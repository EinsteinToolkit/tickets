#include "cctk.h"
#include "cctk_Arguments.h"
#include "cctk_Parameters.h"
#include "util_Table.h"
#include "util_ErrorCodes.h"
#include <stdio.h>
#include <stdlib.h>

#include <iostream>
#include <complex>

static int interp_fields(const cGH* cctkGH,
          CCTK_INT re_inxd,
          CCTK_INT num_points, 
          const CCTK_REAL * xc,
          const CCTK_REAL * yc,
          const CCTK_REAL * zc,
          CCTK_REAL *re_f);



static int interp_fields(const cGH* cctkGH,
          CCTK_INT re_indx,
          CCTK_INT num_points, 
          const CCTK_REAL * xc,
          const CCTK_REAL * yc,
          const CCTK_REAL * zc,
          CCTK_REAL *re_f)
{
  static int operator_handle = -1;
  static int coord_handle = -1;
  static int param_table_handle = -1;

  int N_dims = 3;
  int N_interp_points    = num_points; /* only proc 0 requests points*/
  int N_input_arrays     = 1;
  int N_output_arrays    = 1;

  const int interp_coords_type_code = CCTK_VARIABLE_REAL;
  const void *const interp_coords[3] =
	{(void *)xc, (void *)yc, (void *)zc};

  const CCTK_INT input_array_variable_indices[1]=
      {re_indx};
  const CCTK_INT output_array_type_codes[1]=
	{CCTK_VARIABLE_REAL};
  void *const output_arrays[1]={(void *)re_f};

  if (operator_handle < 0)
  {
    operator_handle = CCTK_InterpHandle(
           "Lagrange polynomial interpolation (tensor product)");

    if (operator_handle < 0 )
      CCTK_WARN(0, "cound not get interpolator handle");

    param_table_handle = Util_TableCreateFromString("order=3"); /*4th order error*/
    if (param_table_handle < 0 )
      CCTK_WARN(0, "cound not get parameter table handle");

    coord_handle = CCTK_CoordSystemHandle ("cart3d");

   if (coord_handle < 0 )
      CCTK_WARN(0, "could net get coord handle");
  }

  if(CCTK_InterpGridArrays(cctkGH, N_dims, operator_handle,
			   param_table_handle,
			   coord_handle, N_interp_points,
			   interp_coords_type_code,
			   interp_coords,
			   N_input_arrays, input_array_variable_indices,
			   N_output_arrays, output_array_type_codes,
			   output_arrays))
  {
    CCTK_WARN(0, "Interpolation error ");
    return -1;
  }

  return 0;
}


extern "C"
{
  void Triv_Triv(CCTK_ARGUMENTS)
  {
    DECLARE_CCTK_ARGUMENTS;
    DECLARE_CCTK_PARAMETERS;

    double x = 3.9668989547038360;
    double y =0;
    double z = -17.6306620209059197;
    double r;

    interp_fields(cctkGH, CCTK_VarIndex("ADMBase::gxx"),
          1, &x, &y, &z, &r);

   fprintf(stderr, "gxx(%f,%f,%f) = %20.16f\n at iter %d on proc %d\n", x,y,z,r,
       cctk_iteration, CCTK_MyProc(cctkGH));
  }
}
