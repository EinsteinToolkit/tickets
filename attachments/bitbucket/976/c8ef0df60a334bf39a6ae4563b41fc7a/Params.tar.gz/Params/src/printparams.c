#include <stdio.h>
#include <cctk.h>
#include <cctk_Parameters.h>
#include <cctk_Arguments.h>

int printparams(void)
{
  DECLARE_CCTK_PARAMETERS;

  int *P1,*P2,*P3;
  printf("p1: %d p2:%d p3:%d\n", p1,p2,p3);
  P1 = CCTK_ParameterGet("p1", CCTK_THORNSTRING, NULL);
  P2 = CCTK_ParameterGet("p2", CCTK_THORNSTRING, NULL);
  P3 = CCTK_ParameterGet("p3", CCTK_THORNSTRING, NULL);
  printf("P1: %d P2:%d P3:%d\n", *P1,*P2,*P3);

  return 0;
}
