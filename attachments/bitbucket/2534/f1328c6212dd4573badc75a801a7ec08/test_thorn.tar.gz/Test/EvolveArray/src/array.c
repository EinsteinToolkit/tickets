#include <cctk.h>
#include <cctk_Arguments.h>
#include <cctk_Parameters.h>

void EvolveArray_MoLRegister(CCTK_ARGUMENTS)
{
  int err = 0;

  err += MoLRegisterEvolved(CCTK_VarIndex("EvolveArray::array_x"),
                             CCTK_VarIndex("EvolveArray::array_dotx"));
  err += MoLRegisterEvolved(CCTK_VarIndex("EvolveArray::array_y"),
                             CCTK_VarIndex("EvolveArray::array_doty"));
  err += MoLRegisterEvolved(CCTK_VarIndex("EvolveArray::array_z"),
                             CCTK_VarIndex("EvolveArray::array_dotz"));
}


void EvolveArray_RHS(CCTK_ARGUMENTS)
{
  DECLARE_CCTK_ARGUMENTS;
  for (int i = 0; i < 4; i++)
  {
    array_dotx[i] = 0;
    array_doty[i] = 0;
    array_dotz[i] = 0;
  }
}

void EvolveArray_ID(CCTK_ARGUMENTS)
{
  DECLARE_CCTK_ARGUMENTS;
  for (int i = 0; i < 4; i++)
  {
    array_x[i] = 0;
    array_y[i] = 0;
    array_z[i] = 0;

    array_x_p[i] = 0;
    array_y_p[i] = 0;
    array_z_p[i] = 0;

    array_x_p_p[i] = 0;
    array_y_p_p[i] = 0;
    array_z_p_p[i] = 0;
  }
}
