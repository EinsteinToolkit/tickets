/*  File produced by Kranc */

#define KRANC_C

#include <algorithm>
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cctk.h"
#include "cctk_Arguments.h"
#include "cctk_Parameters.h"
#include "Kranc.hh"
#include "Differencing.h"

namespace ML_BSSN {

extern "C" void ML_BSSN_EvolutionInteriorSplitBy2_SelectBCs(CCTK_ARGUMENTS)
{
  #ifdef DECLARE_CCTK_ARGUMENTS_ML_BSSN_EvolutionInteriorSplitBy2_SelectBCs
  DECLARE_CCTK_ARGUMENTS_CHECKED(ML_BSSN_EvolutionInteriorSplitBy2_SelectBCs);
  #else
  DECLARE_CCTK_ARGUMENTS;
  #endif
  DECLARE_CCTK_PARAMETERS;
  
  if (cctk_iteration % ML_BSSN_EvolutionInteriorSplitBy2_calc_every != ML_BSSN_EvolutionInteriorSplitBy2_calc_offset)
    return;
  CCTK_INT ierr CCTK_ATTRIBUTE_UNUSED = 0;
  ierr = KrancBdy_SelectGroupForBC(cctkGH, CCTK_ALL_FACES, GetBoundaryWidth(cctkGH), -1 /* no table */, "ML_BSSN::ML_dtshiftrhs","flat");
  if (ierr < 0)
    CCTK_WARN(CCTK_WARN_ALERT, "Failed to register flat BC for ML_BSSN::ML_dtshiftrhs.");
  ierr = KrancBdy_SelectGroupForBC(cctkGH, CCTK_ALL_FACES, GetBoundaryWidth(cctkGH), -1 /* no table */, "ML_BSSN::ML_Gammarhs","flat");
  if (ierr < 0)
    CCTK_WARN(CCTK_WARN_ALERT, "Failed to register flat BC for ML_BSSN::ML_Gammarhs.");
  ierr = KrancBdy_SelectGroupForBC(cctkGH, CCTK_ALL_FACES, GetBoundaryWidth(cctkGH), -1 /* no table */, "ML_BSSN::ML_shiftrhs","flat");
  if (ierr < 0)
    CCTK_WARN(CCTK_WARN_ALERT, "Failed to register flat BC for ML_BSSN::ML_shiftrhs.");
  ierr = KrancBdy_SelectGroupForBC(cctkGH, CCTK_ALL_FACES, GetBoundaryWidth(cctkGH), -1 /* no table */, "ML_BSSN::ML_trace_curvrhs","flat");
  if (ierr < 0)
    CCTK_WARN(CCTK_WARN_ALERT, "Failed to register flat BC for ML_BSSN::ML_trace_curvrhs.");
  return;
}

static void ML_BSSN_EvolutionInteriorSplitBy2_Body(const cGH* restrict const cctkGH, const int dir, const int face, const CCTK_REAL normal[3], const CCTK_REAL tangentA[3], const CCTK_REAL tangentB[3], const int imin[3], const int imax[3], const int n_subblock_gfs, CCTK_REAL* restrict const subblock_gfs[])
{
  DECLARE_CCTK_ARGUMENTS;
  DECLARE_CCTK_PARAMETERS;
  
  /* Include user-supplied include files */
  /* Initialise finite differencing variables */
  const ptrdiff_t di CCTK_ATTRIBUTE_UNUSED = 1;
  const ptrdiff_t dj CCTK_ATTRIBUTE_UNUSED = 
    CCTK_GFINDEX3D(cctkGH,0,1,0) - CCTK_GFINDEX3D(cctkGH,0,0,0);
  const ptrdiff_t dk CCTK_ATTRIBUTE_UNUSED = 
    CCTK_GFINDEX3D(cctkGH,0,0,1) - CCTK_GFINDEX3D(cctkGH,0,0,0);
  const ptrdiff_t cdi CCTK_ATTRIBUTE_UNUSED = sizeof(CCTK_REAL) * di;
  const ptrdiff_t cdj CCTK_ATTRIBUTE_UNUSED = sizeof(CCTK_REAL) * dj;
  const ptrdiff_t cdk CCTK_ATTRIBUTE_UNUSED = sizeof(CCTK_REAL) * dk;
  const ptrdiff_t cctkLbnd1 CCTK_ATTRIBUTE_UNUSED = cctk_lbnd[0];
  const ptrdiff_t cctkLbnd2 CCTK_ATTRIBUTE_UNUSED = cctk_lbnd[1];
  const ptrdiff_t cctkLbnd3 CCTK_ATTRIBUTE_UNUSED = cctk_lbnd[2];
  const CCTK_REAL t CCTK_ATTRIBUTE_UNUSED = cctk_time;
  const CCTK_REAL cctkOriginSpace1 CCTK_ATTRIBUTE_UNUSED = 
    CCTK_ORIGIN_SPACE(0);
  const CCTK_REAL cctkOriginSpace2 CCTK_ATTRIBUTE_UNUSED = 
    CCTK_ORIGIN_SPACE(1);
  const CCTK_REAL cctkOriginSpace3 CCTK_ATTRIBUTE_UNUSED = 
    CCTK_ORIGIN_SPACE(2);
  const CCTK_REAL dt CCTK_ATTRIBUTE_UNUSED = CCTK_DELTA_TIME;
  const CCTK_REAL dx CCTK_ATTRIBUTE_UNUSED = CCTK_DELTA_SPACE(0);
  const CCTK_REAL dy CCTK_ATTRIBUTE_UNUSED = CCTK_DELTA_SPACE(1);
  const CCTK_REAL dz CCTK_ATTRIBUTE_UNUSED = CCTK_DELTA_SPACE(2);
  const CCTK_REAL dxi CCTK_ATTRIBUTE_UNUSED = pow(dx,-1);
  const CCTK_REAL dyi CCTK_ATTRIBUTE_UNUSED = pow(dy,-1);
  const CCTK_REAL dzi CCTK_ATTRIBUTE_UNUSED = pow(dz,-1);
  const CCTK_REAL khalf CCTK_ATTRIBUTE_UNUSED = 0.5;
  const CCTK_REAL kthird CCTK_ATTRIBUTE_UNUSED = 
    0.333333333333333333333333333333;
  const CCTK_REAL ktwothird CCTK_ATTRIBUTE_UNUSED = 
    0.666666666666666666666666666667;
  const CCTK_REAL kfourthird CCTK_ATTRIBUTE_UNUSED = 
    1.33333333333333333333333333333;
  const CCTK_REAL hdxi CCTK_ATTRIBUTE_UNUSED = 0.5*dxi;
  const CCTK_REAL hdyi CCTK_ATTRIBUTE_UNUSED = 0.5*dyi;
  const CCTK_REAL hdzi CCTK_ATTRIBUTE_UNUSED = 0.5*dzi;
  /* Initialize predefined quantities */
  const CCTK_REAL p1o1024dx CCTK_ATTRIBUTE_UNUSED = 0.0009765625*pow(dx,-1);
  const CCTK_REAL p1o1024dy CCTK_ATTRIBUTE_UNUSED = 0.0009765625*pow(dy,-1);
  const CCTK_REAL p1o1024dz CCTK_ATTRIBUTE_UNUSED = 0.0009765625*pow(dz,-1);
  const CCTK_REAL p1o120dx CCTK_ATTRIBUTE_UNUSED = 0.00833333333333333333333333333333*pow(dx,-1);
  const CCTK_REAL p1o120dy CCTK_ATTRIBUTE_UNUSED = 0.00833333333333333333333333333333*pow(dy,-1);
  const CCTK_REAL p1o120dz CCTK_ATTRIBUTE_UNUSED = 0.00833333333333333333333333333333*pow(dz,-1);
  const CCTK_REAL p1o12dx CCTK_ATTRIBUTE_UNUSED = 0.0833333333333333333333333333333*pow(dx,-1);
  const CCTK_REAL p1o12dy CCTK_ATTRIBUTE_UNUSED = 0.0833333333333333333333333333333*pow(dy,-1);
  const CCTK_REAL p1o12dz CCTK_ATTRIBUTE_UNUSED = 0.0833333333333333333333333333333*pow(dz,-1);
  const CCTK_REAL p1o144dxdy CCTK_ATTRIBUTE_UNUSED = 0.00694444444444444444444444444444*pow(dx,-1)*pow(dy,-1);
  const CCTK_REAL p1o144dxdz CCTK_ATTRIBUTE_UNUSED = 0.00694444444444444444444444444444*pow(dx,-1)*pow(dz,-1);
  const CCTK_REAL p1o144dydz CCTK_ATTRIBUTE_UNUSED = 0.00694444444444444444444444444444*pow(dy,-1)*pow(dz,-1);
  const CCTK_REAL p1o1680dx CCTK_ATTRIBUTE_UNUSED = 0.000595238095238095238095238095238*pow(dx,-1);
  const CCTK_REAL p1o1680dy CCTK_ATTRIBUTE_UNUSED = 0.000595238095238095238095238095238*pow(dy,-1);
  const CCTK_REAL p1o1680dz CCTK_ATTRIBUTE_UNUSED = 0.000595238095238095238095238095238*pow(dz,-1);
  const CCTK_REAL p1o180dx2 CCTK_ATTRIBUTE_UNUSED = 0.00555555555555555555555555555556*pow(dx,-2);
  const CCTK_REAL p1o180dy2 CCTK_ATTRIBUTE_UNUSED = 0.00555555555555555555555555555556*pow(dy,-2);
  const CCTK_REAL p1o180dz2 CCTK_ATTRIBUTE_UNUSED = 0.00555555555555555555555555555556*pow(dz,-2);
  const CCTK_REAL p1o24dx CCTK_ATTRIBUTE_UNUSED = 0.0416666666666666666666666666667*pow(dx,-1);
  const CCTK_REAL p1o24dy CCTK_ATTRIBUTE_UNUSED = 0.0416666666666666666666666666667*pow(dy,-1);
  const CCTK_REAL p1o24dz CCTK_ATTRIBUTE_UNUSED = 0.0416666666666666666666666666667*pow(dz,-1);
  const CCTK_REAL p1o2dx CCTK_ATTRIBUTE_UNUSED = 0.5*pow(dx,-1);
  const CCTK_REAL p1o2dy CCTK_ATTRIBUTE_UNUSED = 0.5*pow(dy,-1);
  const CCTK_REAL p1o2dz CCTK_ATTRIBUTE_UNUSED = 0.5*pow(dz,-1);
  const CCTK_REAL p1o3600dxdy CCTK_ATTRIBUTE_UNUSED = 0.000277777777777777777777777777778*pow(dx,-1)*pow(dy,-1);
  const CCTK_REAL p1o3600dxdz CCTK_ATTRIBUTE_UNUSED = 0.000277777777777777777777777777778*pow(dx,-1)*pow(dz,-1);
  const CCTK_REAL p1o3600dydz CCTK_ATTRIBUTE_UNUSED = 0.000277777777777777777777777777778*pow(dy,-1)*pow(dz,-1);
  const CCTK_REAL p1o4dx CCTK_ATTRIBUTE_UNUSED = 0.25*pow(dx,-1);
  const CCTK_REAL p1o4dxdy CCTK_ATTRIBUTE_UNUSED = 0.25*pow(dx,-1)*pow(dy,-1);
  const CCTK_REAL p1o4dxdz CCTK_ATTRIBUTE_UNUSED = 0.25*pow(dx,-1)*pow(dz,-1);
  const CCTK_REAL p1o4dy CCTK_ATTRIBUTE_UNUSED = 0.25*pow(dy,-1);
  const CCTK_REAL p1o4dydz CCTK_ATTRIBUTE_UNUSED = 0.25*pow(dy,-1)*pow(dz,-1);
  const CCTK_REAL p1o4dz CCTK_ATTRIBUTE_UNUSED = 0.25*pow(dz,-1);
  const CCTK_REAL p1o5040dx2 CCTK_ATTRIBUTE_UNUSED = 0.000198412698412698412698412698413*pow(dx,-2);
  const CCTK_REAL p1o5040dy2 CCTK_ATTRIBUTE_UNUSED = 0.000198412698412698412698412698413*pow(dy,-2);
  const CCTK_REAL p1o5040dz2 CCTK_ATTRIBUTE_UNUSED = 0.000198412698412698412698412698413*pow(dz,-2);
  const CCTK_REAL p1o560dx CCTK_ATTRIBUTE_UNUSED = 0.00178571428571428571428571428571*pow(dx,-1);
  const CCTK_REAL p1o560dy CCTK_ATTRIBUTE_UNUSED = 0.00178571428571428571428571428571*pow(dy,-1);
  const CCTK_REAL p1o560dz CCTK_ATTRIBUTE_UNUSED = 0.00178571428571428571428571428571*pow(dz,-1);
  const CCTK_REAL p1o60dx CCTK_ATTRIBUTE_UNUSED = 0.0166666666666666666666666666667*pow(dx,-1);
  const CCTK_REAL p1o60dy CCTK_ATTRIBUTE_UNUSED = 0.0166666666666666666666666666667*pow(dy,-1);
  const CCTK_REAL p1o60dz CCTK_ATTRIBUTE_UNUSED = 0.0166666666666666666666666666667*pow(dz,-1);
  const CCTK_REAL p1o64dx CCTK_ATTRIBUTE_UNUSED = 0.015625*pow(dx,-1);
  const CCTK_REAL p1o64dy CCTK_ATTRIBUTE_UNUSED = 0.015625*pow(dy,-1);
  const CCTK_REAL p1o64dz CCTK_ATTRIBUTE_UNUSED = 0.015625*pow(dz,-1);
  const CCTK_REAL p1o705600dxdy CCTK_ATTRIBUTE_UNUSED = 1.41723356009070294784580498866e-6*pow(dx,-1)*pow(dy,-1);
  const CCTK_REAL p1o705600dxdz CCTK_ATTRIBUTE_UNUSED = 1.41723356009070294784580498866e-6*pow(dx,-1)*pow(dz,-1);
  const CCTK_REAL p1o705600dydz CCTK_ATTRIBUTE_UNUSED = 1.41723356009070294784580498866e-6*pow(dy,-1)*pow(dz,-1);
  const CCTK_REAL p1o840dx CCTK_ATTRIBUTE_UNUSED = 0.00119047619047619047619047619048*pow(dx,-1);
  const CCTK_REAL p1o840dy CCTK_ATTRIBUTE_UNUSED = 0.00119047619047619047619047619048*pow(dy,-1);
  const CCTK_REAL p1o840dz CCTK_ATTRIBUTE_UNUSED = 0.00119047619047619047619047619048*pow(dz,-1);
  const CCTK_REAL p1odx2 CCTK_ATTRIBUTE_UNUSED = pow(dx,-2);
  const CCTK_REAL p1ody2 CCTK_ATTRIBUTE_UNUSED = pow(dy,-2);
  const CCTK_REAL p1odz2 CCTK_ATTRIBUTE_UNUSED = pow(dz,-2);
  const CCTK_REAL pm1o120dx CCTK_ATTRIBUTE_UNUSED = -0.00833333333333333333333333333333*pow(dx,-1);
  const CCTK_REAL pm1o120dy CCTK_ATTRIBUTE_UNUSED = -0.00833333333333333333333333333333*pow(dy,-1);
  const CCTK_REAL pm1o120dz CCTK_ATTRIBUTE_UNUSED = -0.00833333333333333333333333333333*pow(dz,-1);
  const CCTK_REAL pm1o12dx CCTK_ATTRIBUTE_UNUSED = -0.0833333333333333333333333333333*pow(dx,-1);
  const CCTK_REAL pm1o12dx2 CCTK_ATTRIBUTE_UNUSED = -0.0833333333333333333333333333333*pow(dx,-2);
  const CCTK_REAL pm1o12dy CCTK_ATTRIBUTE_UNUSED = -0.0833333333333333333333333333333*pow(dy,-1);
  const CCTK_REAL pm1o12dy2 CCTK_ATTRIBUTE_UNUSED = -0.0833333333333333333333333333333*pow(dy,-2);
  const CCTK_REAL pm1o12dz CCTK_ATTRIBUTE_UNUSED = -0.0833333333333333333333333333333*pow(dz,-1);
  const CCTK_REAL pm1o12dz2 CCTK_ATTRIBUTE_UNUSED = -0.0833333333333333333333333333333*pow(dz,-2);
  const CCTK_REAL pm1o16dx CCTK_ATTRIBUTE_UNUSED = -0.0625*pow(dx,-1);
  const CCTK_REAL pm1o16dy CCTK_ATTRIBUTE_UNUSED = -0.0625*pow(dy,-1);
  const CCTK_REAL pm1o16dz CCTK_ATTRIBUTE_UNUSED = -0.0625*pow(dz,-1);
  const CCTK_REAL pm1o256dx CCTK_ATTRIBUTE_UNUSED = -0.00390625*pow(dx,-1);
  const CCTK_REAL pm1o256dy CCTK_ATTRIBUTE_UNUSED = -0.00390625*pow(dy,-1);
  const CCTK_REAL pm1o256dz CCTK_ATTRIBUTE_UNUSED = -0.00390625*pow(dz,-1);
  const CCTK_REAL pm1o2dx CCTK_ATTRIBUTE_UNUSED = -0.5*pow(dx,-1);
  const CCTK_REAL pm1o2dy CCTK_ATTRIBUTE_UNUSED = -0.5*pow(dy,-1);
  const CCTK_REAL pm1o2dz CCTK_ATTRIBUTE_UNUSED = -0.5*pow(dz,-1);
  const CCTK_REAL pm1o4dx CCTK_ATTRIBUTE_UNUSED = -0.25*pow(dx,-1);
  const CCTK_REAL pm1o4dy CCTK_ATTRIBUTE_UNUSED = -0.25*pow(dy,-1);
  const CCTK_REAL pm1o4dz CCTK_ATTRIBUTE_UNUSED = -0.25*pow(dz,-1);
  const CCTK_REAL pm1o60dx CCTK_ATTRIBUTE_UNUSED = -0.0166666666666666666666666666667*pow(dx,-1);
  const CCTK_REAL pm1o60dy CCTK_ATTRIBUTE_UNUSED = -0.0166666666666666666666666666667*pow(dy,-1);
  const CCTK_REAL pm1o60dz CCTK_ATTRIBUTE_UNUSED = -0.0166666666666666666666666666667*pow(dz,-1);
  const CCTK_REAL pm1o6dx CCTK_ATTRIBUTE_UNUSED = -0.166666666666666666666666666667*pow(dx,-1);
  const CCTK_REAL pm1o6dy CCTK_ATTRIBUTE_UNUSED = -0.166666666666666666666666666667*pow(dy,-1);
  const CCTK_REAL pm1o6dz CCTK_ATTRIBUTE_UNUSED = -0.166666666666666666666666666667*pow(dz,-1);
  const CCTK_REAL pm1o840dx CCTK_ATTRIBUTE_UNUSED = -0.00119047619047619047619047619048*pow(dx,-1);
  const CCTK_REAL pm1o840dy CCTK_ATTRIBUTE_UNUSED = -0.00119047619047619047619047619048*pow(dy,-1);
  const CCTK_REAL pm1o840dz CCTK_ATTRIBUTE_UNUSED = -0.00119047619047619047619047619048*pow(dz,-1);
  /* Assign local copies of arrays functions */
  
  
  /* Calculate temporaries and arrays functions */
  /* Copy local copies back to grid functions */
  /* Loop over the grid points */
  const int imin0=imin[0];
  const int imin1=imin[1];
  const int imin2=imin[2];
  const int imax0=imax[0];
  const int imax1=imax[1];
  const int imax2=imax[2];
  #pragma omp parallel
  CCTK_LOOP3(ML_BSSN_EvolutionInteriorSplitBy2,
    i,j,k, imin0,imin1,imin2, imax0,imax1,imax2,
    cctk_ash[0],cctk_ash[1],cctk_ash[2])
  {
    const ptrdiff_t index CCTK_ATTRIBUTE_UNUSED = di*i + dj*j + dk*k;
    /* Assign local copies of grid functions */
    
    CCTK_REAL alphaL CCTK_ATTRIBUTE_UNUSED = alpha[index];
    CCTK_REAL At11L CCTK_ATTRIBUTE_UNUSED = At11[index];
    CCTK_REAL At12L CCTK_ATTRIBUTE_UNUSED = At12[index];
    CCTK_REAL At13L CCTK_ATTRIBUTE_UNUSED = At13[index];
    CCTK_REAL At22L CCTK_ATTRIBUTE_UNUSED = At22[index];
    CCTK_REAL At23L CCTK_ATTRIBUTE_UNUSED = At23[index];
    CCTK_REAL At33L CCTK_ATTRIBUTE_UNUSED = At33[index];
    CCTK_REAL B1L CCTK_ATTRIBUTE_UNUSED = B1[index];
    CCTK_REAL B2L CCTK_ATTRIBUTE_UNUSED = B2[index];
    CCTK_REAL B3L CCTK_ATTRIBUTE_UNUSED = B3[index];
    CCTK_REAL beta1L CCTK_ATTRIBUTE_UNUSED = beta1[index];
    CCTK_REAL beta2L CCTK_ATTRIBUTE_UNUSED = beta2[index];
    CCTK_REAL beta3L CCTK_ATTRIBUTE_UNUSED = beta3[index];
    CCTK_REAL gt11L CCTK_ATTRIBUTE_UNUSED = gt11[index];
    CCTK_REAL gt12L CCTK_ATTRIBUTE_UNUSED = gt12[index];
    CCTK_REAL gt13L CCTK_ATTRIBUTE_UNUSED = gt13[index];
    CCTK_REAL gt22L CCTK_ATTRIBUTE_UNUSED = gt22[index];
    CCTK_REAL gt23L CCTK_ATTRIBUTE_UNUSED = gt23[index];
    CCTK_REAL gt33L CCTK_ATTRIBUTE_UNUSED = gt33[index];
    CCTK_REAL phiL CCTK_ATTRIBUTE_UNUSED = phi[index];
    CCTK_REAL rL CCTK_ATTRIBUTE_UNUSED = r[index];
    CCTK_REAL trKL CCTK_ATTRIBUTE_UNUSED = trK[index];
    CCTK_REAL Xt1L CCTK_ATTRIBUTE_UNUSED = Xt1[index];
    CCTK_REAL Xt2L CCTK_ATTRIBUTE_UNUSED = Xt2[index];
    CCTK_REAL Xt3L CCTK_ATTRIBUTE_UNUSED = Xt3[index];
    
    /* Include user supplied include files */
    /* Precompute derivatives */
    CCTK_REAL PDstandardNth1alpha CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDstandardNth2alpha CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDstandardNth3alpha CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDstandardNth11alpha CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDstandardNth22alpha CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDstandardNth33alpha CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDstandardNth12alpha CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDstandardNth13alpha CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDstandardNth23alpha CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDupwindNthSymm1B1 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDupwindNthSymm2B1 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDupwindNthSymm3B1 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDupwindNthAnti1B1 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDupwindNthAnti2B1 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDupwindNthAnti3B1 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDdissipationNth1B1 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDdissipationNth2B1 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDdissipationNth3B1 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDupwindNthSymm1B2 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDupwindNthSymm2B2 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDupwindNthSymm3B2 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDupwindNthAnti1B2 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDupwindNthAnti2B2 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDupwindNthAnti3B2 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDdissipationNth1B2 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDdissipationNth2B2 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDdissipationNth3B2 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDupwindNthSymm1B3 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDupwindNthSymm2B3 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDupwindNthSymm3B3 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDupwindNthAnti1B3 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDupwindNthAnti2B3 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDupwindNthAnti3B3 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDdissipationNth1B3 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDdissipationNth2B3 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDdissipationNth3B3 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDstandardNth1beta1 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDstandardNth2beta1 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDstandardNth3beta1 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDstandardNth11beta1 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDstandardNth22beta1 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDstandardNth33beta1 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDstandardNth12beta1 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDstandardNth13beta1 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDstandardNth23beta1 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDupwindNthSymm1beta1 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDupwindNthSymm2beta1 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDupwindNthSymm3beta1 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDupwindNthAnti1beta1 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDupwindNthAnti2beta1 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDupwindNthAnti3beta1 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDdissipationNth1beta1 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDdissipationNth2beta1 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDdissipationNth3beta1 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDstandardNth1beta2 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDstandardNth2beta2 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDstandardNth3beta2 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDstandardNth11beta2 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDstandardNth22beta2 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDstandardNth33beta2 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDstandardNth12beta2 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDstandardNth13beta2 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDstandardNth23beta2 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDupwindNthSymm1beta2 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDupwindNthSymm2beta2 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDupwindNthSymm3beta2 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDupwindNthAnti1beta2 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDupwindNthAnti2beta2 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDupwindNthAnti3beta2 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDdissipationNth1beta2 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDdissipationNth2beta2 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDdissipationNth3beta2 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDstandardNth1beta3 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDstandardNth2beta3 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDstandardNth3beta3 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDstandardNth11beta3 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDstandardNth22beta3 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDstandardNth33beta3 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDstandardNth12beta3 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDstandardNth13beta3 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDstandardNth23beta3 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDupwindNthSymm1beta3 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDupwindNthSymm2beta3 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDupwindNthSymm3beta3 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDupwindNthAnti1beta3 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDupwindNthAnti2beta3 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDupwindNthAnti3beta3 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDdissipationNth1beta3 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDdissipationNth2beta3 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDdissipationNth3beta3 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDstandardNth1gt11 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDstandardNth2gt11 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDstandardNth3gt11 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDstandardNth1gt12 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDstandardNth2gt12 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDstandardNth3gt12 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDstandardNth1gt13 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDstandardNth2gt13 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDstandardNth3gt13 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDstandardNth1gt22 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDstandardNth2gt22 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDstandardNth3gt22 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDstandardNth1gt23 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDstandardNth2gt23 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDstandardNth3gt23 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDstandardNth1gt33 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDstandardNth2gt33 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDstandardNth3gt33 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDstandardNth1phi CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDstandardNth2phi CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDstandardNth3phi CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDstandardNth1trK CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDstandardNth2trK CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDstandardNth3trK CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDupwindNthSymm1trK CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDupwindNthSymm2trK CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDupwindNthSymm3trK CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDupwindNthAnti1trK CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDupwindNthAnti2trK CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDupwindNthAnti3trK CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDdissipationNth1trK CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDdissipationNth2trK CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDdissipationNth3trK CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDupwindNthSymm1Xt1 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDupwindNthSymm2Xt1 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDupwindNthSymm3Xt1 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDupwindNthAnti1Xt1 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDupwindNthAnti2Xt1 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDupwindNthAnti3Xt1 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDdissipationNth1Xt1 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDdissipationNth2Xt1 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDdissipationNth3Xt1 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDupwindNthSymm1Xt2 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDupwindNthSymm2Xt2 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDupwindNthSymm3Xt2 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDupwindNthAnti1Xt2 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDupwindNthAnti2Xt2 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDupwindNthAnti3Xt2 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDdissipationNth1Xt2 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDdissipationNth2Xt2 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDdissipationNth3Xt2 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDupwindNthSymm1Xt3 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDupwindNthSymm2Xt3 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDupwindNthSymm3Xt3 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDupwindNthAnti1Xt3 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDupwindNthAnti2Xt3 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDupwindNthAnti3Xt3 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDdissipationNth1Xt3 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDdissipationNth2Xt3 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL PDdissipationNth3Xt3 CCTK_ATTRIBUTE_UNUSED;
    
    switch (fdOrder)
    {
      case 2:
      {
        PDstandardNth1alpha = PDstandardNthfdOrder21(&alpha[index]);
        PDstandardNth2alpha = PDstandardNthfdOrder22(&alpha[index]);
        PDstandardNth3alpha = PDstandardNthfdOrder23(&alpha[index]);
        PDstandardNth11alpha = PDstandardNthfdOrder211(&alpha[index]);
        PDstandardNth22alpha = PDstandardNthfdOrder222(&alpha[index]);
        PDstandardNth33alpha = PDstandardNthfdOrder233(&alpha[index]);
        PDstandardNth12alpha = PDstandardNthfdOrder212(&alpha[index]);
        PDstandardNth13alpha = PDstandardNthfdOrder213(&alpha[index]);
        PDstandardNth23alpha = PDstandardNthfdOrder223(&alpha[index]);
        PDupwindNthSymm1B1 = PDupwindNthSymmfdOrder21(&B1[index]);
        PDupwindNthSymm2B1 = PDupwindNthSymmfdOrder22(&B1[index]);
        PDupwindNthSymm3B1 = PDupwindNthSymmfdOrder23(&B1[index]);
        PDupwindNthAnti1B1 = PDupwindNthAntifdOrder21(&B1[index]);
        PDupwindNthAnti2B1 = PDupwindNthAntifdOrder22(&B1[index]);
        PDupwindNthAnti3B1 = PDupwindNthAntifdOrder23(&B1[index]);
        PDdissipationNth1B1 = PDdissipationNthfdOrder21(&B1[index]);
        PDdissipationNth2B1 = PDdissipationNthfdOrder22(&B1[index]);
        PDdissipationNth3B1 = PDdissipationNthfdOrder23(&B1[index]);
        PDupwindNthSymm1B2 = PDupwindNthSymmfdOrder21(&B2[index]);
        PDupwindNthSymm2B2 = PDupwindNthSymmfdOrder22(&B2[index]);
        PDupwindNthSymm3B2 = PDupwindNthSymmfdOrder23(&B2[index]);
        PDupwindNthAnti1B2 = PDupwindNthAntifdOrder21(&B2[index]);
        PDupwindNthAnti2B2 = PDupwindNthAntifdOrder22(&B2[index]);
        PDupwindNthAnti3B2 = PDupwindNthAntifdOrder23(&B2[index]);
        PDdissipationNth1B2 = PDdissipationNthfdOrder21(&B2[index]);
        PDdissipationNth2B2 = PDdissipationNthfdOrder22(&B2[index]);
        PDdissipationNth3B2 = PDdissipationNthfdOrder23(&B2[index]);
        PDupwindNthSymm1B3 = PDupwindNthSymmfdOrder21(&B3[index]);
        PDupwindNthSymm2B3 = PDupwindNthSymmfdOrder22(&B3[index]);
        PDupwindNthSymm3B3 = PDupwindNthSymmfdOrder23(&B3[index]);
        PDupwindNthAnti1B3 = PDupwindNthAntifdOrder21(&B3[index]);
        PDupwindNthAnti2B3 = PDupwindNthAntifdOrder22(&B3[index]);
        PDupwindNthAnti3B3 = PDupwindNthAntifdOrder23(&B3[index]);
        PDdissipationNth1B3 = PDdissipationNthfdOrder21(&B3[index]);
        PDdissipationNth2B3 = PDdissipationNthfdOrder22(&B3[index]);
        PDdissipationNth3B3 = PDdissipationNthfdOrder23(&B3[index]);
        PDstandardNth1beta1 = PDstandardNthfdOrder21(&beta1[index]);
        PDstandardNth2beta1 = PDstandardNthfdOrder22(&beta1[index]);
        PDstandardNth3beta1 = PDstandardNthfdOrder23(&beta1[index]);
        PDstandardNth11beta1 = PDstandardNthfdOrder211(&beta1[index]);
        PDstandardNth22beta1 = PDstandardNthfdOrder222(&beta1[index]);
        PDstandardNth33beta1 = PDstandardNthfdOrder233(&beta1[index]);
        PDstandardNth12beta1 = PDstandardNthfdOrder212(&beta1[index]);
        PDstandardNth13beta1 = PDstandardNthfdOrder213(&beta1[index]);
        PDstandardNth23beta1 = PDstandardNthfdOrder223(&beta1[index]);
        PDupwindNthSymm1beta1 = PDupwindNthSymmfdOrder21(&beta1[index]);
        PDupwindNthSymm2beta1 = PDupwindNthSymmfdOrder22(&beta1[index]);
        PDupwindNthSymm3beta1 = PDupwindNthSymmfdOrder23(&beta1[index]);
        PDupwindNthAnti1beta1 = PDupwindNthAntifdOrder21(&beta1[index]);
        PDupwindNthAnti2beta1 = PDupwindNthAntifdOrder22(&beta1[index]);
        PDupwindNthAnti3beta1 = PDupwindNthAntifdOrder23(&beta1[index]);
        PDdissipationNth1beta1 = PDdissipationNthfdOrder21(&beta1[index]);
        PDdissipationNth2beta1 = PDdissipationNthfdOrder22(&beta1[index]);
        PDdissipationNth3beta1 = PDdissipationNthfdOrder23(&beta1[index]);
        PDstandardNth1beta2 = PDstandardNthfdOrder21(&beta2[index]);
        PDstandardNth2beta2 = PDstandardNthfdOrder22(&beta2[index]);
        PDstandardNth3beta2 = PDstandardNthfdOrder23(&beta2[index]);
        PDstandardNth11beta2 = PDstandardNthfdOrder211(&beta2[index]);
        PDstandardNth22beta2 = PDstandardNthfdOrder222(&beta2[index]);
        PDstandardNth33beta2 = PDstandardNthfdOrder233(&beta2[index]);
        PDstandardNth12beta2 = PDstandardNthfdOrder212(&beta2[index]);
        PDstandardNth13beta2 = PDstandardNthfdOrder213(&beta2[index]);
        PDstandardNth23beta2 = PDstandardNthfdOrder223(&beta2[index]);
        PDupwindNthSymm1beta2 = PDupwindNthSymmfdOrder21(&beta2[index]);
        PDupwindNthSymm2beta2 = PDupwindNthSymmfdOrder22(&beta2[index]);
        PDupwindNthSymm3beta2 = PDupwindNthSymmfdOrder23(&beta2[index]);
        PDupwindNthAnti1beta2 = PDupwindNthAntifdOrder21(&beta2[index]);
        PDupwindNthAnti2beta2 = PDupwindNthAntifdOrder22(&beta2[index]);
        PDupwindNthAnti3beta2 = PDupwindNthAntifdOrder23(&beta2[index]);
        PDdissipationNth1beta2 = PDdissipationNthfdOrder21(&beta2[index]);
        PDdissipationNth2beta2 = PDdissipationNthfdOrder22(&beta2[index]);
        PDdissipationNth3beta2 = PDdissipationNthfdOrder23(&beta2[index]);
        PDstandardNth1beta3 = PDstandardNthfdOrder21(&beta3[index]);
        PDstandardNth2beta3 = PDstandardNthfdOrder22(&beta3[index]);
        PDstandardNth3beta3 = PDstandardNthfdOrder23(&beta3[index]);
        PDstandardNth11beta3 = PDstandardNthfdOrder211(&beta3[index]);
        PDstandardNth22beta3 = PDstandardNthfdOrder222(&beta3[index]);
        PDstandardNth33beta3 = PDstandardNthfdOrder233(&beta3[index]);
        PDstandardNth12beta3 = PDstandardNthfdOrder212(&beta3[index]);
        PDstandardNth13beta3 = PDstandardNthfdOrder213(&beta3[index]);
        PDstandardNth23beta3 = PDstandardNthfdOrder223(&beta3[index]);
        PDupwindNthSymm1beta3 = PDupwindNthSymmfdOrder21(&beta3[index]);
        PDupwindNthSymm2beta3 = PDupwindNthSymmfdOrder22(&beta3[index]);
        PDupwindNthSymm3beta3 = PDupwindNthSymmfdOrder23(&beta3[index]);
        PDupwindNthAnti1beta3 = PDupwindNthAntifdOrder21(&beta3[index]);
        PDupwindNthAnti2beta3 = PDupwindNthAntifdOrder22(&beta3[index]);
        PDupwindNthAnti3beta3 = PDupwindNthAntifdOrder23(&beta3[index]);
        PDdissipationNth1beta3 = PDdissipationNthfdOrder21(&beta3[index]);
        PDdissipationNth2beta3 = PDdissipationNthfdOrder22(&beta3[index]);
        PDdissipationNth3beta3 = PDdissipationNthfdOrder23(&beta3[index]);
        PDstandardNth1gt11 = PDstandardNthfdOrder21(&gt11[index]);
        PDstandardNth2gt11 = PDstandardNthfdOrder22(&gt11[index]);
        PDstandardNth3gt11 = PDstandardNthfdOrder23(&gt11[index]);
        PDstandardNth1gt12 = PDstandardNthfdOrder21(&gt12[index]);
        PDstandardNth2gt12 = PDstandardNthfdOrder22(&gt12[index]);
        PDstandardNth3gt12 = PDstandardNthfdOrder23(&gt12[index]);
        PDstandardNth1gt13 = PDstandardNthfdOrder21(&gt13[index]);
        PDstandardNth2gt13 = PDstandardNthfdOrder22(&gt13[index]);
        PDstandardNth3gt13 = PDstandardNthfdOrder23(&gt13[index]);
        PDstandardNth1gt22 = PDstandardNthfdOrder21(&gt22[index]);
        PDstandardNth2gt22 = PDstandardNthfdOrder22(&gt22[index]);
        PDstandardNth3gt22 = PDstandardNthfdOrder23(&gt22[index]);
        PDstandardNth1gt23 = PDstandardNthfdOrder21(&gt23[index]);
        PDstandardNth2gt23 = PDstandardNthfdOrder22(&gt23[index]);
        PDstandardNth3gt23 = PDstandardNthfdOrder23(&gt23[index]);
        PDstandardNth1gt33 = PDstandardNthfdOrder21(&gt33[index]);
        PDstandardNth2gt33 = PDstandardNthfdOrder22(&gt33[index]);
        PDstandardNth3gt33 = PDstandardNthfdOrder23(&gt33[index]);
        PDstandardNth1phi = PDstandardNthfdOrder21(&phi[index]);
        PDstandardNth2phi = PDstandardNthfdOrder22(&phi[index]);
        PDstandardNth3phi = PDstandardNthfdOrder23(&phi[index]);
        PDstandardNth1trK = PDstandardNthfdOrder21(&trK[index]);
        PDstandardNth2trK = PDstandardNthfdOrder22(&trK[index]);
        PDstandardNth3trK = PDstandardNthfdOrder23(&trK[index]);
        PDupwindNthSymm1trK = PDupwindNthSymmfdOrder21(&trK[index]);
        PDupwindNthSymm2trK = PDupwindNthSymmfdOrder22(&trK[index]);
        PDupwindNthSymm3trK = PDupwindNthSymmfdOrder23(&trK[index]);
        PDupwindNthAnti1trK = PDupwindNthAntifdOrder21(&trK[index]);
        PDupwindNthAnti2trK = PDupwindNthAntifdOrder22(&trK[index]);
        PDupwindNthAnti3trK = PDupwindNthAntifdOrder23(&trK[index]);
        PDdissipationNth1trK = PDdissipationNthfdOrder21(&trK[index]);
        PDdissipationNth2trK = PDdissipationNthfdOrder22(&trK[index]);
        PDdissipationNth3trK = PDdissipationNthfdOrder23(&trK[index]);
        PDupwindNthSymm1Xt1 = PDupwindNthSymmfdOrder21(&Xt1[index]);
        PDupwindNthSymm2Xt1 = PDupwindNthSymmfdOrder22(&Xt1[index]);
        PDupwindNthSymm3Xt1 = PDupwindNthSymmfdOrder23(&Xt1[index]);
        PDupwindNthAnti1Xt1 = PDupwindNthAntifdOrder21(&Xt1[index]);
        PDupwindNthAnti2Xt1 = PDupwindNthAntifdOrder22(&Xt1[index]);
        PDupwindNthAnti3Xt1 = PDupwindNthAntifdOrder23(&Xt1[index]);
        PDdissipationNth1Xt1 = PDdissipationNthfdOrder21(&Xt1[index]);
        PDdissipationNth2Xt1 = PDdissipationNthfdOrder22(&Xt1[index]);
        PDdissipationNth3Xt1 = PDdissipationNthfdOrder23(&Xt1[index]);
        PDupwindNthSymm1Xt2 = PDupwindNthSymmfdOrder21(&Xt2[index]);
        PDupwindNthSymm2Xt2 = PDupwindNthSymmfdOrder22(&Xt2[index]);
        PDupwindNthSymm3Xt2 = PDupwindNthSymmfdOrder23(&Xt2[index]);
        PDupwindNthAnti1Xt2 = PDupwindNthAntifdOrder21(&Xt2[index]);
        PDupwindNthAnti2Xt2 = PDupwindNthAntifdOrder22(&Xt2[index]);
        PDupwindNthAnti3Xt2 = PDupwindNthAntifdOrder23(&Xt2[index]);
        PDdissipationNth1Xt2 = PDdissipationNthfdOrder21(&Xt2[index]);
        PDdissipationNth2Xt2 = PDdissipationNthfdOrder22(&Xt2[index]);
        PDdissipationNth3Xt2 = PDdissipationNthfdOrder23(&Xt2[index]);
        PDupwindNthSymm1Xt3 = PDupwindNthSymmfdOrder21(&Xt3[index]);
        PDupwindNthSymm2Xt3 = PDupwindNthSymmfdOrder22(&Xt3[index]);
        PDupwindNthSymm3Xt3 = PDupwindNthSymmfdOrder23(&Xt3[index]);
        PDupwindNthAnti1Xt3 = PDupwindNthAntifdOrder21(&Xt3[index]);
        PDupwindNthAnti2Xt3 = PDupwindNthAntifdOrder22(&Xt3[index]);
        PDupwindNthAnti3Xt3 = PDupwindNthAntifdOrder23(&Xt3[index]);
        PDdissipationNth1Xt3 = PDdissipationNthfdOrder21(&Xt3[index]);
        PDdissipationNth2Xt3 = PDdissipationNthfdOrder22(&Xt3[index]);
        PDdissipationNth3Xt3 = PDdissipationNthfdOrder23(&Xt3[index]);
        break;
      }
      
      case 4:
      {
        PDstandardNth1alpha = PDstandardNthfdOrder41(&alpha[index]);
        PDstandardNth2alpha = PDstandardNthfdOrder42(&alpha[index]);
        PDstandardNth3alpha = PDstandardNthfdOrder43(&alpha[index]);
        PDstandardNth11alpha = PDstandardNthfdOrder411(&alpha[index]);
        PDstandardNth22alpha = PDstandardNthfdOrder422(&alpha[index]);
        PDstandardNth33alpha = PDstandardNthfdOrder433(&alpha[index]);
        PDstandardNth12alpha = PDstandardNthfdOrder412(&alpha[index]);
        PDstandardNth13alpha = PDstandardNthfdOrder413(&alpha[index]);
        PDstandardNth23alpha = PDstandardNthfdOrder423(&alpha[index]);
        PDupwindNthSymm1B1 = PDupwindNthSymmfdOrder41(&B1[index]);
        PDupwindNthSymm2B1 = PDupwindNthSymmfdOrder42(&B1[index]);
        PDupwindNthSymm3B1 = PDupwindNthSymmfdOrder43(&B1[index]);
        PDupwindNthAnti1B1 = PDupwindNthAntifdOrder41(&B1[index]);
        PDupwindNthAnti2B1 = PDupwindNthAntifdOrder42(&B1[index]);
        PDupwindNthAnti3B1 = PDupwindNthAntifdOrder43(&B1[index]);
        PDdissipationNth1B1 = PDdissipationNthfdOrder41(&B1[index]);
        PDdissipationNth2B1 = PDdissipationNthfdOrder42(&B1[index]);
        PDdissipationNth3B1 = PDdissipationNthfdOrder43(&B1[index]);
        PDupwindNthSymm1B2 = PDupwindNthSymmfdOrder41(&B2[index]);
        PDupwindNthSymm2B2 = PDupwindNthSymmfdOrder42(&B2[index]);
        PDupwindNthSymm3B2 = PDupwindNthSymmfdOrder43(&B2[index]);
        PDupwindNthAnti1B2 = PDupwindNthAntifdOrder41(&B2[index]);
        PDupwindNthAnti2B2 = PDupwindNthAntifdOrder42(&B2[index]);
        PDupwindNthAnti3B2 = PDupwindNthAntifdOrder43(&B2[index]);
        PDdissipationNth1B2 = PDdissipationNthfdOrder41(&B2[index]);
        PDdissipationNth2B2 = PDdissipationNthfdOrder42(&B2[index]);
        PDdissipationNth3B2 = PDdissipationNthfdOrder43(&B2[index]);
        PDupwindNthSymm1B3 = PDupwindNthSymmfdOrder41(&B3[index]);
        PDupwindNthSymm2B3 = PDupwindNthSymmfdOrder42(&B3[index]);
        PDupwindNthSymm3B3 = PDupwindNthSymmfdOrder43(&B3[index]);
        PDupwindNthAnti1B3 = PDupwindNthAntifdOrder41(&B3[index]);
        PDupwindNthAnti2B3 = PDupwindNthAntifdOrder42(&B3[index]);
        PDupwindNthAnti3B3 = PDupwindNthAntifdOrder43(&B3[index]);
        PDdissipationNth1B3 = PDdissipationNthfdOrder41(&B3[index]);
        PDdissipationNth2B3 = PDdissipationNthfdOrder42(&B3[index]);
        PDdissipationNth3B3 = PDdissipationNthfdOrder43(&B3[index]);
        PDstandardNth1beta1 = PDstandardNthfdOrder41(&beta1[index]);
        PDstandardNth2beta1 = PDstandardNthfdOrder42(&beta1[index]);
        PDstandardNth3beta1 = PDstandardNthfdOrder43(&beta1[index]);
        PDstandardNth11beta1 = PDstandardNthfdOrder411(&beta1[index]);
        PDstandardNth22beta1 = PDstandardNthfdOrder422(&beta1[index]);
        PDstandardNth33beta1 = PDstandardNthfdOrder433(&beta1[index]);
        PDstandardNth12beta1 = PDstandardNthfdOrder412(&beta1[index]);
        PDstandardNth13beta1 = PDstandardNthfdOrder413(&beta1[index]);
        PDstandardNth23beta1 = PDstandardNthfdOrder423(&beta1[index]);
        PDupwindNthSymm1beta1 = PDupwindNthSymmfdOrder41(&beta1[index]);
        PDupwindNthSymm2beta1 = PDupwindNthSymmfdOrder42(&beta1[index]);
        PDupwindNthSymm3beta1 = PDupwindNthSymmfdOrder43(&beta1[index]);
        PDupwindNthAnti1beta1 = PDupwindNthAntifdOrder41(&beta1[index]);
        PDupwindNthAnti2beta1 = PDupwindNthAntifdOrder42(&beta1[index]);
        PDupwindNthAnti3beta1 = PDupwindNthAntifdOrder43(&beta1[index]);
        PDdissipationNth1beta1 = PDdissipationNthfdOrder41(&beta1[index]);
        PDdissipationNth2beta1 = PDdissipationNthfdOrder42(&beta1[index]);
        PDdissipationNth3beta1 = PDdissipationNthfdOrder43(&beta1[index]);
        PDstandardNth1beta2 = PDstandardNthfdOrder41(&beta2[index]);
        PDstandardNth2beta2 = PDstandardNthfdOrder42(&beta2[index]);
        PDstandardNth3beta2 = PDstandardNthfdOrder43(&beta2[index]);
        PDstandardNth11beta2 = PDstandardNthfdOrder411(&beta2[index]);
        PDstandardNth22beta2 = PDstandardNthfdOrder422(&beta2[index]);
        PDstandardNth33beta2 = PDstandardNthfdOrder433(&beta2[index]);
        PDstandardNth12beta2 = PDstandardNthfdOrder412(&beta2[index]);
        PDstandardNth13beta2 = PDstandardNthfdOrder413(&beta2[index]);
        PDstandardNth23beta2 = PDstandardNthfdOrder423(&beta2[index]);
        PDupwindNthSymm1beta2 = PDupwindNthSymmfdOrder41(&beta2[index]);
        PDupwindNthSymm2beta2 = PDupwindNthSymmfdOrder42(&beta2[index]);
        PDupwindNthSymm3beta2 = PDupwindNthSymmfdOrder43(&beta2[index]);
        PDupwindNthAnti1beta2 = PDupwindNthAntifdOrder41(&beta2[index]);
        PDupwindNthAnti2beta2 = PDupwindNthAntifdOrder42(&beta2[index]);
        PDupwindNthAnti3beta2 = PDupwindNthAntifdOrder43(&beta2[index]);
        PDdissipationNth1beta2 = PDdissipationNthfdOrder41(&beta2[index]);
        PDdissipationNth2beta2 = PDdissipationNthfdOrder42(&beta2[index]);
        PDdissipationNth3beta2 = PDdissipationNthfdOrder43(&beta2[index]);
        PDstandardNth1beta3 = PDstandardNthfdOrder41(&beta3[index]);
        PDstandardNth2beta3 = PDstandardNthfdOrder42(&beta3[index]);
        PDstandardNth3beta3 = PDstandardNthfdOrder43(&beta3[index]);
        PDstandardNth11beta3 = PDstandardNthfdOrder411(&beta3[index]);
        PDstandardNth22beta3 = PDstandardNthfdOrder422(&beta3[index]);
        PDstandardNth33beta3 = PDstandardNthfdOrder433(&beta3[index]);
        PDstandardNth12beta3 = PDstandardNthfdOrder412(&beta3[index]);
        PDstandardNth13beta3 = PDstandardNthfdOrder413(&beta3[index]);
        PDstandardNth23beta3 = PDstandardNthfdOrder423(&beta3[index]);
        PDupwindNthSymm1beta3 = PDupwindNthSymmfdOrder41(&beta3[index]);
        PDupwindNthSymm2beta3 = PDupwindNthSymmfdOrder42(&beta3[index]);
        PDupwindNthSymm3beta3 = PDupwindNthSymmfdOrder43(&beta3[index]);
        PDupwindNthAnti1beta3 = PDupwindNthAntifdOrder41(&beta3[index]);
        PDupwindNthAnti2beta3 = PDupwindNthAntifdOrder42(&beta3[index]);
        PDupwindNthAnti3beta3 = PDupwindNthAntifdOrder43(&beta3[index]);
        PDdissipationNth1beta3 = PDdissipationNthfdOrder41(&beta3[index]);
        PDdissipationNth2beta3 = PDdissipationNthfdOrder42(&beta3[index]);
        PDdissipationNth3beta3 = PDdissipationNthfdOrder43(&beta3[index]);
        PDstandardNth1gt11 = PDstandardNthfdOrder41(&gt11[index]);
        PDstandardNth2gt11 = PDstandardNthfdOrder42(&gt11[index]);
        PDstandardNth3gt11 = PDstandardNthfdOrder43(&gt11[index]);
        PDstandardNth1gt12 = PDstandardNthfdOrder41(&gt12[index]);
        PDstandardNth2gt12 = PDstandardNthfdOrder42(&gt12[index]);
        PDstandardNth3gt12 = PDstandardNthfdOrder43(&gt12[index]);
        PDstandardNth1gt13 = PDstandardNthfdOrder41(&gt13[index]);
        PDstandardNth2gt13 = PDstandardNthfdOrder42(&gt13[index]);
        PDstandardNth3gt13 = PDstandardNthfdOrder43(&gt13[index]);
        PDstandardNth1gt22 = PDstandardNthfdOrder41(&gt22[index]);
        PDstandardNth2gt22 = PDstandardNthfdOrder42(&gt22[index]);
        PDstandardNth3gt22 = PDstandardNthfdOrder43(&gt22[index]);
        PDstandardNth1gt23 = PDstandardNthfdOrder41(&gt23[index]);
        PDstandardNth2gt23 = PDstandardNthfdOrder42(&gt23[index]);
        PDstandardNth3gt23 = PDstandardNthfdOrder43(&gt23[index]);
        PDstandardNth1gt33 = PDstandardNthfdOrder41(&gt33[index]);
        PDstandardNth2gt33 = PDstandardNthfdOrder42(&gt33[index]);
        PDstandardNth3gt33 = PDstandardNthfdOrder43(&gt33[index]);
        PDstandardNth1phi = PDstandardNthfdOrder41(&phi[index]);
        PDstandardNth2phi = PDstandardNthfdOrder42(&phi[index]);
        PDstandardNth3phi = PDstandardNthfdOrder43(&phi[index]);
        PDstandardNth1trK = PDstandardNthfdOrder41(&trK[index]);
        PDstandardNth2trK = PDstandardNthfdOrder42(&trK[index]);
        PDstandardNth3trK = PDstandardNthfdOrder43(&trK[index]);
        PDupwindNthSymm1trK = PDupwindNthSymmfdOrder41(&trK[index]);
        PDupwindNthSymm2trK = PDupwindNthSymmfdOrder42(&trK[index]);
        PDupwindNthSymm3trK = PDupwindNthSymmfdOrder43(&trK[index]);
        PDupwindNthAnti1trK = PDupwindNthAntifdOrder41(&trK[index]);
        PDupwindNthAnti2trK = PDupwindNthAntifdOrder42(&trK[index]);
        PDupwindNthAnti3trK = PDupwindNthAntifdOrder43(&trK[index]);
        PDdissipationNth1trK = PDdissipationNthfdOrder41(&trK[index]);
        PDdissipationNth2trK = PDdissipationNthfdOrder42(&trK[index]);
        PDdissipationNth3trK = PDdissipationNthfdOrder43(&trK[index]);
        PDupwindNthSymm1Xt1 = PDupwindNthSymmfdOrder41(&Xt1[index]);
        PDupwindNthSymm2Xt1 = PDupwindNthSymmfdOrder42(&Xt1[index]);
        PDupwindNthSymm3Xt1 = PDupwindNthSymmfdOrder43(&Xt1[index]);
        PDupwindNthAnti1Xt1 = PDupwindNthAntifdOrder41(&Xt1[index]);
        PDupwindNthAnti2Xt1 = PDupwindNthAntifdOrder42(&Xt1[index]);
        PDupwindNthAnti3Xt1 = PDupwindNthAntifdOrder43(&Xt1[index]);
        PDdissipationNth1Xt1 = PDdissipationNthfdOrder41(&Xt1[index]);
        PDdissipationNth2Xt1 = PDdissipationNthfdOrder42(&Xt1[index]);
        PDdissipationNth3Xt1 = PDdissipationNthfdOrder43(&Xt1[index]);
        PDupwindNthSymm1Xt2 = PDupwindNthSymmfdOrder41(&Xt2[index]);
        PDupwindNthSymm2Xt2 = PDupwindNthSymmfdOrder42(&Xt2[index]);
        PDupwindNthSymm3Xt2 = PDupwindNthSymmfdOrder43(&Xt2[index]);
        PDupwindNthAnti1Xt2 = PDupwindNthAntifdOrder41(&Xt2[index]);
        PDupwindNthAnti2Xt2 = PDupwindNthAntifdOrder42(&Xt2[index]);
        PDupwindNthAnti3Xt2 = PDupwindNthAntifdOrder43(&Xt2[index]);
        PDdissipationNth1Xt2 = PDdissipationNthfdOrder41(&Xt2[index]);
        PDdissipationNth2Xt2 = PDdissipationNthfdOrder42(&Xt2[index]);
        PDdissipationNth3Xt2 = PDdissipationNthfdOrder43(&Xt2[index]);
        PDupwindNthSymm1Xt3 = PDupwindNthSymmfdOrder41(&Xt3[index]);
        PDupwindNthSymm2Xt3 = PDupwindNthSymmfdOrder42(&Xt3[index]);
        PDupwindNthSymm3Xt3 = PDupwindNthSymmfdOrder43(&Xt3[index]);
        PDupwindNthAnti1Xt3 = PDupwindNthAntifdOrder41(&Xt3[index]);
        PDupwindNthAnti2Xt3 = PDupwindNthAntifdOrder42(&Xt3[index]);
        PDupwindNthAnti3Xt3 = PDupwindNthAntifdOrder43(&Xt3[index]);
        PDdissipationNth1Xt3 = PDdissipationNthfdOrder41(&Xt3[index]);
        PDdissipationNth2Xt3 = PDdissipationNthfdOrder42(&Xt3[index]);
        PDdissipationNth3Xt3 = PDdissipationNthfdOrder43(&Xt3[index]);
        break;
      }
      
      case 6:
      {
        PDstandardNth1alpha = PDstandardNthfdOrder61(&alpha[index]);
        PDstandardNth2alpha = PDstandardNthfdOrder62(&alpha[index]);
        PDstandardNth3alpha = PDstandardNthfdOrder63(&alpha[index]);
        PDstandardNth11alpha = PDstandardNthfdOrder611(&alpha[index]);
        PDstandardNth22alpha = PDstandardNthfdOrder622(&alpha[index]);
        PDstandardNth33alpha = PDstandardNthfdOrder633(&alpha[index]);
        PDstandardNth12alpha = PDstandardNthfdOrder612(&alpha[index]);
        PDstandardNth13alpha = PDstandardNthfdOrder613(&alpha[index]);
        PDstandardNth23alpha = PDstandardNthfdOrder623(&alpha[index]);
        PDupwindNthSymm1B1 = PDupwindNthSymmfdOrder61(&B1[index]);
        PDupwindNthSymm2B1 = PDupwindNthSymmfdOrder62(&B1[index]);
        PDupwindNthSymm3B1 = PDupwindNthSymmfdOrder63(&B1[index]);
        PDupwindNthAnti1B1 = PDupwindNthAntifdOrder61(&B1[index]);
        PDupwindNthAnti2B1 = PDupwindNthAntifdOrder62(&B1[index]);
        PDupwindNthAnti3B1 = PDupwindNthAntifdOrder63(&B1[index]);
        PDdissipationNth1B1 = PDdissipationNthfdOrder61(&B1[index]);
        PDdissipationNth2B1 = PDdissipationNthfdOrder62(&B1[index]);
        PDdissipationNth3B1 = PDdissipationNthfdOrder63(&B1[index]);
        PDupwindNthSymm1B2 = PDupwindNthSymmfdOrder61(&B2[index]);
        PDupwindNthSymm2B2 = PDupwindNthSymmfdOrder62(&B2[index]);
        PDupwindNthSymm3B2 = PDupwindNthSymmfdOrder63(&B2[index]);
        PDupwindNthAnti1B2 = PDupwindNthAntifdOrder61(&B2[index]);
        PDupwindNthAnti2B2 = PDupwindNthAntifdOrder62(&B2[index]);
        PDupwindNthAnti3B2 = PDupwindNthAntifdOrder63(&B2[index]);
        PDdissipationNth1B2 = PDdissipationNthfdOrder61(&B2[index]);
        PDdissipationNth2B2 = PDdissipationNthfdOrder62(&B2[index]);
        PDdissipationNth3B2 = PDdissipationNthfdOrder63(&B2[index]);
        PDupwindNthSymm1B3 = PDupwindNthSymmfdOrder61(&B3[index]);
        PDupwindNthSymm2B3 = PDupwindNthSymmfdOrder62(&B3[index]);
        PDupwindNthSymm3B3 = PDupwindNthSymmfdOrder63(&B3[index]);
        PDupwindNthAnti1B3 = PDupwindNthAntifdOrder61(&B3[index]);
        PDupwindNthAnti2B3 = PDupwindNthAntifdOrder62(&B3[index]);
        PDupwindNthAnti3B3 = PDupwindNthAntifdOrder63(&B3[index]);
        PDdissipationNth1B3 = PDdissipationNthfdOrder61(&B3[index]);
        PDdissipationNth2B3 = PDdissipationNthfdOrder62(&B3[index]);
        PDdissipationNth3B3 = PDdissipationNthfdOrder63(&B3[index]);
        PDstandardNth1beta1 = PDstandardNthfdOrder61(&beta1[index]);
        PDstandardNth2beta1 = PDstandardNthfdOrder62(&beta1[index]);
        PDstandardNth3beta1 = PDstandardNthfdOrder63(&beta1[index]);
        PDstandardNth11beta1 = PDstandardNthfdOrder611(&beta1[index]);
        PDstandardNth22beta1 = PDstandardNthfdOrder622(&beta1[index]);
        PDstandardNth33beta1 = PDstandardNthfdOrder633(&beta1[index]);
        PDstandardNth12beta1 = PDstandardNthfdOrder612(&beta1[index]);
        PDstandardNth13beta1 = PDstandardNthfdOrder613(&beta1[index]);
        PDstandardNth23beta1 = PDstandardNthfdOrder623(&beta1[index]);
        PDupwindNthSymm1beta1 = PDupwindNthSymmfdOrder61(&beta1[index]);
        PDupwindNthSymm2beta1 = PDupwindNthSymmfdOrder62(&beta1[index]);
        PDupwindNthSymm3beta1 = PDupwindNthSymmfdOrder63(&beta1[index]);
        PDupwindNthAnti1beta1 = PDupwindNthAntifdOrder61(&beta1[index]);
        PDupwindNthAnti2beta1 = PDupwindNthAntifdOrder62(&beta1[index]);
        PDupwindNthAnti3beta1 = PDupwindNthAntifdOrder63(&beta1[index]);
        PDdissipationNth1beta1 = PDdissipationNthfdOrder61(&beta1[index]);
        PDdissipationNth2beta1 = PDdissipationNthfdOrder62(&beta1[index]);
        PDdissipationNth3beta1 = PDdissipationNthfdOrder63(&beta1[index]);
        PDstandardNth1beta2 = PDstandardNthfdOrder61(&beta2[index]);
        PDstandardNth2beta2 = PDstandardNthfdOrder62(&beta2[index]);
        PDstandardNth3beta2 = PDstandardNthfdOrder63(&beta2[index]);
        PDstandardNth11beta2 = PDstandardNthfdOrder611(&beta2[index]);
        PDstandardNth22beta2 = PDstandardNthfdOrder622(&beta2[index]);
        PDstandardNth33beta2 = PDstandardNthfdOrder633(&beta2[index]);
        PDstandardNth12beta2 = PDstandardNthfdOrder612(&beta2[index]);
        PDstandardNth13beta2 = PDstandardNthfdOrder613(&beta2[index]);
        PDstandardNth23beta2 = PDstandardNthfdOrder623(&beta2[index]);
        PDupwindNthSymm1beta2 = PDupwindNthSymmfdOrder61(&beta2[index]);
        PDupwindNthSymm2beta2 = PDupwindNthSymmfdOrder62(&beta2[index]);
        PDupwindNthSymm3beta2 = PDupwindNthSymmfdOrder63(&beta2[index]);
        PDupwindNthAnti1beta2 = PDupwindNthAntifdOrder61(&beta2[index]);
        PDupwindNthAnti2beta2 = PDupwindNthAntifdOrder62(&beta2[index]);
        PDupwindNthAnti3beta2 = PDupwindNthAntifdOrder63(&beta2[index]);
        PDdissipationNth1beta2 = PDdissipationNthfdOrder61(&beta2[index]);
        PDdissipationNth2beta2 = PDdissipationNthfdOrder62(&beta2[index]);
        PDdissipationNth3beta2 = PDdissipationNthfdOrder63(&beta2[index]);
        PDstandardNth1beta3 = PDstandardNthfdOrder61(&beta3[index]);
        PDstandardNth2beta3 = PDstandardNthfdOrder62(&beta3[index]);
        PDstandardNth3beta3 = PDstandardNthfdOrder63(&beta3[index]);
        PDstandardNth11beta3 = PDstandardNthfdOrder611(&beta3[index]);
        PDstandardNth22beta3 = PDstandardNthfdOrder622(&beta3[index]);
        PDstandardNth33beta3 = PDstandardNthfdOrder633(&beta3[index]);
        PDstandardNth12beta3 = PDstandardNthfdOrder612(&beta3[index]);
        PDstandardNth13beta3 = PDstandardNthfdOrder613(&beta3[index]);
        PDstandardNth23beta3 = PDstandardNthfdOrder623(&beta3[index]);
        PDupwindNthSymm1beta3 = PDupwindNthSymmfdOrder61(&beta3[index]);
        PDupwindNthSymm2beta3 = PDupwindNthSymmfdOrder62(&beta3[index]);
        PDupwindNthSymm3beta3 = PDupwindNthSymmfdOrder63(&beta3[index]);
        PDupwindNthAnti1beta3 = PDupwindNthAntifdOrder61(&beta3[index]);
        PDupwindNthAnti2beta3 = PDupwindNthAntifdOrder62(&beta3[index]);
        PDupwindNthAnti3beta3 = PDupwindNthAntifdOrder63(&beta3[index]);
        PDdissipationNth1beta3 = PDdissipationNthfdOrder61(&beta3[index]);
        PDdissipationNth2beta3 = PDdissipationNthfdOrder62(&beta3[index]);
        PDdissipationNth3beta3 = PDdissipationNthfdOrder63(&beta3[index]);
        PDstandardNth1gt11 = PDstandardNthfdOrder61(&gt11[index]);
        PDstandardNth2gt11 = PDstandardNthfdOrder62(&gt11[index]);
        PDstandardNth3gt11 = PDstandardNthfdOrder63(&gt11[index]);
        PDstandardNth1gt12 = PDstandardNthfdOrder61(&gt12[index]);
        PDstandardNth2gt12 = PDstandardNthfdOrder62(&gt12[index]);
        PDstandardNth3gt12 = PDstandardNthfdOrder63(&gt12[index]);
        PDstandardNth1gt13 = PDstandardNthfdOrder61(&gt13[index]);
        PDstandardNth2gt13 = PDstandardNthfdOrder62(&gt13[index]);
        PDstandardNth3gt13 = PDstandardNthfdOrder63(&gt13[index]);
        PDstandardNth1gt22 = PDstandardNthfdOrder61(&gt22[index]);
        PDstandardNth2gt22 = PDstandardNthfdOrder62(&gt22[index]);
        PDstandardNth3gt22 = PDstandardNthfdOrder63(&gt22[index]);
        PDstandardNth1gt23 = PDstandardNthfdOrder61(&gt23[index]);
        PDstandardNth2gt23 = PDstandardNthfdOrder62(&gt23[index]);
        PDstandardNth3gt23 = PDstandardNthfdOrder63(&gt23[index]);
        PDstandardNth1gt33 = PDstandardNthfdOrder61(&gt33[index]);
        PDstandardNth2gt33 = PDstandardNthfdOrder62(&gt33[index]);
        PDstandardNth3gt33 = PDstandardNthfdOrder63(&gt33[index]);
        PDstandardNth1phi = PDstandardNthfdOrder61(&phi[index]);
        PDstandardNth2phi = PDstandardNthfdOrder62(&phi[index]);
        PDstandardNth3phi = PDstandardNthfdOrder63(&phi[index]);
        PDstandardNth1trK = PDstandardNthfdOrder61(&trK[index]);
        PDstandardNth2trK = PDstandardNthfdOrder62(&trK[index]);
        PDstandardNth3trK = PDstandardNthfdOrder63(&trK[index]);
        PDupwindNthSymm1trK = PDupwindNthSymmfdOrder61(&trK[index]);
        PDupwindNthSymm2trK = PDupwindNthSymmfdOrder62(&trK[index]);
        PDupwindNthSymm3trK = PDupwindNthSymmfdOrder63(&trK[index]);
        PDupwindNthAnti1trK = PDupwindNthAntifdOrder61(&trK[index]);
        PDupwindNthAnti2trK = PDupwindNthAntifdOrder62(&trK[index]);
        PDupwindNthAnti3trK = PDupwindNthAntifdOrder63(&trK[index]);
        PDdissipationNth1trK = PDdissipationNthfdOrder61(&trK[index]);
        PDdissipationNth2trK = PDdissipationNthfdOrder62(&trK[index]);
        PDdissipationNth3trK = PDdissipationNthfdOrder63(&trK[index]);
        PDupwindNthSymm1Xt1 = PDupwindNthSymmfdOrder61(&Xt1[index]);
        PDupwindNthSymm2Xt1 = PDupwindNthSymmfdOrder62(&Xt1[index]);
        PDupwindNthSymm3Xt1 = PDupwindNthSymmfdOrder63(&Xt1[index]);
        PDupwindNthAnti1Xt1 = PDupwindNthAntifdOrder61(&Xt1[index]);
        PDupwindNthAnti2Xt1 = PDupwindNthAntifdOrder62(&Xt1[index]);
        PDupwindNthAnti3Xt1 = PDupwindNthAntifdOrder63(&Xt1[index]);
        PDdissipationNth1Xt1 = PDdissipationNthfdOrder61(&Xt1[index]);
        PDdissipationNth2Xt1 = PDdissipationNthfdOrder62(&Xt1[index]);
        PDdissipationNth3Xt1 = PDdissipationNthfdOrder63(&Xt1[index]);
        PDupwindNthSymm1Xt2 = PDupwindNthSymmfdOrder61(&Xt2[index]);
        PDupwindNthSymm2Xt2 = PDupwindNthSymmfdOrder62(&Xt2[index]);
        PDupwindNthSymm3Xt2 = PDupwindNthSymmfdOrder63(&Xt2[index]);
        PDupwindNthAnti1Xt2 = PDupwindNthAntifdOrder61(&Xt2[index]);
        PDupwindNthAnti2Xt2 = PDupwindNthAntifdOrder62(&Xt2[index]);
        PDupwindNthAnti3Xt2 = PDupwindNthAntifdOrder63(&Xt2[index]);
        PDdissipationNth1Xt2 = PDdissipationNthfdOrder61(&Xt2[index]);
        PDdissipationNth2Xt2 = PDdissipationNthfdOrder62(&Xt2[index]);
        PDdissipationNth3Xt2 = PDdissipationNthfdOrder63(&Xt2[index]);
        PDupwindNthSymm1Xt3 = PDupwindNthSymmfdOrder61(&Xt3[index]);
        PDupwindNthSymm2Xt3 = PDupwindNthSymmfdOrder62(&Xt3[index]);
        PDupwindNthSymm3Xt3 = PDupwindNthSymmfdOrder63(&Xt3[index]);
        PDupwindNthAnti1Xt3 = PDupwindNthAntifdOrder61(&Xt3[index]);
        PDupwindNthAnti2Xt3 = PDupwindNthAntifdOrder62(&Xt3[index]);
        PDupwindNthAnti3Xt3 = PDupwindNthAntifdOrder63(&Xt3[index]);
        PDdissipationNth1Xt3 = PDdissipationNthfdOrder61(&Xt3[index]);
        PDdissipationNth2Xt3 = PDdissipationNthfdOrder62(&Xt3[index]);
        PDdissipationNth3Xt3 = PDdissipationNthfdOrder63(&Xt3[index]);
        break;
      }
      
      case 8:
      {
        PDstandardNth1alpha = PDstandardNthfdOrder81(&alpha[index]);
        PDstandardNth2alpha = PDstandardNthfdOrder82(&alpha[index]);
        PDstandardNth3alpha = PDstandardNthfdOrder83(&alpha[index]);
        PDstandardNth11alpha = PDstandardNthfdOrder811(&alpha[index]);
        PDstandardNth22alpha = PDstandardNthfdOrder822(&alpha[index]);
        PDstandardNth33alpha = PDstandardNthfdOrder833(&alpha[index]);
        PDstandardNth12alpha = PDstandardNthfdOrder812(&alpha[index]);
        PDstandardNth13alpha = PDstandardNthfdOrder813(&alpha[index]);
        PDstandardNth23alpha = PDstandardNthfdOrder823(&alpha[index]);
        PDupwindNthSymm1B1 = PDupwindNthSymmfdOrder81(&B1[index]);
        PDupwindNthSymm2B1 = PDupwindNthSymmfdOrder82(&B1[index]);
        PDupwindNthSymm3B1 = PDupwindNthSymmfdOrder83(&B1[index]);
        PDupwindNthAnti1B1 = PDupwindNthAntifdOrder81(&B1[index]);
        PDupwindNthAnti2B1 = PDupwindNthAntifdOrder82(&B1[index]);
        PDupwindNthAnti3B1 = PDupwindNthAntifdOrder83(&B1[index]);
        PDdissipationNth1B1 = PDdissipationNthfdOrder81(&B1[index]);
        PDdissipationNth2B1 = PDdissipationNthfdOrder82(&B1[index]);
        PDdissipationNth3B1 = PDdissipationNthfdOrder83(&B1[index]);
        PDupwindNthSymm1B2 = PDupwindNthSymmfdOrder81(&B2[index]);
        PDupwindNthSymm2B2 = PDupwindNthSymmfdOrder82(&B2[index]);
        PDupwindNthSymm3B2 = PDupwindNthSymmfdOrder83(&B2[index]);
        PDupwindNthAnti1B2 = PDupwindNthAntifdOrder81(&B2[index]);
        PDupwindNthAnti2B2 = PDupwindNthAntifdOrder82(&B2[index]);
        PDupwindNthAnti3B2 = PDupwindNthAntifdOrder83(&B2[index]);
        PDdissipationNth1B2 = PDdissipationNthfdOrder81(&B2[index]);
        PDdissipationNth2B2 = PDdissipationNthfdOrder82(&B2[index]);
        PDdissipationNth3B2 = PDdissipationNthfdOrder83(&B2[index]);
        PDupwindNthSymm1B3 = PDupwindNthSymmfdOrder81(&B3[index]);
        PDupwindNthSymm2B3 = PDupwindNthSymmfdOrder82(&B3[index]);
        PDupwindNthSymm3B3 = PDupwindNthSymmfdOrder83(&B3[index]);
        PDupwindNthAnti1B3 = PDupwindNthAntifdOrder81(&B3[index]);
        PDupwindNthAnti2B3 = PDupwindNthAntifdOrder82(&B3[index]);
        PDupwindNthAnti3B3 = PDupwindNthAntifdOrder83(&B3[index]);
        PDdissipationNth1B3 = PDdissipationNthfdOrder81(&B3[index]);
        PDdissipationNth2B3 = PDdissipationNthfdOrder82(&B3[index]);
        PDdissipationNth3B3 = PDdissipationNthfdOrder83(&B3[index]);
        PDstandardNth1beta1 = PDstandardNthfdOrder81(&beta1[index]);
        PDstandardNth2beta1 = PDstandardNthfdOrder82(&beta1[index]);
        PDstandardNth3beta1 = PDstandardNthfdOrder83(&beta1[index]);
        PDstandardNth11beta1 = PDstandardNthfdOrder811(&beta1[index]);
        PDstandardNth22beta1 = PDstandardNthfdOrder822(&beta1[index]);
        PDstandardNth33beta1 = PDstandardNthfdOrder833(&beta1[index]);
        PDstandardNth12beta1 = PDstandardNthfdOrder812(&beta1[index]);
        PDstandardNth13beta1 = PDstandardNthfdOrder813(&beta1[index]);
        PDstandardNth23beta1 = PDstandardNthfdOrder823(&beta1[index]);
        PDupwindNthSymm1beta1 = PDupwindNthSymmfdOrder81(&beta1[index]);
        PDupwindNthSymm2beta1 = PDupwindNthSymmfdOrder82(&beta1[index]);
        PDupwindNthSymm3beta1 = PDupwindNthSymmfdOrder83(&beta1[index]);
        PDupwindNthAnti1beta1 = PDupwindNthAntifdOrder81(&beta1[index]);
        PDupwindNthAnti2beta1 = PDupwindNthAntifdOrder82(&beta1[index]);
        PDupwindNthAnti3beta1 = PDupwindNthAntifdOrder83(&beta1[index]);
        PDdissipationNth1beta1 = PDdissipationNthfdOrder81(&beta1[index]);
        PDdissipationNth2beta1 = PDdissipationNthfdOrder82(&beta1[index]);
        PDdissipationNth3beta1 = PDdissipationNthfdOrder83(&beta1[index]);
        PDstandardNth1beta2 = PDstandardNthfdOrder81(&beta2[index]);
        PDstandardNth2beta2 = PDstandardNthfdOrder82(&beta2[index]);
        PDstandardNth3beta2 = PDstandardNthfdOrder83(&beta2[index]);
        PDstandardNth11beta2 = PDstandardNthfdOrder811(&beta2[index]);
        PDstandardNth22beta2 = PDstandardNthfdOrder822(&beta2[index]);
        PDstandardNth33beta2 = PDstandardNthfdOrder833(&beta2[index]);
        PDstandardNth12beta2 = PDstandardNthfdOrder812(&beta2[index]);
        PDstandardNth13beta2 = PDstandardNthfdOrder813(&beta2[index]);
        PDstandardNth23beta2 = PDstandardNthfdOrder823(&beta2[index]);
        PDupwindNthSymm1beta2 = PDupwindNthSymmfdOrder81(&beta2[index]);
        PDupwindNthSymm2beta2 = PDupwindNthSymmfdOrder82(&beta2[index]);
        PDupwindNthSymm3beta2 = PDupwindNthSymmfdOrder83(&beta2[index]);
        PDupwindNthAnti1beta2 = PDupwindNthAntifdOrder81(&beta2[index]);
        PDupwindNthAnti2beta2 = PDupwindNthAntifdOrder82(&beta2[index]);
        PDupwindNthAnti3beta2 = PDupwindNthAntifdOrder83(&beta2[index]);
        PDdissipationNth1beta2 = PDdissipationNthfdOrder81(&beta2[index]);
        PDdissipationNth2beta2 = PDdissipationNthfdOrder82(&beta2[index]);
        PDdissipationNth3beta2 = PDdissipationNthfdOrder83(&beta2[index]);
        PDstandardNth1beta3 = PDstandardNthfdOrder81(&beta3[index]);
        PDstandardNth2beta3 = PDstandardNthfdOrder82(&beta3[index]);
        PDstandardNth3beta3 = PDstandardNthfdOrder83(&beta3[index]);
        PDstandardNth11beta3 = PDstandardNthfdOrder811(&beta3[index]);
        PDstandardNth22beta3 = PDstandardNthfdOrder822(&beta3[index]);
        PDstandardNth33beta3 = PDstandardNthfdOrder833(&beta3[index]);
        PDstandardNth12beta3 = PDstandardNthfdOrder812(&beta3[index]);
        PDstandardNth13beta3 = PDstandardNthfdOrder813(&beta3[index]);
        PDstandardNth23beta3 = PDstandardNthfdOrder823(&beta3[index]);
        PDupwindNthSymm1beta3 = PDupwindNthSymmfdOrder81(&beta3[index]);
        PDupwindNthSymm2beta3 = PDupwindNthSymmfdOrder82(&beta3[index]);
        PDupwindNthSymm3beta3 = PDupwindNthSymmfdOrder83(&beta3[index]);
        PDupwindNthAnti1beta3 = PDupwindNthAntifdOrder81(&beta3[index]);
        PDupwindNthAnti2beta3 = PDupwindNthAntifdOrder82(&beta3[index]);
        PDupwindNthAnti3beta3 = PDupwindNthAntifdOrder83(&beta3[index]);
        PDdissipationNth1beta3 = PDdissipationNthfdOrder81(&beta3[index]);
        PDdissipationNth2beta3 = PDdissipationNthfdOrder82(&beta3[index]);
        PDdissipationNth3beta3 = PDdissipationNthfdOrder83(&beta3[index]);
        PDstandardNth1gt11 = PDstandardNthfdOrder81(&gt11[index]);
        PDstandardNth2gt11 = PDstandardNthfdOrder82(&gt11[index]);
        PDstandardNth3gt11 = PDstandardNthfdOrder83(&gt11[index]);
        PDstandardNth1gt12 = PDstandardNthfdOrder81(&gt12[index]);
        PDstandardNth2gt12 = PDstandardNthfdOrder82(&gt12[index]);
        PDstandardNth3gt12 = PDstandardNthfdOrder83(&gt12[index]);
        PDstandardNth1gt13 = PDstandardNthfdOrder81(&gt13[index]);
        PDstandardNth2gt13 = PDstandardNthfdOrder82(&gt13[index]);
        PDstandardNth3gt13 = PDstandardNthfdOrder83(&gt13[index]);
        PDstandardNth1gt22 = PDstandardNthfdOrder81(&gt22[index]);
        PDstandardNth2gt22 = PDstandardNthfdOrder82(&gt22[index]);
        PDstandardNth3gt22 = PDstandardNthfdOrder83(&gt22[index]);
        PDstandardNth1gt23 = PDstandardNthfdOrder81(&gt23[index]);
        PDstandardNth2gt23 = PDstandardNthfdOrder82(&gt23[index]);
        PDstandardNth3gt23 = PDstandardNthfdOrder83(&gt23[index]);
        PDstandardNth1gt33 = PDstandardNthfdOrder81(&gt33[index]);
        PDstandardNth2gt33 = PDstandardNthfdOrder82(&gt33[index]);
        PDstandardNth3gt33 = PDstandardNthfdOrder83(&gt33[index]);
        PDstandardNth1phi = PDstandardNthfdOrder81(&phi[index]);
        PDstandardNth2phi = PDstandardNthfdOrder82(&phi[index]);
        PDstandardNth3phi = PDstandardNthfdOrder83(&phi[index]);
        PDstandardNth1trK = PDstandardNthfdOrder81(&trK[index]);
        PDstandardNth2trK = PDstandardNthfdOrder82(&trK[index]);
        PDstandardNth3trK = PDstandardNthfdOrder83(&trK[index]);
        PDupwindNthSymm1trK = PDupwindNthSymmfdOrder81(&trK[index]);
        PDupwindNthSymm2trK = PDupwindNthSymmfdOrder82(&trK[index]);
        PDupwindNthSymm3trK = PDupwindNthSymmfdOrder83(&trK[index]);
        PDupwindNthAnti1trK = PDupwindNthAntifdOrder81(&trK[index]);
        PDupwindNthAnti2trK = PDupwindNthAntifdOrder82(&trK[index]);
        PDupwindNthAnti3trK = PDupwindNthAntifdOrder83(&trK[index]);
        PDdissipationNth1trK = PDdissipationNthfdOrder81(&trK[index]);
        PDdissipationNth2trK = PDdissipationNthfdOrder82(&trK[index]);
        PDdissipationNth3trK = PDdissipationNthfdOrder83(&trK[index]);
        PDupwindNthSymm1Xt1 = PDupwindNthSymmfdOrder81(&Xt1[index]);
        PDupwindNthSymm2Xt1 = PDupwindNthSymmfdOrder82(&Xt1[index]);
        PDupwindNthSymm3Xt1 = PDupwindNthSymmfdOrder83(&Xt1[index]);
        PDupwindNthAnti1Xt1 = PDupwindNthAntifdOrder81(&Xt1[index]);
        PDupwindNthAnti2Xt1 = PDupwindNthAntifdOrder82(&Xt1[index]);
        PDupwindNthAnti3Xt1 = PDupwindNthAntifdOrder83(&Xt1[index]);
        PDdissipationNth1Xt1 = PDdissipationNthfdOrder81(&Xt1[index]);
        PDdissipationNth2Xt1 = PDdissipationNthfdOrder82(&Xt1[index]);
        PDdissipationNth3Xt1 = PDdissipationNthfdOrder83(&Xt1[index]);
        PDupwindNthSymm1Xt2 = PDupwindNthSymmfdOrder81(&Xt2[index]);
        PDupwindNthSymm2Xt2 = PDupwindNthSymmfdOrder82(&Xt2[index]);
        PDupwindNthSymm3Xt2 = PDupwindNthSymmfdOrder83(&Xt2[index]);
        PDupwindNthAnti1Xt2 = PDupwindNthAntifdOrder81(&Xt2[index]);
        PDupwindNthAnti2Xt2 = PDupwindNthAntifdOrder82(&Xt2[index]);
        PDupwindNthAnti3Xt2 = PDupwindNthAntifdOrder83(&Xt2[index]);
        PDdissipationNth1Xt2 = PDdissipationNthfdOrder81(&Xt2[index]);
        PDdissipationNth2Xt2 = PDdissipationNthfdOrder82(&Xt2[index]);
        PDdissipationNth3Xt2 = PDdissipationNthfdOrder83(&Xt2[index]);
        PDupwindNthSymm1Xt3 = PDupwindNthSymmfdOrder81(&Xt3[index]);
        PDupwindNthSymm2Xt3 = PDupwindNthSymmfdOrder82(&Xt3[index]);
        PDupwindNthSymm3Xt3 = PDupwindNthSymmfdOrder83(&Xt3[index]);
        PDupwindNthAnti1Xt3 = PDupwindNthAntifdOrder81(&Xt3[index]);
        PDupwindNthAnti2Xt3 = PDupwindNthAntifdOrder82(&Xt3[index]);
        PDupwindNthAnti3Xt3 = PDupwindNthAntifdOrder83(&Xt3[index]);
        PDdissipationNth1Xt3 = PDdissipationNthfdOrder81(&Xt3[index]);
        PDdissipationNth2Xt3 = PDdissipationNthfdOrder82(&Xt3[index]);
        PDdissipationNth3Xt3 = PDdissipationNthfdOrder83(&Xt3[index]);
        break;
      }
      default:
        CCTK_BUILTIN_UNREACHABLE();
    }
    /* Calculate temporaries and grid functions */
    CCTK_REAL epsdiss1 CCTK_ATTRIBUTE_UNUSED = epsDiss;
    
    CCTK_REAL epsdiss2 CCTK_ATTRIBUTE_UNUSED = epsDiss;
    
    CCTK_REAL epsdiss3 CCTK_ATTRIBUTE_UNUSED = epsDiss;
    
    CCTK_REAL detgt CCTK_ATTRIBUTE_UNUSED = 1;
    
    CCTK_REAL gtu11 CCTK_ATTRIBUTE_UNUSED = (gt22L*gt33L - 
      pow(gt23L,2))*pow(detgt,-1);
    
    CCTK_REAL gtu12 CCTK_ATTRIBUTE_UNUSED = (gt13L*gt23L - 
      gt12L*gt33L)*pow(detgt,-1);
    
    CCTK_REAL gtu13 CCTK_ATTRIBUTE_UNUSED = (-(gt13L*gt22L) + 
      gt12L*gt23L)*pow(detgt,-1);
    
    CCTK_REAL gtu22 CCTK_ATTRIBUTE_UNUSED = (gt11L*gt33L - 
      pow(gt13L,2))*pow(detgt,-1);
    
    CCTK_REAL gtu23 CCTK_ATTRIBUTE_UNUSED = (gt12L*gt13L - 
      gt11L*gt23L)*pow(detgt,-1);
    
    CCTK_REAL gtu33 CCTK_ATTRIBUTE_UNUSED = (gt11L*gt22L - 
      pow(gt12L,2))*pow(detgt,-1);
    
    CCTK_REAL Gtl111 CCTK_ATTRIBUTE_UNUSED = 0.5*PDstandardNth1gt11;
    
    CCTK_REAL Gtl112 CCTK_ATTRIBUTE_UNUSED = 0.5*PDstandardNth2gt11;
    
    CCTK_REAL Gtl113 CCTK_ATTRIBUTE_UNUSED = 0.5*PDstandardNth3gt11;
    
    CCTK_REAL Gtl122 CCTK_ATTRIBUTE_UNUSED = -0.5*PDstandardNth1gt22 + 
      PDstandardNth2gt12;
    
    CCTK_REAL Gtl123 CCTK_ATTRIBUTE_UNUSED = 0.5*(-PDstandardNth1gt23 + 
      PDstandardNth2gt13 + PDstandardNth3gt12);
    
    CCTK_REAL Gtl133 CCTK_ATTRIBUTE_UNUSED = -0.5*PDstandardNth1gt33 + 
      PDstandardNth3gt13;
    
    CCTK_REAL Gtl211 CCTK_ATTRIBUTE_UNUSED = PDstandardNth1gt12 - 
      0.5*PDstandardNth2gt11;
    
    CCTK_REAL Gtl212 CCTK_ATTRIBUTE_UNUSED = 0.5*PDstandardNth1gt22;
    
    CCTK_REAL Gtl213 CCTK_ATTRIBUTE_UNUSED = 0.5*(PDstandardNth1gt23 - 
      PDstandardNth2gt13 + PDstandardNth3gt12);
    
    CCTK_REAL Gtl222 CCTK_ATTRIBUTE_UNUSED = 0.5*PDstandardNth2gt22;
    
    CCTK_REAL Gtl223 CCTK_ATTRIBUTE_UNUSED = 0.5*PDstandardNth3gt22;
    
    CCTK_REAL Gtl233 CCTK_ATTRIBUTE_UNUSED = -0.5*PDstandardNth2gt33 + 
      PDstandardNth3gt23;
    
    CCTK_REAL Gtl311 CCTK_ATTRIBUTE_UNUSED = PDstandardNth1gt13 - 
      0.5*PDstandardNth3gt11;
    
    CCTK_REAL Gtl312 CCTK_ATTRIBUTE_UNUSED = 0.5*(PDstandardNth1gt23 + 
      PDstandardNth2gt13 - PDstandardNth3gt12);
    
    CCTK_REAL Gtl313 CCTK_ATTRIBUTE_UNUSED = 0.5*PDstandardNth1gt33;
    
    CCTK_REAL Gtl322 CCTK_ATTRIBUTE_UNUSED = PDstandardNth2gt23 - 
      0.5*PDstandardNth3gt22;
    
    CCTK_REAL Gtl323 CCTK_ATTRIBUTE_UNUSED = 0.5*PDstandardNth2gt33;
    
    CCTK_REAL Gtl333 CCTK_ATTRIBUTE_UNUSED = 0.5*PDstandardNth3gt33;
    
    CCTK_REAL Gt111 CCTK_ATTRIBUTE_UNUSED = Gtl111*gtu11 + Gtl211*gtu12 + 
      Gtl311*gtu13;
    
    CCTK_REAL Gt211 CCTK_ATTRIBUTE_UNUSED = Gtl111*gtu12 + Gtl211*gtu22 + 
      Gtl311*gtu23;
    
    CCTK_REAL Gt311 CCTK_ATTRIBUTE_UNUSED = Gtl111*gtu13 + Gtl211*gtu23 + 
      Gtl311*gtu33;
    
    CCTK_REAL Gt112 CCTK_ATTRIBUTE_UNUSED = Gtl112*gtu11 + Gtl212*gtu12 + 
      Gtl312*gtu13;
    
    CCTK_REAL Gt212 CCTK_ATTRIBUTE_UNUSED = Gtl112*gtu12 + Gtl212*gtu22 + 
      Gtl312*gtu23;
    
    CCTK_REAL Gt312 CCTK_ATTRIBUTE_UNUSED = Gtl112*gtu13 + Gtl212*gtu23 + 
      Gtl312*gtu33;
    
    CCTK_REAL Gt113 CCTK_ATTRIBUTE_UNUSED = Gtl113*gtu11 + Gtl213*gtu12 + 
      Gtl313*gtu13;
    
    CCTK_REAL Gt213 CCTK_ATTRIBUTE_UNUSED = Gtl113*gtu12 + Gtl213*gtu22 + 
      Gtl313*gtu23;
    
    CCTK_REAL Gt313 CCTK_ATTRIBUTE_UNUSED = Gtl113*gtu13 + Gtl213*gtu23 + 
      Gtl313*gtu33;
    
    CCTK_REAL Gt122 CCTK_ATTRIBUTE_UNUSED = Gtl122*gtu11 + Gtl222*gtu12 + 
      Gtl322*gtu13;
    
    CCTK_REAL Gt222 CCTK_ATTRIBUTE_UNUSED = Gtl122*gtu12 + Gtl222*gtu22 + 
      Gtl322*gtu23;
    
    CCTK_REAL Gt322 CCTK_ATTRIBUTE_UNUSED = Gtl122*gtu13 + Gtl222*gtu23 + 
      Gtl322*gtu33;
    
    CCTK_REAL Gt123 CCTK_ATTRIBUTE_UNUSED = Gtl123*gtu11 + Gtl223*gtu12 + 
      Gtl323*gtu13;
    
    CCTK_REAL Gt223 CCTK_ATTRIBUTE_UNUSED = Gtl123*gtu12 + Gtl223*gtu22 + 
      Gtl323*gtu23;
    
    CCTK_REAL Gt323 CCTK_ATTRIBUTE_UNUSED = Gtl123*gtu13 + Gtl223*gtu23 + 
      Gtl323*gtu33;
    
    CCTK_REAL Gt133 CCTK_ATTRIBUTE_UNUSED = Gtl133*gtu11 + Gtl233*gtu12 + 
      Gtl333*gtu13;
    
    CCTK_REAL Gt233 CCTK_ATTRIBUTE_UNUSED = Gtl133*gtu12 + Gtl233*gtu22 + 
      Gtl333*gtu23;
    
    CCTK_REAL Gt333 CCTK_ATTRIBUTE_UNUSED = Gtl133*gtu13 + Gtl233*gtu23 + 
      Gtl333*gtu33;
    
    CCTK_REAL em4phi CCTK_ATTRIBUTE_UNUSED = IfThen(conformalMethod != 
      0,pow(phiL,2),exp(-4*phiL));
    
    CCTK_REAL gu11 CCTK_ATTRIBUTE_UNUSED = em4phi*gtu11;
    
    CCTK_REAL gu12 CCTK_ATTRIBUTE_UNUSED = em4phi*gtu12;
    
    CCTK_REAL gu13 CCTK_ATTRIBUTE_UNUSED = em4phi*gtu13;
    
    CCTK_REAL gu22 CCTK_ATTRIBUTE_UNUSED = em4phi*gtu22;
    
    CCTK_REAL gu23 CCTK_ATTRIBUTE_UNUSED = em4phi*gtu23;
    
    CCTK_REAL gu33 CCTK_ATTRIBUTE_UNUSED = em4phi*gtu33;
    
    CCTK_REAL Xtn1 CCTK_ATTRIBUTE_UNUSED = Gt111*gtu11 + Gt122*gtu22 + 
      2*(Gt112*gtu12 + Gt113*gtu13 + Gt123*gtu23) + Gt133*gtu33;
    
    CCTK_REAL Xtn2 CCTK_ATTRIBUTE_UNUSED = Gt211*gtu11 + Gt222*gtu22 + 
      2*(Gt212*gtu12 + Gt213*gtu13 + Gt223*gtu23) + Gt233*gtu33;
    
    CCTK_REAL Xtn3 CCTK_ATTRIBUTE_UNUSED = Gt311*gtu11 + Gt322*gtu22 + 
      2*(Gt312*gtu12 + Gt313*gtu13 + Gt323*gtu23) + Gt333*gtu33;
    
    CCTK_REAL fac1 CCTK_ATTRIBUTE_UNUSED = IfThen(conformalMethod != 
      0,-0.5*pow(phiL,-1),1);
    
    CCTK_REAL cdphi1 CCTK_ATTRIBUTE_UNUSED = fac1*PDstandardNth1phi;
    
    CCTK_REAL cdphi2 CCTK_ATTRIBUTE_UNUSED = fac1*PDstandardNth2phi;
    
    CCTK_REAL cdphi3 CCTK_ATTRIBUTE_UNUSED = fac1*PDstandardNth3phi;
    
    CCTK_REAL Atm11 CCTK_ATTRIBUTE_UNUSED = At11L*gtu11 + At12L*gtu12 + 
      At13L*gtu13;
    
    CCTK_REAL Atm21 CCTK_ATTRIBUTE_UNUSED = At11L*gtu12 + At12L*gtu22 + 
      At13L*gtu23;
    
    CCTK_REAL Atm31 CCTK_ATTRIBUTE_UNUSED = At11L*gtu13 + At12L*gtu23 + 
      At13L*gtu33;
    
    CCTK_REAL Atm12 CCTK_ATTRIBUTE_UNUSED = At12L*gtu11 + At22L*gtu12 + 
      At23L*gtu13;
    
    CCTK_REAL Atm22 CCTK_ATTRIBUTE_UNUSED = At12L*gtu12 + At22L*gtu22 + 
      At23L*gtu23;
    
    CCTK_REAL Atm32 CCTK_ATTRIBUTE_UNUSED = At12L*gtu13 + At22L*gtu23 + 
      At23L*gtu33;
    
    CCTK_REAL Atm13 CCTK_ATTRIBUTE_UNUSED = At13L*gtu11 + At23L*gtu12 + 
      At33L*gtu13;
    
    CCTK_REAL Atm23 CCTK_ATTRIBUTE_UNUSED = At13L*gtu12 + At23L*gtu22 + 
      At33L*gtu23;
    
    CCTK_REAL Atm33 CCTK_ATTRIBUTE_UNUSED = At13L*gtu13 + At23L*gtu23 + 
      At33L*gtu33;
    
    CCTK_REAL Atu11 CCTK_ATTRIBUTE_UNUSED = Atm11*gtu11 + Atm12*gtu12 + 
      Atm13*gtu13;
    
    CCTK_REAL Atu12 CCTK_ATTRIBUTE_UNUSED = Atm11*gtu12 + Atm12*gtu22 + 
      Atm13*gtu23;
    
    CCTK_REAL Atu13 CCTK_ATTRIBUTE_UNUSED = Atm11*gtu13 + Atm12*gtu23 + 
      Atm13*gtu33;
    
    CCTK_REAL Atu22 CCTK_ATTRIBUTE_UNUSED = Atm21*gtu12 + Atm22*gtu22 + 
      Atm23*gtu23;
    
    CCTK_REAL Atu23 CCTK_ATTRIBUTE_UNUSED = Atm21*gtu13 + Atm22*gtu23 + 
      Atm23*gtu33;
    
    CCTK_REAL Atu33 CCTK_ATTRIBUTE_UNUSED = Atm31*gtu13 + Atm32*gtu23 + 
      Atm33*gtu33;
    
    CCTK_REAL dotXt1 CCTK_ATTRIBUTE_UNUSED = gtu11*PDstandardNth11beta1 + 
      gtu22*PDstandardNth22beta1 + gtu33*PDstandardNth33beta1 + 
      0.333333333333333333333333333333*(gtu11*(PDstandardNth11beta1 + 
      PDstandardNth12beta2 + PDstandardNth13beta3) + 
      gtu12*(PDstandardNth12beta1 + PDstandardNth22beta2 + 
      PDstandardNth23beta3) + gtu13*(PDstandardNth13beta1 + 
      PDstandardNth23beta2 + PDstandardNth33beta3)) - 
      2*(Atu11*PDstandardNth1alpha + Atu12*PDstandardNth2alpha + 
      Atu13*PDstandardNth3alpha) + 2*(gtu12*PDstandardNth12beta1 + 
      gtu13*PDstandardNth13beta1 + gtu23*PDstandardNth23beta1 + 
      alphaL*(6*(Atu11*cdphi1 + Atu12*cdphi2 + Atu13*cdphi3) + Atu11*Gt111 + 
      2*Atu12*Gt112 + 2*Atu13*Gt113 + Atu22*Gt122 + 2*Atu23*Gt123 + 
      Atu33*Gt133 - 0.666666666666666666666666666667*(gtu11*PDstandardNth1trK 
      + gtu12*PDstandardNth2trK + gtu13*PDstandardNth3trK))) + 
      (-PDstandardNth1beta1 + 
      0.666666666666666666666666666667*(PDstandardNth1beta1 + 
      PDstandardNth2beta2 + PDstandardNth3beta3))*Xtn1 - 
      PDstandardNth2beta1*Xtn2 - PDstandardNth3beta1*Xtn3;
    
    CCTK_REAL dotXt2 CCTK_ATTRIBUTE_UNUSED = gtu11*PDstandardNth11beta2 + 
      gtu22*PDstandardNth22beta2 + gtu33*PDstandardNth33beta2 + 
      0.333333333333333333333333333333*(gtu12*(PDstandardNth11beta1 + 
      PDstandardNth12beta2 + PDstandardNth13beta3) + 
      gtu22*(PDstandardNth12beta1 + PDstandardNth22beta2 + 
      PDstandardNth23beta3) + gtu23*(PDstandardNth13beta1 + 
      PDstandardNth23beta2 + PDstandardNth33beta3)) - 
      2*(Atu12*PDstandardNth1alpha + Atu22*PDstandardNth2alpha + 
      Atu23*PDstandardNth3alpha) + 2*(gtu12*PDstandardNth12beta2 + 
      gtu13*PDstandardNth13beta2 + gtu23*PDstandardNth23beta2 + 
      alphaL*(6*(Atu12*cdphi1 + Atu22*cdphi2 + Atu23*cdphi3) + Atu11*Gt211 + 
      2*Atu12*Gt212 + 2*Atu13*Gt213 + Atu22*Gt222 + 2*Atu23*Gt223 + 
      Atu33*Gt233 - 0.666666666666666666666666666667*(gtu12*PDstandardNth1trK 
      + gtu22*PDstandardNth2trK + gtu23*PDstandardNth3trK))) - 
      PDstandardNth1beta2*Xtn1 + (-PDstandardNth2beta2 + 
      0.666666666666666666666666666667*(PDstandardNth1beta1 + 
      PDstandardNth2beta2 + PDstandardNth3beta3))*Xtn2 - 
      PDstandardNth3beta2*Xtn3;
    
    CCTK_REAL dotXt3 CCTK_ATTRIBUTE_UNUSED = gtu11*PDstandardNth11beta3 + 
      gtu22*PDstandardNth22beta3 + gtu33*PDstandardNth33beta3 + 
      0.333333333333333333333333333333*(gtu13*(PDstandardNth11beta1 + 
      PDstandardNth12beta2 + PDstandardNth13beta3) + 
      gtu23*(PDstandardNth12beta1 + PDstandardNth22beta2 + 
      PDstandardNth23beta3) + gtu33*(PDstandardNth13beta1 + 
      PDstandardNth23beta2 + PDstandardNth33beta3)) - 
      2*(Atu13*PDstandardNth1alpha + Atu23*PDstandardNth2alpha + 
      Atu33*PDstandardNth3alpha) + 2*(gtu12*PDstandardNth12beta3 + 
      gtu13*PDstandardNth13beta3 + gtu23*PDstandardNth23beta3 + 
      alphaL*(6*(Atu13*cdphi1 + Atu23*cdphi2 + Atu33*cdphi3) + Atu11*Gt311 + 
      2*Atu12*Gt312 + 2*Atu13*Gt313 + Atu22*Gt322 + 2*Atu23*Gt323 + 
      Atu33*Gt333 - 0.666666666666666666666666666667*(gtu13*PDstandardNth1trK 
      + gtu23*PDstandardNth2trK + gtu33*PDstandardNth3trK))) - 
      PDstandardNth1beta3*Xtn1 - PDstandardNth2beta3*Xtn2 + 
      (-PDstandardNth3beta3 + 
      0.666666666666666666666666666667*(PDstandardNth1beta1 + 
      PDstandardNth2beta2 + PDstandardNth3beta3))*Xtn3;
    
    CCTK_REAL Xt1rhsL CCTK_ATTRIBUTE_UNUSED = dotXt1 + 
      epsdiss1*PDdissipationNth1Xt1 + epsdiss2*PDdissipationNth2Xt1 + 
      epsdiss3*PDdissipationNth3Xt1 + beta1L*PDupwindNthAnti1Xt1 + 
      beta2L*PDupwindNthAnti2Xt1 + beta3L*PDupwindNthAnti3Xt1 + 
      PDupwindNthSymm1Xt1*fabs(beta1L) + PDupwindNthSymm2Xt1*fabs(beta2L) + 
      PDupwindNthSymm3Xt1*fabs(beta3L);
    
    CCTK_REAL Xt2rhsL CCTK_ATTRIBUTE_UNUSED = dotXt2 + 
      epsdiss1*PDdissipationNth1Xt2 + epsdiss2*PDdissipationNth2Xt2 + 
      epsdiss3*PDdissipationNth3Xt2 + beta1L*PDupwindNthAnti1Xt2 + 
      beta2L*PDupwindNthAnti2Xt2 + beta3L*PDupwindNthAnti3Xt2 + 
      PDupwindNthSymm1Xt2*fabs(beta1L) + PDupwindNthSymm2Xt2*fabs(beta2L) + 
      PDupwindNthSymm3Xt2*fabs(beta3L);
    
    CCTK_REAL Xt3rhsL CCTK_ATTRIBUTE_UNUSED = dotXt3 + 
      epsdiss1*PDdissipationNth1Xt3 + epsdiss2*PDdissipationNth2Xt3 + 
      epsdiss3*PDdissipationNth3Xt3 + beta1L*PDupwindNthAnti1Xt3 + 
      beta2L*PDupwindNthAnti2Xt3 + beta3L*PDupwindNthAnti3Xt3 + 
      PDupwindNthSymm1Xt3*fabs(beta1L) + PDupwindNthSymm2Xt3*fabs(beta2L) + 
      PDupwindNthSymm3Xt3*fabs(beta3L);
    
    CCTK_REAL dottrK CCTK_ATTRIBUTE_UNUSED = 
      -(em4phi*(gtu11*PDstandardNth11alpha + gtu22*PDstandardNth22alpha + 
      gtu33*(PDstandardNth33alpha + 2*cdphi3*PDstandardNth3alpha) + 
      2*(gtu12*PDstandardNth12alpha + gtu13*(PDstandardNth13alpha + 
      cdphi1*PDstandardNth3alpha) + gtu23*(PDstandardNth23alpha + 
      cdphi2*PDstandardNth3alpha)) + PDstandardNth1alpha*(2*(cdphi1*gtu11 + 
      cdphi2*gtu12 + cdphi3*gtu13) - Xtn1) + 
      PDstandardNth2alpha*(2*(cdphi1*gtu12 + cdphi2*gtu22 + cdphi3*gtu23) - 
      Xtn2) - PDstandardNth3alpha*Xtn3)) + alphaL*(2*(Atm12*Atm21 + 
      Atm13*Atm31 + Atm23*Atm32) + 
      0.333333333333333333333333333333*pow(trKL,2) + pow(Atm11,2) + 
      pow(Atm22,2) + pow(Atm33,2));
    
    CCTK_REAL trKrhsL CCTK_ATTRIBUTE_UNUSED = dottrK + 
      epsdiss1*PDdissipationNth1trK + epsdiss2*PDdissipationNth2trK + 
      epsdiss3*PDdissipationNth3trK + beta1L*PDupwindNthAnti1trK + 
      beta2L*PDupwindNthAnti2trK + beta3L*PDupwindNthAnti3trK + 
      PDupwindNthSymm1trK*fabs(beta1L) + PDupwindNthSymm2trK*fabs(beta2L) + 
      PDupwindNthSymm3trK*fabs(beta3L);
    
    CCTK_REAL betaDriverValue CCTK_ATTRIBUTE_UNUSED = 
      IfThen(useSpatialBetaDriver != 
      0,betaDriver*spatialBetaDriverRadius*pow(fmax(rL,spatialBetaDriverRadius),-1),betaDriver);
    
    CCTK_REAL shiftGammaCoeffValue CCTK_ATTRIBUTE_UNUSED = 
      IfThen(useSpatialShiftGammaCoeff != 0,shiftGammaCoeff*fmin(1,exp(1 - 
      rL*pow(spatialShiftGammaCoeffRadius,-1))),shiftGammaCoeff);
    
    CCTK_REAL ddetgt1 CCTK_ATTRIBUTE_UNUSED = gtu11*PDstandardNth1gt11 + 
      gtu22*PDstandardNth1gt22 + 2*(gtu12*PDstandardNth1gt12 + 
      gtu13*PDstandardNth1gt13 + gtu23*PDstandardNth1gt23) + 
      gtu33*PDstandardNth1gt33;
    
    CCTK_REAL ddetgt2 CCTK_ATTRIBUTE_UNUSED = gtu11*PDstandardNth2gt11 + 
      gtu22*PDstandardNth2gt22 + 2*(gtu12*PDstandardNth2gt12 + 
      gtu13*PDstandardNth2gt13 + gtu23*PDstandardNth2gt23) + 
      gtu33*PDstandardNth2gt33;
    
    CCTK_REAL ddetgt3 CCTK_ATTRIBUTE_UNUSED = gtu11*PDstandardNth3gt11 + 
      gtu22*PDstandardNth3gt22 + 2*(gtu12*PDstandardNth3gt12 + 
      gtu13*PDstandardNth3gt13 + gtu23*PDstandardNth3gt23) + 
      gtu33*PDstandardNth3gt33;
    
    CCTK_REAL dotbeta1 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL dotbeta2 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL dotbeta3 CCTK_ATTRIBUTE_UNUSED;
    
    if (shiftFormulation == 0)
    {
      dotbeta1 = shiftGammaCoeffValue*IfThen(evolveB != 0,B1L,Xt1L - 
        beta1L*betaDriverValue)*pow(alphaL,shiftAlphaPower);
      
      dotbeta2 = shiftGammaCoeffValue*IfThen(evolveB != 0,B2L,Xt2L - 
        beta2L*betaDriverValue)*pow(alphaL,shiftAlphaPower);
      
      dotbeta3 = shiftGammaCoeffValue*IfThen(evolveB != 0,B3L,Xt3L - 
        beta3L*betaDriverValue)*pow(alphaL,shiftAlphaPower);
    }
    else
    {
      dotbeta1 = -(alphaL*(gu11*(PDstandardNth1alpha + alphaL*(2*cdphi1 + 
        0.5*ddetgt1 - gtu11*PDstandardNth1gt11 + gtu12*(-PDstandardNth1gt12 - 
        PDstandardNth2gt11) - gtu22*PDstandardNth2gt12 + 
        gtu13*(-PDstandardNth1gt13 - PDstandardNth3gt11) + 
        gtu23*(-PDstandardNth2gt13 - PDstandardNth3gt12) - 
        gtu33*PDstandardNth3gt13)) + gu12*(PDstandardNth2alpha + 
        alphaL*(2*cdphi2 + 0.5*ddetgt2 - gtu11*PDstandardNth1gt12 + 
        gtu12*(-PDstandardNth1gt22 - PDstandardNth2gt12) - 
        gtu22*PDstandardNth2gt22 + gtu13*(-PDstandardNth1gt23 - 
        PDstandardNth3gt12) + gtu23*(-PDstandardNth2gt23 - PDstandardNth3gt22) 
        - gtu33*PDstandardNth3gt23)) + gu13*(PDstandardNth3alpha + 
        alphaL*(2*cdphi3 + 0.5*ddetgt3 - gtu11*PDstandardNth1gt13 + 
        gtu12*(-PDstandardNth1gt23 - PDstandardNth2gt13) - 
        gtu22*PDstandardNth2gt23 + gtu13*(-PDstandardNth1gt33 - 
        PDstandardNth3gt13) + gtu23*(-PDstandardNth2gt33 - PDstandardNth3gt23) 
        - gtu33*PDstandardNth3gt33))));
      
      dotbeta2 = -(alphaL*(gu12*(PDstandardNth1alpha + alphaL*(2*cdphi1 + 
        0.5*ddetgt1 - gtu11*PDstandardNth1gt11 + gtu12*(-PDstandardNth1gt12 - 
        PDstandardNth2gt11) - gtu22*PDstandardNth2gt12 + 
        gtu13*(-PDstandardNth1gt13 - PDstandardNth3gt11) + 
        gtu23*(-PDstandardNth2gt13 - PDstandardNth3gt12) - 
        gtu33*PDstandardNth3gt13)) + gu22*(PDstandardNth2alpha + 
        alphaL*(2*cdphi2 + 0.5*ddetgt2 - gtu11*PDstandardNth1gt12 + 
        gtu12*(-PDstandardNth1gt22 - PDstandardNth2gt12) - 
        gtu22*PDstandardNth2gt22 + gtu13*(-PDstandardNth1gt23 - 
        PDstandardNth3gt12) + gtu23*(-PDstandardNth2gt23 - PDstandardNth3gt22) 
        - gtu33*PDstandardNth3gt23)) + gu23*(PDstandardNth3alpha + 
        alphaL*(2*cdphi3 + 0.5*ddetgt3 - gtu11*PDstandardNth1gt13 + 
        gtu12*(-PDstandardNth1gt23 - PDstandardNth2gt13) - 
        gtu22*PDstandardNth2gt23 + gtu13*(-PDstandardNth1gt33 - 
        PDstandardNth3gt13) + gtu23*(-PDstandardNth2gt33 - PDstandardNth3gt23) 
        - gtu33*PDstandardNth3gt33))));
      
      dotbeta3 = -(alphaL*(gu13*(PDstandardNth1alpha + alphaL*(2*cdphi1 + 
        0.5*ddetgt1 - gtu11*PDstandardNth1gt11 + gtu12*(-PDstandardNth1gt12 - 
        PDstandardNth2gt11) - gtu22*PDstandardNth2gt12 + 
        gtu13*(-PDstandardNth1gt13 - PDstandardNth3gt11) + 
        gtu23*(-PDstandardNth2gt13 - PDstandardNth3gt12) - 
        gtu33*PDstandardNth3gt13)) + gu23*(PDstandardNth2alpha + 
        alphaL*(2*cdphi2 + 0.5*ddetgt2 - gtu11*PDstandardNth1gt12 + 
        gtu12*(-PDstandardNth1gt22 - PDstandardNth2gt12) - 
        gtu22*PDstandardNth2gt22 + gtu13*(-PDstandardNth1gt23 - 
        PDstandardNth3gt12) + gtu23*(-PDstandardNth2gt23 - PDstandardNth3gt22) 
        - gtu33*PDstandardNth3gt23)) + gu33*(PDstandardNth3alpha + 
        alphaL*(2*cdphi3 + 0.5*ddetgt3 - gtu11*PDstandardNth1gt13 + 
        gtu12*(-PDstandardNth1gt23 - PDstandardNth2gt13) - 
        gtu22*PDstandardNth2gt23 + gtu13*(-PDstandardNth1gt33 - 
        PDstandardNth3gt13) + gtu23*(-PDstandardNth2gt33 - PDstandardNth3gt23) 
        - gtu33*PDstandardNth3gt33))));
    }
    
    CCTK_REAL beta1rhsL CCTK_ATTRIBUTE_UNUSED = dotbeta1 + 
      epsdiss1*PDdissipationNth1beta1 + epsdiss2*PDdissipationNth2beta1 + 
      epsdiss3*PDdissipationNth3beta1 + IfThen(advectShift != 
      0,beta1L*PDupwindNthAnti1beta1 + beta2L*PDupwindNthAnti2beta1 + 
      beta3L*PDupwindNthAnti3beta1 + PDupwindNthSymm1beta1*fabs(beta1L) + 
      PDupwindNthSymm2beta1*fabs(beta2L) + 
      PDupwindNthSymm3beta1*fabs(beta3L),0);
    
    CCTK_REAL beta2rhsL CCTK_ATTRIBUTE_UNUSED = dotbeta2 + 
      epsdiss1*PDdissipationNth1beta2 + epsdiss2*PDdissipationNth2beta2 + 
      epsdiss3*PDdissipationNth3beta2 + IfThen(advectShift != 
      0,beta1L*PDupwindNthAnti1beta2 + beta2L*PDupwindNthAnti2beta2 + 
      beta3L*PDupwindNthAnti3beta2 + PDupwindNthSymm1beta2*fabs(beta1L) + 
      PDupwindNthSymm2beta2*fabs(beta2L) + 
      PDupwindNthSymm3beta2*fabs(beta3L),0);
    
    CCTK_REAL beta3rhsL CCTK_ATTRIBUTE_UNUSED = dotbeta3 + 
      epsdiss1*PDdissipationNth1beta3 + epsdiss2*PDdissipationNth2beta3 + 
      epsdiss3*PDdissipationNth3beta3 + IfThen(advectShift != 
      0,beta1L*PDupwindNthAnti1beta3 + beta2L*PDupwindNthAnti2beta3 + 
      beta3L*PDupwindNthAnti3beta3 + PDupwindNthSymm1beta3*fabs(beta1L) + 
      PDupwindNthSymm2beta3*fabs(beta2L) + 
      PDupwindNthSymm3beta3*fabs(beta3L),0);
    
    CCTK_REAL B1rhsL CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL B2rhsL CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL B3rhsL CCTK_ATTRIBUTE_UNUSED;
    
    if (evolveB != 0)
    {
      B1rhsL = dotXt1 + epsdiss1*PDdissipationNth1B1 + 
        epsdiss2*PDdissipationNth2B1 + epsdiss3*PDdissipationNth3B1 + 
        IfThen(fixAdvectionTerms == 0 && advectShift != 
        0,beta1L*PDupwindNthAnti1B1 + beta2L*PDupwindNthAnti2B1 + 
        beta3L*PDupwindNthAnti3B1 + PDupwindNthSymm1B1*fabs(beta1L) + 
        PDupwindNthSymm2B1*fabs(beta2L) + PDupwindNthSymm3B1*fabs(beta3L),0) - 
        betaDriverValue*(B1L + IfThen(fixAdvectionTerms != 0 && advectShift != 
        0,(beta1L*PDupwindNthAnti1beta1 + beta2L*PDupwindNthAnti2beta1 + 
        beta3L*PDupwindNthAnti3beta1 + PDupwindNthSymm1beta1*fabs(beta1L) + 
        PDupwindNthSymm2beta1*fabs(beta2L) + 
        PDupwindNthSymm3beta1*fabs(beta3L))*pow(alphaL,-shiftAlphaPower)*pow(shiftGammaCoeffValue,-1),0)) 
        + IfThen(fixAdvectionTerms != 0,beta1L*PDupwindNthAnti1Xt1 + 
        beta2L*PDupwindNthAnti2Xt1 + beta3L*PDupwindNthAnti3Xt1 + 
        PDupwindNthSymm1Xt1*fabs(beta1L) + PDupwindNthSymm2Xt1*fabs(beta2L) + 
        PDupwindNthSymm3Xt1*fabs(beta3L),0);
      
      B2rhsL = dotXt2 + epsdiss1*PDdissipationNth1B2 + 
        epsdiss2*PDdissipationNth2B2 + epsdiss3*PDdissipationNth3B2 + 
        IfThen(fixAdvectionTerms == 0 && advectShift != 
        0,beta1L*PDupwindNthAnti1B2 + beta2L*PDupwindNthAnti2B2 + 
        beta3L*PDupwindNthAnti3B2 + PDupwindNthSymm1B2*fabs(beta1L) + 
        PDupwindNthSymm2B2*fabs(beta2L) + PDupwindNthSymm3B2*fabs(beta3L),0) - 
        betaDriverValue*(B2L + IfThen(fixAdvectionTerms != 0 && advectShift != 
        0,(beta1L*PDupwindNthAnti1beta2 + beta2L*PDupwindNthAnti2beta2 + 
        beta3L*PDupwindNthAnti3beta2 + PDupwindNthSymm1beta2*fabs(beta1L) + 
        PDupwindNthSymm2beta2*fabs(beta2L) + 
        PDupwindNthSymm3beta2*fabs(beta3L))*pow(alphaL,-shiftAlphaPower)*pow(shiftGammaCoeffValue,-1),0)) 
        + IfThen(fixAdvectionTerms != 0,beta1L*PDupwindNthAnti1Xt2 + 
        beta2L*PDupwindNthAnti2Xt2 + beta3L*PDupwindNthAnti3Xt2 + 
        PDupwindNthSymm1Xt2*fabs(beta1L) + PDupwindNthSymm2Xt2*fabs(beta2L) + 
        PDupwindNthSymm3Xt2*fabs(beta3L),0);
      
      B3rhsL = dotXt3 + epsdiss1*PDdissipationNth1B3 + 
        epsdiss2*PDdissipationNth2B3 + epsdiss3*PDdissipationNth3B3 + 
        IfThen(fixAdvectionTerms == 0 && advectShift != 
        0,beta1L*PDupwindNthAnti1B3 + beta2L*PDupwindNthAnti2B3 + 
        beta3L*PDupwindNthAnti3B3 + PDupwindNthSymm1B3*fabs(beta1L) + 
        PDupwindNthSymm2B3*fabs(beta2L) + PDupwindNthSymm3B3*fabs(beta3L),0) - 
        betaDriverValue*(B3L + IfThen(fixAdvectionTerms != 0 && advectShift != 
        0,(beta1L*PDupwindNthAnti1beta3 + beta2L*PDupwindNthAnti2beta3 + 
        beta3L*PDupwindNthAnti3beta3 + PDupwindNthSymm1beta3*fabs(beta1L) + 
        PDupwindNthSymm2beta3*fabs(beta2L) + 
        PDupwindNthSymm3beta3*fabs(beta3L))*pow(alphaL,-shiftAlphaPower)*pow(shiftGammaCoeffValue,-1),0)) 
        + IfThen(fixAdvectionTerms != 0,beta1L*PDupwindNthAnti1Xt3 + 
        beta2L*PDupwindNthAnti2Xt3 + beta3L*PDupwindNthAnti3Xt3 + 
        PDupwindNthSymm1Xt3*fabs(beta1L) + PDupwindNthSymm2Xt3*fabs(beta2L) + 
        PDupwindNthSymm3Xt3*fabs(beta3L),0);
    }
    else
    {
      B1rhsL = 0;
      
      B2rhsL = 0;
      
      B3rhsL = 0;
    }
    /* Copy local copies back to grid functions */
    B1rhs[index] = B1rhsL;
    B2rhs[index] = B2rhsL;
    B3rhs[index] = B3rhsL;
    beta1rhs[index] = beta1rhsL;
    beta2rhs[index] = beta2rhsL;
    beta3rhs[index] = beta3rhsL;
    trKrhs[index] = trKrhsL;
    Xt1rhs[index] = Xt1rhsL;
    Xt2rhs[index] = Xt2rhsL;
    Xt3rhs[index] = Xt3rhsL;
  }
  CCTK_ENDLOOP3(ML_BSSN_EvolutionInteriorSplitBy2);
}
extern "C" void ML_BSSN_EvolutionInteriorSplitBy2(CCTK_ARGUMENTS)
{
  #ifdef DECLARE_CCTK_ARGUMENTS_ML_BSSN_EvolutionInteriorSplitBy2
  DECLARE_CCTK_ARGUMENTS_CHECKED(ML_BSSN_EvolutionInteriorSplitBy2);
  #else
  DECLARE_CCTK_ARGUMENTS;
  #endif
  DECLARE_CCTK_PARAMETERS;
  
  if (verbose > 1)
  {
    CCTK_VInfo(CCTK_THORNSTRING,"Entering ML_BSSN_EvolutionInteriorSplitBy2_Body");
  }
  if (cctk_iteration % ML_BSSN_EvolutionInteriorSplitBy2_calc_every != ML_BSSN_EvolutionInteriorSplitBy2_calc_offset)
  {
    return;
  }
  
  const char* const groups[] = {
    "grid::coordinates",
    "ML_BSSN::ML_curv",
    "ML_BSSN::ML_dtshift",
    "ML_BSSN::ML_dtshiftrhs",
    "ML_BSSN::ML_Gamma",
    "ML_BSSN::ML_Gammarhs",
    "ML_BSSN::ML_lapse",
    "ML_BSSN::ML_log_confac",
    "ML_BSSN::ML_metric",
    "ML_BSSN::ML_shift",
    "ML_BSSN::ML_shiftrhs",
    "ML_BSSN::ML_trace_curv",
    "ML_BSSN::ML_trace_curvrhs"};
  AssertGroupStorage(cctkGH, "ML_BSSN_EvolutionInteriorSplitBy2", 13, groups);
  
  switch (fdOrder)
  {
    case 2:
    {
      EnsureStencilFits(cctkGH, "ML_BSSN_EvolutionInteriorSplitBy2", 2, 2, 2);
      break;
    }
    
    case 4:
    {
      EnsureStencilFits(cctkGH, "ML_BSSN_EvolutionInteriorSplitBy2", 3, 3, 3);
      break;
    }
    
    case 6:
    {
      EnsureStencilFits(cctkGH, "ML_BSSN_EvolutionInteriorSplitBy2", 4, 4, 4);
      break;
    }
    
    case 8:
    {
      EnsureStencilFits(cctkGH, "ML_BSSN_EvolutionInteriorSplitBy2", 5, 5, 5);
      break;
    }
    default:
      CCTK_BUILTIN_UNREACHABLE();
  }
  
  LoopOverInterior(cctkGH, ML_BSSN_EvolutionInteriorSplitBy2_Body);
  if (verbose > 1)
  {
    CCTK_VInfo(CCTK_THORNSTRING,"Leaving ML_BSSN_EvolutionInteriorSplitBy2_Body");
  }
}

} // namespace ML_BSSN
