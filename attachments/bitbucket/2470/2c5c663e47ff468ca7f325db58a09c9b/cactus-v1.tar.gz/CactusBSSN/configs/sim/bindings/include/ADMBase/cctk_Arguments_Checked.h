#ifndef CCTK_ARGUMENTS_CHECKED_H
#define CCTK_ARGUMENTS_CHECKED_H 1

/* needed for CCTK_ANSI_FPP */
#include "cctk_Types.h"

#ifdef CCODE
#define DECLARE_CCTK_ARGUMENTS_CHECKED(func) DECLARE_CCTK_ARGUMENTS_##func
#endif
#ifdef FCODE
#if CCTK_ANSI_FPP
#define DECLARE_CCTK_ARGUMENTS_CHECKED(func) DECLARE_CCTK_ARGUMENTS_##func
#else
#define DECLARE_CCTK_ARGUMENTS_CHECKED(func) DECLARE_CCTK_ARGUMENTS_/**/func
#endif
#endif

#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_ADMBase_Boundaries 
#define DECLARE_CCTK_ARGUMENTS_ADMBase_Boundaries \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end ADMBase_Boundaries */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_ADMBase_CartesianMinkowski 
#define DECLARE_CCTK_ARGUMENTS_ADMBase_CartesianMinkowski \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_REAL  * restrict const alp __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).alp));; /* TL: ADMBase_CartesianMinkowski_C --> 0 no*/\
CCTK_REAL  * restrict const kxx __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).kxx));; /* group yes */\
CCTK_REAL  * restrict const kxy __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).kxy));; /* group yes */\
CCTK_REAL  * restrict const kxz __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).kxz));; /* group yes */\
CCTK_REAL  * restrict const kyy __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).kyy));; /* group yes */\
CCTK_REAL  * restrict const kyz __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).kyz));; /* group yes */\
CCTK_REAL  * restrict const kzz __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).kzz));; /* group yes */\
CCTK_REAL  * restrict const dtalp __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).dtalp));; /* TL: ADMBase_CartesianMinkowski_C --> 0 no*/\
CCTK_INT  * restrict const dtlapse_state __attribute__((__unused__)) = ((CCTK_INT *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).dtlapse_state));; /* TL: ADMBase_CartesianMinkowski_C --> 0 no*/\
CCTK_REAL  * restrict const dtbetax __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).dtbetax));; /* group yes */\
CCTK_REAL  * restrict const dtbetay __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).dtbetay));; /* group yes */\
CCTK_REAL  * restrict const dtbetaz __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).dtbetaz));; /* group yes */\
CCTK_INT  * restrict const dtshift_state __attribute__((__unused__)) = ((CCTK_INT *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).dtshift_state));; /* TL: ADMBase_CartesianMinkowski_C --> 0 no*/\
CCTK_REAL  * restrict const gxx_p __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 1, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gxx));; /* TL: ADMBase_CartesianMinkowski_C --> 1 no*/\
CCTK_REAL  * restrict const gxx_p_p __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 2, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gxx));; /* TL: ADMBase_CartesianMinkowski_C --> 2 no*/\
CCTK_REAL  * restrict const gxy_p __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 1, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gxy));; /* TL: ADMBase_CartesianMinkowski_C --> 1 no*/\
CCTK_REAL  * restrict const gxy_p_p __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 2, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gxy));; /* TL: ADMBase_CartesianMinkowski_C --> 2 no*/\
CCTK_REAL  * restrict const gxz_p __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 1, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gxz));; /* TL: ADMBase_CartesianMinkowski_C --> 1 no*/\
CCTK_REAL  * restrict const gxz_p_p __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 2, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gxz));; /* TL: ADMBase_CartesianMinkowski_C --> 2 no*/\
CCTK_REAL  * restrict const gyy_p __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 1, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gyy));; /* TL: ADMBase_CartesianMinkowski_C --> 1 no*/\
CCTK_REAL  * restrict const gyy_p_p __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 2, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gyy));; /* TL: ADMBase_CartesianMinkowski_C --> 2 no*/\
CCTK_REAL  * restrict const gyz_p __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 1, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gyz));; /* TL: ADMBase_CartesianMinkowski_C --> 1 no*/\
CCTK_REAL  * restrict const gyz_p_p __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 2, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gyz));; /* TL: ADMBase_CartesianMinkowski_C --> 2 no*/\
CCTK_REAL  * restrict const gzz_p __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 1, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gzz));; /* TL: ADMBase_CartesianMinkowski_C --> 1 no*/\
CCTK_REAL  * restrict const gzz_p_p __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 2, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gzz));; /* TL: ADMBase_CartesianMinkowski_C --> 2 no*/\
CCTK_REAL  * restrict const kxx_p __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 1, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).kxx));; /* TL: ADMBase_CartesianMinkowski_C --> 1 no*/\
CCTK_REAL  * restrict const kxx_p_p __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 2, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).kxx));; /* TL: ADMBase_CartesianMinkowski_C --> 2 no*/\
CCTK_REAL  * restrict const kxy_p __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 1, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).kxy));; /* TL: ADMBase_CartesianMinkowski_C --> 1 no*/\
CCTK_REAL  * restrict const kxy_p_p __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 2, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).kxy));; /* TL: ADMBase_CartesianMinkowski_C --> 2 no*/\
CCTK_REAL  * restrict const kxz_p __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 1, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).kxz));; /* TL: ADMBase_CartesianMinkowski_C --> 1 no*/\
CCTK_REAL  * restrict const kxz_p_p __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 2, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).kxz));; /* TL: ADMBase_CartesianMinkowski_C --> 2 no*/\
CCTK_REAL  * restrict const kyy_p __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 1, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).kyy));; /* TL: ADMBase_CartesianMinkowski_C --> 1 no*/\
CCTK_REAL  * restrict const kyy_p_p __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 2, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).kyy));; /* TL: ADMBase_CartesianMinkowski_C --> 2 no*/\
CCTK_REAL  * restrict const kyz_p __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 1, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).kyz));; /* TL: ADMBase_CartesianMinkowski_C --> 1 no*/\
CCTK_REAL  * restrict const kyz_p_p __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 2, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).kyz));; /* TL: ADMBase_CartesianMinkowski_C --> 2 no*/\
CCTK_REAL  * restrict const kzz_p __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 1, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).kzz));; /* TL: ADMBase_CartesianMinkowski_C --> 1 no*/\
CCTK_REAL  * restrict const kzz_p_p __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 2, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).kzz));; /* TL: ADMBase_CartesianMinkowski_C --> 2 no*/\
CCTK_REAL  * restrict const gxx __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gxx));; /* group yes */\
CCTK_REAL  * restrict const gxy __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gxy));; /* group yes */\
CCTK_REAL  * restrict const gxz __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gxz));; /* group yes */\
CCTK_REAL  * restrict const gyy __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gyy));; /* group yes */\
CCTK_REAL  * restrict const gyz __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gyz));; /* group yes */\
CCTK_REAL  * restrict const gzz __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gzz));; /* group yes */\
CCTK_REAL  * restrict const betax __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).betax));; /* group yes */\
CCTK_REAL  * restrict const betay __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).betay));; /* group yes */\
CCTK_REAL  * restrict const betaz __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).betaz));; /* group yes */\
CCTK_INT  * restrict const shift_state __attribute__((__unused__)) = ((CCTK_INT *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).shift_state));; /* TL: ADMBase_CartesianMinkowski_C --> 0 no*/\
  /* end ADMBase_CartesianMinkowski */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_ADMBase_DtLapseZero 
#define DECLARE_CCTK_ARGUMENTS_ADMBase_DtLapseZero \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_REAL  * restrict const dtalp __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).dtalp));; /* TL: ADMBase_DtLapseZero_C --> 0 no*/\
CCTK_REAL  * restrict const dtalp_p __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 1, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).dtalp));; /* TL: ADMBase_DtLapseZero_C --> 1 no*/\
CCTK_REAL  * restrict const dtalp_p_p __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 2, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).dtalp));; /* TL: ADMBase_DtLapseZero_C --> 2 no*/\
  /* end ADMBase_DtLapseZero */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_ADMBase_DtShiftZero 
#define DECLARE_CCTK_ARGUMENTS_ADMBase_DtShiftZero \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_REAL  * restrict const dtbetax_p __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 1, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).dtbetax));; /* TL: ADMBase_DtShiftZero_C --> 1 no*/\
CCTK_REAL  * restrict const dtbetax_p_p __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 2, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).dtbetax));; /* TL: ADMBase_DtShiftZero_C --> 2 no*/\
CCTK_REAL  * restrict const dtbetay_p __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 1, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).dtbetay));; /* TL: ADMBase_DtShiftZero_C --> 1 no*/\
CCTK_REAL  * restrict const dtbetay_p_p __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 2, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).dtbetay));; /* TL: ADMBase_DtShiftZero_C --> 2 no*/\
CCTK_REAL  * restrict const dtbetaz_p __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 1, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).dtbetaz));; /* TL: ADMBase_DtShiftZero_C --> 1 no*/\
CCTK_REAL  * restrict const dtbetaz_p_p __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 2, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).dtbetaz));; /* TL: ADMBase_DtShiftZero_C --> 2 no*/\
CCTK_REAL  * restrict const dtbetax __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).dtbetax));; /* group yes */\
CCTK_REAL  * restrict const dtbetay __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).dtbetay));; /* group yes */\
CCTK_REAL  * restrict const dtbetaz __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).dtbetaz));; /* group yes */\
  /* end ADMBase_DtShiftZero */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_ADMBase_LapseOne 
#define DECLARE_CCTK_ARGUMENTS_ADMBase_LapseOne \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_REAL  * restrict const alp __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).alp));; /* TL: ADMBase_LapseOne_C --> 0 no*/\
CCTK_REAL  * restrict const alp_p __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 1, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).alp));; /* TL: ADMBase_LapseOne_C --> 1 no*/\
CCTK_REAL  * restrict const alp_p_p __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 2, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).alp));; /* TL: ADMBase_LapseOne_C --> 2 no*/\
  /* end ADMBase_LapseOne */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_ADMBase_LapseStatic 
#define DECLARE_CCTK_ARGUMENTS_ADMBase_LapseStatic \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_REAL  * restrict const alp __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).alp));; /* TL: ADMBase_LapseStatic_C --> 0 no*/\
CCTK_REAL const * restrict const alp_p __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 1, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).alp));; /* TL: ADMBase_LapseStatic_C --> 1 no*/\
CCTK_REAL  * restrict const dtalp __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).dtalp));; /* TL: ADMBase_LapseStatic_C --> 0 no*/\
CCTK_REAL const * restrict const dtalp_p __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 1, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).dtalp));; /* TL: ADMBase_LapseStatic_C --> 1 no*/\
  /* end ADMBase_LapseStatic */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_ADMBase_ParamCheck 
#define DECLARE_CCTK_ARGUMENTS_ADMBase_ParamCheck \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end ADMBase_ParamCheck */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_ADMBase_SetDtLapseStateOff 
#define DECLARE_CCTK_ARGUMENTS_ADMBase_SetDtLapseStateOff \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_INT  * restrict const dtlapse_state __attribute__((__unused__)) = ((CCTK_INT *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).dtlapse_state));; /* TL: ADMBase_SetDtLapseStateOff_C --> 0 no*/\
  /* end ADMBase_SetDtLapseStateOff */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_ADMBase_SetDtLapseStateOn 
#define DECLARE_CCTK_ARGUMENTS_ADMBase_SetDtLapseStateOn \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_INT  * restrict const dtlapse_state __attribute__((__unused__)) = ((CCTK_INT *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).dtlapse_state));; /* TL: ADMBase_SetDtLapseStateOn_C --> 0 no*/\
  /* end ADMBase_SetDtLapseStateOn */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_ADMBase_SetDtShiftStateOff 
#define DECLARE_CCTK_ARGUMENTS_ADMBase_SetDtShiftStateOff \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_INT  * restrict const dtshift_state __attribute__((__unused__)) = ((CCTK_INT *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).dtshift_state));; /* TL: ADMBase_SetDtShiftStateOff_C --> 0 no*/\
  /* end ADMBase_SetDtShiftStateOff */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_ADMBase_SetDtShiftStateOn 
#define DECLARE_CCTK_ARGUMENTS_ADMBase_SetDtShiftStateOn \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_INT  * restrict const dtshift_state __attribute__((__unused__)) = ((CCTK_INT *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).dtshift_state));; /* TL: ADMBase_SetDtShiftStateOn_C --> 0 no*/\
  /* end ADMBase_SetDtShiftStateOn */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_ADMBase_SetShiftStateOff 
#define DECLARE_CCTK_ARGUMENTS_ADMBase_SetShiftStateOff \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_INT  * restrict const shift_state __attribute__((__unused__)) = ((CCTK_INT *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).shift_state));; /* TL: ADMBase_SetShiftStateOff_C --> 0 no*/\
  /* end ADMBase_SetShiftStateOff */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_ADMBase_SetShiftStateOn 
#define DECLARE_CCTK_ARGUMENTS_ADMBase_SetShiftStateOn \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_INT  * restrict const shift_state __attribute__((__unused__)) = ((CCTK_INT *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).shift_state));; /* TL: ADMBase_SetShiftStateOn_C --> 0 no*/\
  /* end ADMBase_SetShiftStateOn */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_ADMBase_ShiftStatic 
#define DECLARE_CCTK_ARGUMENTS_ADMBase_ShiftStatic \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_REAL const * restrict const betax_p __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 1, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).betax));; /* TL: ADMBase_ShiftStatic_C --> 1 no*/\
CCTK_REAL const * restrict const betay_p __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 1, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).betay));; /* TL: ADMBase_ShiftStatic_C --> 1 no*/\
CCTK_REAL const * restrict const betaz_p __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 1, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).betaz));; /* TL: ADMBase_ShiftStatic_C --> 1 no*/\
CCTK_REAL const * restrict const dtbetax_p __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 1, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).dtbetax));; /* TL: ADMBase_ShiftStatic_C --> 1 no*/\
CCTK_REAL const * restrict const dtbetay_p __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 1, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).dtbetay));; /* TL: ADMBase_ShiftStatic_C --> 1 no*/\
CCTK_REAL const * restrict const dtbetaz_p __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 1, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).dtbetaz));; /* TL: ADMBase_ShiftStatic_C --> 1 no*/\
CCTK_REAL  * restrict const dtbetax __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).dtbetax));; /* group yes */\
CCTK_REAL  * restrict const dtbetay __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).dtbetay));; /* group yes */\
CCTK_REAL  * restrict const dtbetaz __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).dtbetaz));; /* group yes */\
CCTK_REAL  * restrict const betax __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).betax));; /* group yes */\
CCTK_REAL  * restrict const betay __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).betay));; /* group yes */\
CCTK_REAL  * restrict const betaz __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).betaz));; /* group yes */\
  /* end ADMBase_ShiftStatic */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_ADMBase_ShiftZero 
#define DECLARE_CCTK_ARGUMENTS_ADMBase_ShiftZero \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_REAL  * restrict const betax_p __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 1, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).betax));; /* TL: ADMBase_ShiftZero_C --> 1 no*/\
CCTK_REAL  * restrict const betax_p_p __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 2, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).betax));; /* TL: ADMBase_ShiftZero_C --> 2 no*/\
CCTK_REAL  * restrict const betay_p __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 1, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).betay));; /* TL: ADMBase_ShiftZero_C --> 1 no*/\
CCTK_REAL  * restrict const betay_p_p __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 2, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).betay));; /* TL: ADMBase_ShiftZero_C --> 2 no*/\
CCTK_REAL  * restrict const betaz_p __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 1, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).betaz));; /* TL: ADMBase_ShiftZero_C --> 1 no*/\
CCTK_REAL  * restrict const betaz_p_p __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 2, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).betaz));; /* TL: ADMBase_ShiftZero_C --> 2 no*/\
CCTK_REAL  * restrict const betax __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).betax));; /* group yes */\
CCTK_REAL  * restrict const betay __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).betay));; /* group yes */\
CCTK_REAL  * restrict const betaz __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).betaz));; /* group yes */\
  /* end ADMBase_ShiftZero */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_ADMBase_Static 
#define DECLARE_CCTK_ARGUMENTS_ADMBase_Static \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_REAL  * restrict const kxx __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).kxx));; /* group yes */\
CCTK_REAL  * restrict const kxy __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).kxy));; /* group yes */\
CCTK_REAL  * restrict const kxz __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).kxz));; /* group yes */\
CCTK_REAL  * restrict const kyy __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).kyy));; /* group yes */\
CCTK_REAL  * restrict const kyz __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).kyz));; /* group yes */\
CCTK_REAL  * restrict const kzz __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).kzz));; /* group yes */\
CCTK_REAL const * restrict const gxx_p __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 1, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gxx));; /* TL: ADMBase_Static_C --> 1 no*/\
CCTK_REAL const * restrict const gxy_p __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 1, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gxy));; /* TL: ADMBase_Static_C --> 1 no*/\
CCTK_REAL const * restrict const gxz_p __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 1, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gxz));; /* TL: ADMBase_Static_C --> 1 no*/\
CCTK_REAL const * restrict const gyy_p __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 1, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gyy));; /* TL: ADMBase_Static_C --> 1 no*/\
CCTK_REAL const * restrict const gyz_p __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 1, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gyz));; /* TL: ADMBase_Static_C --> 1 no*/\
CCTK_REAL const * restrict const gzz_p __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 1, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gzz));; /* TL: ADMBase_Static_C --> 1 no*/\
CCTK_REAL const * restrict const kxx_p __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 1, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).kxx));; /* TL: ADMBase_Static_C --> 1 no*/\
CCTK_REAL const * restrict const kxy_p __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 1, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).kxy));; /* TL: ADMBase_Static_C --> 1 no*/\
CCTK_REAL const * restrict const kxz_p __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 1, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).kxz));; /* TL: ADMBase_Static_C --> 1 no*/\
CCTK_REAL const * restrict const kyy_p __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 1, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).kyy));; /* TL: ADMBase_Static_C --> 1 no*/\
CCTK_REAL const * restrict const kyz_p __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 1, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).kyz));; /* TL: ADMBase_Static_C --> 1 no*/\
CCTK_REAL const * restrict const kzz_p __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 1, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).kzz));; /* TL: ADMBase_Static_C --> 1 no*/\
CCTK_REAL  * restrict const gxx __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gxx));; /* group yes */\
CCTK_REAL  * restrict const gxy __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gxy));; /* group yes */\
CCTK_REAL  * restrict const gxz __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gxz));; /* group yes */\
CCTK_REAL  * restrict const gyy __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gyy));; /* group yes */\
CCTK_REAL  * restrict const gyz __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gyz));; /* group yes */\
CCTK_REAL  * restrict const gzz __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gzz));; /* group yes */\
  /* end ADMBase_Static */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_Einstein_InitSymBound 
#define DECLARE_CCTK_ARGUMENTS_Einstein_InitSymBound \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end Einstein_InitSymBound */
#endif
#endif
#endif