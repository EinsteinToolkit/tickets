#ifndef CCTK_ARGUMENTS_CHECKED_H
#define CCTK_ARGUMENTS_CHECKED_H 1

/* needed for CCTK_ANSI_FPP */
#include "cctk_Types.h"

#ifdef CCODE
#define DECLARE_CCTK_ARGUMENTS_CHECKED(func) DECLARE_CCTK_ARGUMENTS_##func
#endif
#ifdef FCODE
#if CCTK_ANSI_FPP
#define DECLARE_CCTK_ARGUMENTS_CHECKED(func) DECLARE_CCTK_ARGUMENTS_##func
#else
#define DECLARE_CCTK_ARGUMENTS_CHECKED(func) DECLARE_CCTK_ARGUMENTS_/**/func
#endif
#endif

#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_Einstein_ActivateSlicing 
#define DECLARE_CCTK_ARGUMENTS_Einstein_ActivateSlicing \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end Einstein_ActivateSlicing */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_Einstein_SetNextSlicing 
#define DECLARE_CCTK_ARGUMENTS_Einstein_SetNextSlicing \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end Einstein_SetNextSlicing */
#endif
#endif
#endif