#ifndef CCTK_ARGUMENTS_CHECKED_H
#define CCTK_ARGUMENTS_CHECKED_H 1

/* needed for CCTK_ANSI_FPP */
#include "cctk_Types.h"

#ifdef CCODE
#define DECLARE_CCTK_ARGUMENTS_CHECKED(func) DECLARE_CCTK_ARGUMENTS_##func
#endif
#ifdef FCODE
#if CCTK_ANSI_FPP
#define DECLARE_CCTK_ARGUMENTS_CHECKED(func) DECLARE_CCTK_ARGUMENTS_##func
#else
#define DECLARE_CCTK_ARGUMENTS_CHECKED(func) DECLARE_CCTK_ARGUMENTS_/**/func
#endif
#endif

#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_SymBase_Check 
#define DECLARE_CCTK_ARGUMENTS_SymBase_Check \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end SymBase_Check */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_SymBase_Startup 
#define DECLARE_CCTK_ARGUMENTS_SymBase_Startup \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end SymBase_Startup */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_SymBase_Statistics 
#define DECLARE_CCTK_ARGUMENTS_SymBase_Statistics \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end SymBase_Statistics */
#endif
#endif
#endif