 /*@@
   @header    CactusIOFunctions.h
   @date      Mon Jan 8 1999
   @author    Gabrielle Allen
   @desc 
   Overloadable IO functions
   @enddesc 
   @version $Header: /CCT/Projects/XiRel/SPEC2006/CactusBSSN/src/include/CactusIOFunctions.h,v 1.1.1.1 2009/02/03 01:02:30 jtao Exp $
 @@*/

#ifndef _CACTUSIOFUNCTIONS_H_
#define _CACTUSIOFUNCTIONS_H_

#include <stdarg.h>

#include "OverloadMacros.h"

#ifdef __cplusplus
extern "C" {
#endif

/* The functions. */

#define OVERLOADABLE(name) OVERLOADABLE_PROTOTYPE(name)

#include "IOOverloadables.h"

#undef OVERLOADABLE

#ifdef __cplusplus
}
#endif

#endif
