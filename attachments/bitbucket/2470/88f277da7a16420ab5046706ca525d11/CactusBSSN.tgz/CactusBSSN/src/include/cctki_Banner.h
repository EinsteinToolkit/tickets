 /*@@
   @header    cctki_Banner.h
   @date      Wed Oct 13 16:21:40 CEST 1999
   @author    Gabrielle Allen
   @desc 
   Prototypes and constants for internal banner functions
   @enddesc 
   @version $Header: /CCT/Projects/XiRel/SPEC2006/CactusBSSN/src/include/cctki_Banner.h,v 1.1.1.1 2009/02/03 01:02:30 jtao Exp $
 @@*/

#ifndef _CCTKI_BANNER_H_
#define _CCTKI_BANNER_H_

/* Prototypes */

#ifdef __cplusplus 
extern "C" {
#endif

void CCTKi_CactusBanner(void);
int  CCTKi_PrintBanners(void);

#ifdef __cplusplus 
}
#endif

#endif



