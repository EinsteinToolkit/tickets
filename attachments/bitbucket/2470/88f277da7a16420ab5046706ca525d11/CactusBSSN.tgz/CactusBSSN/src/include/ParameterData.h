 /*@@
   @header    ParameterData.h
   @date      Fri Jan 15 14:06:43 1999
   @author    Tom Goodale
   @desc 
   
   @enddesc
   @version $Id: ParameterData.h,v 1.1.1.1 2009/02/03 01:02:30 jtao Exp $
 @@*/

int ProcessParameterDatabase(tFleshConfig *ConfigData);

int CCTKi_InitialiseParameters(tFleshConfig *ConfigData);

