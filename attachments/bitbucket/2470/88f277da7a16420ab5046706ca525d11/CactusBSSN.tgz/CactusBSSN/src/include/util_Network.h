 /*@@
   @header    util_Network.c
   @date      Fri 19 Jan 2001
   @author    Thomas Radke
   @desc
              Network related routines
   @enddesc
   @version $Header: /CCT/Projects/XiRel/SPEC2006/CactusBSSN/src/include/util_Network.h,v 1.1.1.1 2009/02/03 01:02:30 jtao Exp $
 @@*/

#ifndef _UTIL_NETWORK_H_
#define _UTIL_NETWORK_H_ 1

#ifdef __cplusplus
extern "C" 
{
#endif

void Util_GetHostName (char *name, int length);

#ifdef __cplusplus
}
#endif

#endif /* _UTIL_NETWORK_H_ */
