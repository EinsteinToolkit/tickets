/*@@
   @file      cctk_DebugDefines.h
   @date      Sun 28 Dec 2003
   @author    Erik Schnetter
   @desc
              Routines to provide some debugging support for the Cactus code.
   @enddesc
   @version   $Id: cctk_DebugDefines.h,v 1.1.1.1 2009/02/03 01:02:30 jtao Exp $
 @@*/

/********************************************************************
 *********************     External Routines   **********************
 ********************************************************************/

int CCTK_GFIndex1D (const cGH *GH, int i);
int CCTK_GFIndex2D (const cGH *GH, int i, int j);
int CCTK_GFIndex3D (const cGH *GH, int i, int j, int k);
int CCTK_GFIndex4D (const cGH *GH, int i, int j, int k, int l);
