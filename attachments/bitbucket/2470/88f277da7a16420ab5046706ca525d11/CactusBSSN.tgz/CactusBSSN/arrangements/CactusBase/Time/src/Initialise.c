 /*@@
   @file      Initialise.c
   @date      May 12 2001
   @author    Gabrielle Allen
   @desc 
   Initialise grid variables
   @enddesc 
 @@*/

#include "cctk.h"
#include "cctk_Arguments.h"

static const char *rcsid = "$Header: /CCT/Projects/XiRel/SPEC2006/CactusBSSN/arrangements/CactusBase/Time/src/Initialise.c,v 1.1.1.1 2009/02/03 01:02:30 jtao Exp $";

CCTK_FILEVERSION(CactusBase_Time_Initialise_c)

void Time_Initialise(CCTK_ARGUMENTS);

void Time_Initialise(CCTK_ARGUMENTS)
{
  DECLARE_CCTK_ARGUMENTS;

  *courant_wave_speed = 0;  
  *courant_min_time = 0;
  *courant_dt = 0;
}
