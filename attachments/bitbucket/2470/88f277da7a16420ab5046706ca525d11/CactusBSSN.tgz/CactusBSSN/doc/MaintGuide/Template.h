 /*@@
   @header    Template.h
   @date      Fri Oct  6 10:45:01 2000
   @author    Tom Goodale
   @desc 
   This is a template header function
   @enddesc
   @version $Header: /CCT/Projects/XiRel/SPEC2006/CactusBSSN/doc/MaintGuide/Template.h,v 1.1.1.1 2009/02/03 01:02:30 jtao Exp $
 @@*/

#ifndef _TEMPLATE_H_
#define _TEMPLATE_H_ 1

#ifdef __cplusplus
extern "C" 
{
#endif


#ifdef __cplusplus
}
#endif

#endif /* _TEMPLATE_H_ */
