/*  File produced by Kranc */

#define KRANC_C

#include <algorithm>
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cctk.h"
#include "cctk_Arguments.h"
#include "cctk_Parameters.h"
#include "Kranc.hh"
#include "Differencing.h"

namespace ML_CCZ4 {

extern "C" void ML_CCZ4_EvolutionInteriorSplitBy2_SelectBCs(CCTK_ARGUMENTS)
{
  #ifdef DECLARE_CCTK_ARGUMENTS_ML_CCZ4_EvolutionInteriorSplitBy2_SelectBCs
  DECLARE_CCTK_ARGUMENTS_CHECKED(ML_CCZ4_EvolutionInteriorSplitBy2_SelectBCs);
  #else
  DECLARE_CCTK_ARGUMENTS
  #endif
  DECLARE_CCTK_PARAMETERS
  
  if (cctk_iteration % ML_CCZ4_EvolutionInteriorSplitBy2_calc_every != ML_CCZ4_EvolutionInteriorSplitBy2_calc_offset)
    return;
  CCTK_INT ierr CCTK_ATTRIBUTE_UNUSED = 0;
  ierr = KrancBdy_SelectGroupForBC(cctkGH, CCTK_ALL_FACES, GetBoundaryWidth(cctkGH), -1 /* no table */, "ML_CCZ4::ML_dtshiftrhs","flat");
  if (ierr < 0)
    CCTK_WARN(CCTK_WARN_ALERT, "Failed to register flat BC for ML_CCZ4::ML_dtshiftrhs.");
  ierr = KrancBdy_SelectGroupForBC(cctkGH, CCTK_ALL_FACES, GetBoundaryWidth(cctkGH), -1 /* no table */, "ML_CCZ4::ML_Gammarhs","flat");
  if (ierr < 0)
    CCTK_WARN(CCTK_WARN_ALERT, "Failed to register flat BC for ML_CCZ4::ML_Gammarhs.");
  ierr = KrancBdy_SelectGroupForBC(cctkGH, CCTK_ALL_FACES, GetBoundaryWidth(cctkGH), -1 /* no table */, "ML_CCZ4::ML_shiftrhs","flat");
  if (ierr < 0)
    CCTK_WARN(CCTK_WARN_ALERT, "Failed to register flat BC for ML_CCZ4::ML_shiftrhs.");
  ierr = KrancBdy_SelectGroupForBC(cctkGH, CCTK_ALL_FACES, GetBoundaryWidth(cctkGH), -1 /* no table */, "ML_CCZ4::ML_Thetarhs","flat");
  if (ierr < 0)
    CCTK_WARN(CCTK_WARN_ALERT, "Failed to register flat BC for ML_CCZ4::ML_Thetarhs.");
  ierr = KrancBdy_SelectGroupForBC(cctkGH, CCTK_ALL_FACES, GetBoundaryWidth(cctkGH), -1 /* no table */, "ML_CCZ4::ML_trace_curvrhs","flat");
  if (ierr < 0)
    CCTK_WARN(CCTK_WARN_ALERT, "Failed to register flat BC for ML_CCZ4::ML_trace_curvrhs.");
  return;
}

static void ML_CCZ4_EvolutionInteriorSplitBy2_Body(const cGH* restrict const cctkGH, const int dir, const int face, const CCTK_REAL normal[3], const CCTK_REAL tangentA[3], const CCTK_REAL tangentB[3], const int imin[3], const int imax[3], const int n_subblock_gfs, CCTK_REAL* restrict const subblock_gfs[])
{
  DECLARE_CCTK_ARGUMENTS
  DECLARE_CCTK_PARAMETERS
  
  /* Include user-supplied include files */
  /* Initialise finite differencing variables */
  const ptrdiff_t di CCTK_ATTRIBUTE_UNUSED = 1;
  const ptrdiff_t dj CCTK_ATTRIBUTE_UNUSED = 
    CCTK_GFINDEX3D(cctkGH,0,1,0) - CCTK_GFINDEX3D(cctkGH,0,0,0);
  const ptrdiff_t dk CCTK_ATTRIBUTE_UNUSED = 
    CCTK_GFINDEX3D(cctkGH,0,0,1) - CCTK_GFINDEX3D(cctkGH,0,0,0);
  const ptrdiff_t cdi CCTK_ATTRIBUTE_UNUSED = sizeof(CCTK_REAL) * di;
  const ptrdiff_t cdj CCTK_ATTRIBUTE_UNUSED = sizeof(CCTK_REAL) * dj;
  const ptrdiff_t cdk CCTK_ATTRIBUTE_UNUSED = sizeof(CCTK_REAL) * dk;
  const ptrdiff_t cctkLbnd1 CCTK_ATTRIBUTE_UNUSED = cctk_lbnd[0];
  const ptrdiff_t cctkLbnd2 CCTK_ATTRIBUTE_UNUSED = cctk_lbnd[1];
  const ptrdiff_t cctkLbnd3 CCTK_ATTRIBUTE_UNUSED = cctk_lbnd[2];
  const CCTK_REAL t CCTK_ATTRIBUTE_UNUSED = cctk_time;
  const CCTK_REAL cctkOriginSpace1 CCTK_ATTRIBUTE_UNUSED = 
    CCTK_ORIGIN_SPACE(0);
  const CCTK_REAL cctkOriginSpace2 CCTK_ATTRIBUTE_UNUSED = 
    CCTK_ORIGIN_SPACE(1);
  const CCTK_REAL cctkOriginSpace3 CCTK_ATTRIBUTE_UNUSED = 
    CCTK_ORIGIN_SPACE(2);
  const CCTK_REAL dt CCTK_ATTRIBUTE_UNUSED = CCTK_DELTA_TIME;
  const CCTK_REAL dx CCTK_ATTRIBUTE_UNUSED = CCTK_DELTA_SPACE(0);
  const CCTK_REAL dy CCTK_ATTRIBUTE_UNUSED = CCTK_DELTA_SPACE(1);
  const CCTK_REAL dz CCTK_ATTRIBUTE_UNUSED = CCTK_DELTA_SPACE(2);
  const CCTK_REAL dxi CCTK_ATTRIBUTE_UNUSED = pow(dx,-1);
  const CCTK_REAL dyi CCTK_ATTRIBUTE_UNUSED = pow(dy,-1);
  const CCTK_REAL dzi CCTK_ATTRIBUTE_UNUSED = pow(dz,-1);
  const CCTK_REAL khalf CCTK_ATTRIBUTE_UNUSED = 0.5;
  const CCTK_REAL kthird CCTK_ATTRIBUTE_UNUSED = 
    0.333333333333333333333333333333;
  const CCTK_REAL ktwothird CCTK_ATTRIBUTE_UNUSED = 
    0.666666666666666666666666666667;
  const CCTK_REAL kfourthird CCTK_ATTRIBUTE_UNUSED = 
    1.33333333333333333333333333333;
  const CCTK_REAL hdxi CCTK_ATTRIBUTE_UNUSED = 0.5*dxi;
  const CCTK_REAL hdyi CCTK_ATTRIBUTE_UNUSED = 0.5*dyi;
  const CCTK_REAL hdzi CCTK_ATTRIBUTE_UNUSED = 0.5*dzi;
  /* Initialize predefined quantities */
  const CCTK_REAL p1o1024dx CCTK_ATTRIBUTE_UNUSED = 0.0009765625*pow(dx,-1);
  const CCTK_REAL p1o1024dy CCTK_ATTRIBUTE_UNUSED = 0.0009765625*pow(dy,-1);
  const CCTK_REAL p1o1024dz CCTK_ATTRIBUTE_UNUSED = 0.0009765625*pow(dz,-1);
  const CCTK_REAL p1o1680dx CCTK_ATTRIBUTE_UNUSED = 0.000595238095238095238095238095238*pow(dx,-1);
  const CCTK_REAL p1o1680dy CCTK_ATTRIBUTE_UNUSED = 0.000595238095238095238095238095238*pow(dy,-1);
  const CCTK_REAL p1o1680dz CCTK_ATTRIBUTE_UNUSED = 0.000595238095238095238095238095238*pow(dz,-1);
  const CCTK_REAL p1o5040dx2 CCTK_ATTRIBUTE_UNUSED = 0.000198412698412698412698412698413*pow(dx,-2);
  const CCTK_REAL p1o5040dy2 CCTK_ATTRIBUTE_UNUSED = 0.000198412698412698412698412698413*pow(dy,-2);
  const CCTK_REAL p1o5040dz2 CCTK_ATTRIBUTE_UNUSED = 0.000198412698412698412698412698413*pow(dz,-2);
  const CCTK_REAL p1o560dx CCTK_ATTRIBUTE_UNUSED = 0.00178571428571428571428571428571*pow(dx,-1);
  const CCTK_REAL p1o560dy CCTK_ATTRIBUTE_UNUSED = 0.00178571428571428571428571428571*pow(dy,-1);
  const CCTK_REAL p1o560dz CCTK_ATTRIBUTE_UNUSED = 0.00178571428571428571428571428571*pow(dz,-1);
  const CCTK_REAL p1o60dx CCTK_ATTRIBUTE_UNUSED = 0.0166666666666666666666666666667*pow(dx,-1);
  const CCTK_REAL p1o60dy CCTK_ATTRIBUTE_UNUSED = 0.0166666666666666666666666666667*pow(dy,-1);
  const CCTK_REAL p1o60dz CCTK_ATTRIBUTE_UNUSED = 0.0166666666666666666666666666667*pow(dz,-1);
  const CCTK_REAL p1o705600dxdy CCTK_ATTRIBUTE_UNUSED = 1.41723356009070294784580498866e-6*pow(dx,-1)*pow(dy,-1);
  const CCTK_REAL p1o705600dxdz CCTK_ATTRIBUTE_UNUSED = 1.41723356009070294784580498866e-6*pow(dx,-1)*pow(dz,-1);
  const CCTK_REAL p1o705600dydz CCTK_ATTRIBUTE_UNUSED = 1.41723356009070294784580498866e-6*pow(dy,-1)*pow(dz,-1);
  const CCTK_REAL p1o840dx CCTK_ATTRIBUTE_UNUSED = 0.00119047619047619047619047619048*pow(dx,-1);
  const CCTK_REAL p1o840dy CCTK_ATTRIBUTE_UNUSED = 0.00119047619047619047619047619048*pow(dy,-1);
  const CCTK_REAL p1o840dz CCTK_ATTRIBUTE_UNUSED = 0.00119047619047619047619047619048*pow(dz,-1);
  const CCTK_REAL pm1o840dx CCTK_ATTRIBUTE_UNUSED = -0.00119047619047619047619047619048*pow(dx,-1);
  const CCTK_REAL pm1o840dy CCTK_ATTRIBUTE_UNUSED = -0.00119047619047619047619047619048*pow(dy,-1);
  const CCTK_REAL pm1o840dz CCTK_ATTRIBUTE_UNUSED = -0.00119047619047619047619047619048*pow(dz,-1);
  /* Assign local copies of arrays functions */
  
  
  /* Calculate temporaries and arrays functions */
  /* Copy local copies back to grid functions */
  /* Loop over the grid points */
  const int imin0=imin[0];
  const int imin1=imin[1];
  const int imin2=imin[2];
  const int imax0=imax[0];
  const int imax1=imax[1];
  const int imax2=imax[2];
  #pragma omp parallel
  CCTK_LOOP3(ML_CCZ4_EvolutionInteriorSplitBy2,
    i,j,k, imin0,imin1,imin2, imax0,imax1,imax2,
    cctk_ash[0],cctk_ash[1],cctk_ash[2])
  {
    const ptrdiff_t index CCTK_ATTRIBUTE_UNUSED = di*i + dj*j + dk*k;
    /* Assign local copies of grid functions */
    
    CCTK_REAL alphaL CCTK_ATTRIBUTE_UNUSED = alpha[index];
    CCTK_REAL At11L CCTK_ATTRIBUTE_UNUSED = At11[index];
    CCTK_REAL At12L CCTK_ATTRIBUTE_UNUSED = At12[index];
    CCTK_REAL At13L CCTK_ATTRIBUTE_UNUSED = At13[index];
    CCTK_REAL At22L CCTK_ATTRIBUTE_UNUSED = At22[index];
    CCTK_REAL At23L CCTK_ATTRIBUTE_UNUSED = At23[index];
    CCTK_REAL At33L CCTK_ATTRIBUTE_UNUSED = At33[index];
    CCTK_REAL B1L CCTK_ATTRIBUTE_UNUSED = B1[index];
    CCTK_REAL B2L CCTK_ATTRIBUTE_UNUSED = B2[index];
    CCTK_REAL B3L CCTK_ATTRIBUTE_UNUSED = B3[index];
    CCTK_REAL beta1L CCTK_ATTRIBUTE_UNUSED = beta1[index];
    CCTK_REAL beta2L CCTK_ATTRIBUTE_UNUSED = beta2[index];
    CCTK_REAL beta3L CCTK_ATTRIBUTE_UNUSED = beta3[index];
    CCTK_REAL gt11L CCTK_ATTRIBUTE_UNUSED = gt11[index];
    CCTK_REAL gt12L CCTK_ATTRIBUTE_UNUSED = gt12[index];
    CCTK_REAL gt13L CCTK_ATTRIBUTE_UNUSED = gt13[index];
    CCTK_REAL gt22L CCTK_ATTRIBUTE_UNUSED = gt22[index];
    CCTK_REAL gt23L CCTK_ATTRIBUTE_UNUSED = gt23[index];
    CCTK_REAL gt33L CCTK_ATTRIBUTE_UNUSED = gt33[index];
    CCTK_REAL phiL CCTK_ATTRIBUTE_UNUSED = phi[index];
    CCTK_REAL ThetaL CCTK_ATTRIBUTE_UNUSED = Theta[index];
    CCTK_REAL trKL CCTK_ATTRIBUTE_UNUSED = trK[index];
    CCTK_REAL Xt1L CCTK_ATTRIBUTE_UNUSED = Xt1[index];
    CCTK_REAL Xt2L CCTK_ATTRIBUTE_UNUSED = Xt2[index];
    CCTK_REAL Xt3L CCTK_ATTRIBUTE_UNUSED = Xt3[index];
    
    /* Include user supplied include files */
    /* Precompute derivatives */
    const CCTK_REAL PDstandardNth1alpha CCTK_ATTRIBUTE_UNUSED = PDstandardNth1(&alpha[index]);
    const CCTK_REAL PDstandardNth2alpha CCTK_ATTRIBUTE_UNUSED = PDstandardNth2(&alpha[index]);
    const CCTK_REAL PDstandardNth3alpha CCTK_ATTRIBUTE_UNUSED = PDstandardNth3(&alpha[index]);
    const CCTK_REAL PDstandardNth11alpha CCTK_ATTRIBUTE_UNUSED = PDstandardNth11(&alpha[index]);
    const CCTK_REAL PDstandardNth22alpha CCTK_ATTRIBUTE_UNUSED = PDstandardNth22(&alpha[index]);
    const CCTK_REAL PDstandardNth33alpha CCTK_ATTRIBUTE_UNUSED = PDstandardNth33(&alpha[index]);
    const CCTK_REAL PDstandardNth12alpha CCTK_ATTRIBUTE_UNUSED = PDstandardNth12(&alpha[index]);
    const CCTK_REAL PDstandardNth13alpha CCTK_ATTRIBUTE_UNUSED = PDstandardNth13(&alpha[index]);
    const CCTK_REAL PDstandardNth23alpha CCTK_ATTRIBUTE_UNUSED = PDstandardNth23(&alpha[index]);
    const CCTK_REAL PDupwindNthSymm1B1 CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm1(&B1[index]);
    const CCTK_REAL PDupwindNthSymm2B1 CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm2(&B1[index]);
    const CCTK_REAL PDupwindNthSymm3B1 CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm3(&B1[index]);
    const CCTK_REAL PDupwindNthAnti1B1 CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti1(&B1[index]);
    const CCTK_REAL PDupwindNthAnti2B1 CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti2(&B1[index]);
    const CCTK_REAL PDupwindNthAnti3B1 CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti3(&B1[index]);
    const CCTK_REAL PDdissipationNth1B1 CCTK_ATTRIBUTE_UNUSED = PDdissipationNth1(&B1[index]);
    const CCTK_REAL PDdissipationNth2B1 CCTK_ATTRIBUTE_UNUSED = PDdissipationNth2(&B1[index]);
    const CCTK_REAL PDdissipationNth3B1 CCTK_ATTRIBUTE_UNUSED = PDdissipationNth3(&B1[index]);
    const CCTK_REAL PDupwindNthSymm1B2 CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm1(&B2[index]);
    const CCTK_REAL PDupwindNthSymm2B2 CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm2(&B2[index]);
    const CCTK_REAL PDupwindNthSymm3B2 CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm3(&B2[index]);
    const CCTK_REAL PDupwindNthAnti1B2 CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti1(&B2[index]);
    const CCTK_REAL PDupwindNthAnti2B2 CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti2(&B2[index]);
    const CCTK_REAL PDupwindNthAnti3B2 CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti3(&B2[index]);
    const CCTK_REAL PDdissipationNth1B2 CCTK_ATTRIBUTE_UNUSED = PDdissipationNth1(&B2[index]);
    const CCTK_REAL PDdissipationNth2B2 CCTK_ATTRIBUTE_UNUSED = PDdissipationNth2(&B2[index]);
    const CCTK_REAL PDdissipationNth3B2 CCTK_ATTRIBUTE_UNUSED = PDdissipationNth3(&B2[index]);
    const CCTK_REAL PDupwindNthSymm1B3 CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm1(&B3[index]);
    const CCTK_REAL PDupwindNthSymm2B3 CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm2(&B3[index]);
    const CCTK_REAL PDupwindNthSymm3B3 CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm3(&B3[index]);
    const CCTK_REAL PDupwindNthAnti1B3 CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti1(&B3[index]);
    const CCTK_REAL PDupwindNthAnti2B3 CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti2(&B3[index]);
    const CCTK_REAL PDupwindNthAnti3B3 CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti3(&B3[index]);
    const CCTK_REAL PDdissipationNth1B3 CCTK_ATTRIBUTE_UNUSED = PDdissipationNth1(&B3[index]);
    const CCTK_REAL PDdissipationNth2B3 CCTK_ATTRIBUTE_UNUSED = PDdissipationNth2(&B3[index]);
    const CCTK_REAL PDdissipationNth3B3 CCTK_ATTRIBUTE_UNUSED = PDdissipationNth3(&B3[index]);
    const CCTK_REAL PDstandardNth1beta1 CCTK_ATTRIBUTE_UNUSED = PDstandardNth1(&beta1[index]);
    const CCTK_REAL PDstandardNth2beta1 CCTK_ATTRIBUTE_UNUSED = PDstandardNth2(&beta1[index]);
    const CCTK_REAL PDstandardNth3beta1 CCTK_ATTRIBUTE_UNUSED = PDstandardNth3(&beta1[index]);
    const CCTK_REAL PDstandardNth11beta1 CCTK_ATTRIBUTE_UNUSED = PDstandardNth11(&beta1[index]);
    const CCTK_REAL PDstandardNth22beta1 CCTK_ATTRIBUTE_UNUSED = PDstandardNth22(&beta1[index]);
    const CCTK_REAL PDstandardNth33beta1 CCTK_ATTRIBUTE_UNUSED = PDstandardNth33(&beta1[index]);
    const CCTK_REAL PDstandardNth12beta1 CCTK_ATTRIBUTE_UNUSED = PDstandardNth12(&beta1[index]);
    const CCTK_REAL PDstandardNth13beta1 CCTK_ATTRIBUTE_UNUSED = PDstandardNth13(&beta1[index]);
    const CCTK_REAL PDstandardNth23beta1 CCTK_ATTRIBUTE_UNUSED = PDstandardNth23(&beta1[index]);
    const CCTK_REAL PDupwindNthSymm1beta1 CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm1(&beta1[index]);
    const CCTK_REAL PDupwindNthSymm2beta1 CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm2(&beta1[index]);
    const CCTK_REAL PDupwindNthSymm3beta1 CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm3(&beta1[index]);
    const CCTK_REAL PDupwindNthAnti1beta1 CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti1(&beta1[index]);
    const CCTK_REAL PDupwindNthAnti2beta1 CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti2(&beta1[index]);
    const CCTK_REAL PDupwindNthAnti3beta1 CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti3(&beta1[index]);
    const CCTK_REAL PDdissipationNth1beta1 CCTK_ATTRIBUTE_UNUSED = PDdissipationNth1(&beta1[index]);
    const CCTK_REAL PDdissipationNth2beta1 CCTK_ATTRIBUTE_UNUSED = PDdissipationNth2(&beta1[index]);
    const CCTK_REAL PDdissipationNth3beta1 CCTK_ATTRIBUTE_UNUSED = PDdissipationNth3(&beta1[index]);
    const CCTK_REAL PDstandardNth1beta2 CCTK_ATTRIBUTE_UNUSED = PDstandardNth1(&beta2[index]);
    const CCTK_REAL PDstandardNth2beta2 CCTK_ATTRIBUTE_UNUSED = PDstandardNth2(&beta2[index]);
    const CCTK_REAL PDstandardNth3beta2 CCTK_ATTRIBUTE_UNUSED = PDstandardNth3(&beta2[index]);
    const CCTK_REAL PDstandardNth11beta2 CCTK_ATTRIBUTE_UNUSED = PDstandardNth11(&beta2[index]);
    const CCTK_REAL PDstandardNth22beta2 CCTK_ATTRIBUTE_UNUSED = PDstandardNth22(&beta2[index]);
    const CCTK_REAL PDstandardNth33beta2 CCTK_ATTRIBUTE_UNUSED = PDstandardNth33(&beta2[index]);
    const CCTK_REAL PDstandardNth12beta2 CCTK_ATTRIBUTE_UNUSED = PDstandardNth12(&beta2[index]);
    const CCTK_REAL PDstandardNth13beta2 CCTK_ATTRIBUTE_UNUSED = PDstandardNth13(&beta2[index]);
    const CCTK_REAL PDstandardNth23beta2 CCTK_ATTRIBUTE_UNUSED = PDstandardNth23(&beta2[index]);
    const CCTK_REAL PDupwindNthSymm1beta2 CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm1(&beta2[index]);
    const CCTK_REAL PDupwindNthSymm2beta2 CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm2(&beta2[index]);
    const CCTK_REAL PDupwindNthSymm3beta2 CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm3(&beta2[index]);
    const CCTK_REAL PDupwindNthAnti1beta2 CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti1(&beta2[index]);
    const CCTK_REAL PDupwindNthAnti2beta2 CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti2(&beta2[index]);
    const CCTK_REAL PDupwindNthAnti3beta2 CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti3(&beta2[index]);
    const CCTK_REAL PDdissipationNth1beta2 CCTK_ATTRIBUTE_UNUSED = PDdissipationNth1(&beta2[index]);
    const CCTK_REAL PDdissipationNth2beta2 CCTK_ATTRIBUTE_UNUSED = PDdissipationNth2(&beta2[index]);
    const CCTK_REAL PDdissipationNth3beta2 CCTK_ATTRIBUTE_UNUSED = PDdissipationNth3(&beta2[index]);
    const CCTK_REAL PDstandardNth1beta3 CCTK_ATTRIBUTE_UNUSED = PDstandardNth1(&beta3[index]);
    const CCTK_REAL PDstandardNth2beta3 CCTK_ATTRIBUTE_UNUSED = PDstandardNth2(&beta3[index]);
    const CCTK_REAL PDstandardNth3beta3 CCTK_ATTRIBUTE_UNUSED = PDstandardNth3(&beta3[index]);
    const CCTK_REAL PDstandardNth11beta3 CCTK_ATTRIBUTE_UNUSED = PDstandardNth11(&beta3[index]);
    const CCTK_REAL PDstandardNth22beta3 CCTK_ATTRIBUTE_UNUSED = PDstandardNth22(&beta3[index]);
    const CCTK_REAL PDstandardNth33beta3 CCTK_ATTRIBUTE_UNUSED = PDstandardNth33(&beta3[index]);
    const CCTK_REAL PDstandardNth12beta3 CCTK_ATTRIBUTE_UNUSED = PDstandardNth12(&beta3[index]);
    const CCTK_REAL PDstandardNth13beta3 CCTK_ATTRIBUTE_UNUSED = PDstandardNth13(&beta3[index]);
    const CCTK_REAL PDstandardNth23beta3 CCTK_ATTRIBUTE_UNUSED = PDstandardNth23(&beta3[index]);
    const CCTK_REAL PDupwindNthSymm1beta3 CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm1(&beta3[index]);
    const CCTK_REAL PDupwindNthSymm2beta3 CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm2(&beta3[index]);
    const CCTK_REAL PDupwindNthSymm3beta3 CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm3(&beta3[index]);
    const CCTK_REAL PDupwindNthAnti1beta3 CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti1(&beta3[index]);
    const CCTK_REAL PDupwindNthAnti2beta3 CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti2(&beta3[index]);
    const CCTK_REAL PDupwindNthAnti3beta3 CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti3(&beta3[index]);
    const CCTK_REAL PDdissipationNth1beta3 CCTK_ATTRIBUTE_UNUSED = PDdissipationNth1(&beta3[index]);
    const CCTK_REAL PDdissipationNth2beta3 CCTK_ATTRIBUTE_UNUSED = PDdissipationNth2(&beta3[index]);
    const CCTK_REAL PDdissipationNth3beta3 CCTK_ATTRIBUTE_UNUSED = PDdissipationNth3(&beta3[index]);
    const CCTK_REAL PDstandardNth1gt11 CCTK_ATTRIBUTE_UNUSED = PDstandardNth1(&gt11[index]);
    const CCTK_REAL PDstandardNth2gt11 CCTK_ATTRIBUTE_UNUSED = PDstandardNth2(&gt11[index]);
    const CCTK_REAL PDstandardNth3gt11 CCTK_ATTRIBUTE_UNUSED = PDstandardNth3(&gt11[index]);
    const CCTK_REAL PDstandardNth11gt11 CCTK_ATTRIBUTE_UNUSED = PDstandardNth11(&gt11[index]);
    const CCTK_REAL PDstandardNth22gt11 CCTK_ATTRIBUTE_UNUSED = PDstandardNth22(&gt11[index]);
    const CCTK_REAL PDstandardNth33gt11 CCTK_ATTRIBUTE_UNUSED = PDstandardNth33(&gt11[index]);
    const CCTK_REAL PDstandardNth12gt11 CCTK_ATTRIBUTE_UNUSED = PDstandardNth12(&gt11[index]);
    const CCTK_REAL PDstandardNth13gt11 CCTK_ATTRIBUTE_UNUSED = PDstandardNth13(&gt11[index]);
    const CCTK_REAL PDstandardNth23gt11 CCTK_ATTRIBUTE_UNUSED = PDstandardNth23(&gt11[index]);
    const CCTK_REAL PDstandardNth1gt12 CCTK_ATTRIBUTE_UNUSED = PDstandardNth1(&gt12[index]);
    const CCTK_REAL PDstandardNth2gt12 CCTK_ATTRIBUTE_UNUSED = PDstandardNth2(&gt12[index]);
    const CCTK_REAL PDstandardNth3gt12 CCTK_ATTRIBUTE_UNUSED = PDstandardNth3(&gt12[index]);
    const CCTK_REAL PDstandardNth11gt12 CCTK_ATTRIBUTE_UNUSED = PDstandardNth11(&gt12[index]);
    const CCTK_REAL PDstandardNth22gt12 CCTK_ATTRIBUTE_UNUSED = PDstandardNth22(&gt12[index]);
    const CCTK_REAL PDstandardNth33gt12 CCTK_ATTRIBUTE_UNUSED = PDstandardNth33(&gt12[index]);
    const CCTK_REAL PDstandardNth12gt12 CCTK_ATTRIBUTE_UNUSED = PDstandardNth12(&gt12[index]);
    const CCTK_REAL PDstandardNth13gt12 CCTK_ATTRIBUTE_UNUSED = PDstandardNth13(&gt12[index]);
    const CCTK_REAL PDstandardNth23gt12 CCTK_ATTRIBUTE_UNUSED = PDstandardNth23(&gt12[index]);
    const CCTK_REAL PDstandardNth1gt13 CCTK_ATTRIBUTE_UNUSED = PDstandardNth1(&gt13[index]);
    const CCTK_REAL PDstandardNth2gt13 CCTK_ATTRIBUTE_UNUSED = PDstandardNth2(&gt13[index]);
    const CCTK_REAL PDstandardNth3gt13 CCTK_ATTRIBUTE_UNUSED = PDstandardNth3(&gt13[index]);
    const CCTK_REAL PDstandardNth11gt13 CCTK_ATTRIBUTE_UNUSED = PDstandardNth11(&gt13[index]);
    const CCTK_REAL PDstandardNth22gt13 CCTK_ATTRIBUTE_UNUSED = PDstandardNth22(&gt13[index]);
    const CCTK_REAL PDstandardNth33gt13 CCTK_ATTRIBUTE_UNUSED = PDstandardNth33(&gt13[index]);
    const CCTK_REAL PDstandardNth12gt13 CCTK_ATTRIBUTE_UNUSED = PDstandardNth12(&gt13[index]);
    const CCTK_REAL PDstandardNth13gt13 CCTK_ATTRIBUTE_UNUSED = PDstandardNth13(&gt13[index]);
    const CCTK_REAL PDstandardNth23gt13 CCTK_ATTRIBUTE_UNUSED = PDstandardNth23(&gt13[index]);
    const CCTK_REAL PDstandardNth1gt22 CCTK_ATTRIBUTE_UNUSED = PDstandardNth1(&gt22[index]);
    const CCTK_REAL PDstandardNth2gt22 CCTK_ATTRIBUTE_UNUSED = PDstandardNth2(&gt22[index]);
    const CCTK_REAL PDstandardNth3gt22 CCTK_ATTRIBUTE_UNUSED = PDstandardNth3(&gt22[index]);
    const CCTK_REAL PDstandardNth11gt22 CCTK_ATTRIBUTE_UNUSED = PDstandardNth11(&gt22[index]);
    const CCTK_REAL PDstandardNth22gt22 CCTK_ATTRIBUTE_UNUSED = PDstandardNth22(&gt22[index]);
    const CCTK_REAL PDstandardNth33gt22 CCTK_ATTRIBUTE_UNUSED = PDstandardNth33(&gt22[index]);
    const CCTK_REAL PDstandardNth12gt22 CCTK_ATTRIBUTE_UNUSED = PDstandardNth12(&gt22[index]);
    const CCTK_REAL PDstandardNth13gt22 CCTK_ATTRIBUTE_UNUSED = PDstandardNth13(&gt22[index]);
    const CCTK_REAL PDstandardNth23gt22 CCTK_ATTRIBUTE_UNUSED = PDstandardNth23(&gt22[index]);
    const CCTK_REAL PDstandardNth1gt23 CCTK_ATTRIBUTE_UNUSED = PDstandardNth1(&gt23[index]);
    const CCTK_REAL PDstandardNth2gt23 CCTK_ATTRIBUTE_UNUSED = PDstandardNth2(&gt23[index]);
    const CCTK_REAL PDstandardNth3gt23 CCTK_ATTRIBUTE_UNUSED = PDstandardNth3(&gt23[index]);
    const CCTK_REAL PDstandardNth11gt23 CCTK_ATTRIBUTE_UNUSED = PDstandardNth11(&gt23[index]);
    const CCTK_REAL PDstandardNth22gt23 CCTK_ATTRIBUTE_UNUSED = PDstandardNth22(&gt23[index]);
    const CCTK_REAL PDstandardNth33gt23 CCTK_ATTRIBUTE_UNUSED = PDstandardNth33(&gt23[index]);
    const CCTK_REAL PDstandardNth12gt23 CCTK_ATTRIBUTE_UNUSED = PDstandardNth12(&gt23[index]);
    const CCTK_REAL PDstandardNth13gt23 CCTK_ATTRIBUTE_UNUSED = PDstandardNth13(&gt23[index]);
    const CCTK_REAL PDstandardNth23gt23 CCTK_ATTRIBUTE_UNUSED = PDstandardNth23(&gt23[index]);
    const CCTK_REAL PDstandardNth1gt33 CCTK_ATTRIBUTE_UNUSED = PDstandardNth1(&gt33[index]);
    const CCTK_REAL PDstandardNth2gt33 CCTK_ATTRIBUTE_UNUSED = PDstandardNth2(&gt33[index]);
    const CCTK_REAL PDstandardNth3gt33 CCTK_ATTRIBUTE_UNUSED = PDstandardNth3(&gt33[index]);
    const CCTK_REAL PDstandardNth11gt33 CCTK_ATTRIBUTE_UNUSED = PDstandardNth11(&gt33[index]);
    const CCTK_REAL PDstandardNth22gt33 CCTK_ATTRIBUTE_UNUSED = PDstandardNth22(&gt33[index]);
    const CCTK_REAL PDstandardNth33gt33 CCTK_ATTRIBUTE_UNUSED = PDstandardNth33(&gt33[index]);
    const CCTK_REAL PDstandardNth12gt33 CCTK_ATTRIBUTE_UNUSED = PDstandardNth12(&gt33[index]);
    const CCTK_REAL PDstandardNth13gt33 CCTK_ATTRIBUTE_UNUSED = PDstandardNth13(&gt33[index]);
    const CCTK_REAL PDstandardNth23gt33 CCTK_ATTRIBUTE_UNUSED = PDstandardNth23(&gt33[index]);
    const CCTK_REAL PDstandardNth1phi CCTK_ATTRIBUTE_UNUSED = PDstandardNth1(&phi[index]);
    const CCTK_REAL PDstandardNth2phi CCTK_ATTRIBUTE_UNUSED = PDstandardNth2(&phi[index]);
    const CCTK_REAL PDstandardNth3phi CCTK_ATTRIBUTE_UNUSED = PDstandardNth3(&phi[index]);
    const CCTK_REAL PDstandardNth11phi CCTK_ATTRIBUTE_UNUSED = PDstandardNth11(&phi[index]);
    const CCTK_REAL PDstandardNth22phi CCTK_ATTRIBUTE_UNUSED = PDstandardNth22(&phi[index]);
    const CCTK_REAL PDstandardNth33phi CCTK_ATTRIBUTE_UNUSED = PDstandardNth33(&phi[index]);
    const CCTK_REAL PDstandardNth12phi CCTK_ATTRIBUTE_UNUSED = PDstandardNth12(&phi[index]);
    const CCTK_REAL PDstandardNth13phi CCTK_ATTRIBUTE_UNUSED = PDstandardNth13(&phi[index]);
    const CCTK_REAL PDstandardNth23phi CCTK_ATTRIBUTE_UNUSED = PDstandardNth23(&phi[index]);
    const CCTK_REAL PDstandardNth1Theta CCTK_ATTRIBUTE_UNUSED = PDstandardNth1(&Theta[index]);
    const CCTK_REAL PDstandardNth2Theta CCTK_ATTRIBUTE_UNUSED = PDstandardNth2(&Theta[index]);
    const CCTK_REAL PDstandardNth3Theta CCTK_ATTRIBUTE_UNUSED = PDstandardNth3(&Theta[index]);
    const CCTK_REAL PDupwindNthSymm1Theta CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm1(&Theta[index]);
    const CCTK_REAL PDupwindNthSymm2Theta CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm2(&Theta[index]);
    const CCTK_REAL PDupwindNthSymm3Theta CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm3(&Theta[index]);
    const CCTK_REAL PDupwindNthAnti1Theta CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti1(&Theta[index]);
    const CCTK_REAL PDupwindNthAnti2Theta CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti2(&Theta[index]);
    const CCTK_REAL PDupwindNthAnti3Theta CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti3(&Theta[index]);
    const CCTK_REAL PDdissipationNth1Theta CCTK_ATTRIBUTE_UNUSED = PDdissipationNth1(&Theta[index]);
    const CCTK_REAL PDdissipationNth2Theta CCTK_ATTRIBUTE_UNUSED = PDdissipationNth2(&Theta[index]);
    const CCTK_REAL PDdissipationNth3Theta CCTK_ATTRIBUTE_UNUSED = PDdissipationNth3(&Theta[index]);
    const CCTK_REAL PDstandardNth1trK CCTK_ATTRIBUTE_UNUSED = PDstandardNth1(&trK[index]);
    const CCTK_REAL PDstandardNth2trK CCTK_ATTRIBUTE_UNUSED = PDstandardNth2(&trK[index]);
    const CCTK_REAL PDstandardNth3trK CCTK_ATTRIBUTE_UNUSED = PDstandardNth3(&trK[index]);
    const CCTK_REAL PDupwindNthSymm1trK CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm1(&trK[index]);
    const CCTK_REAL PDupwindNthSymm2trK CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm2(&trK[index]);
    const CCTK_REAL PDupwindNthSymm3trK CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm3(&trK[index]);
    const CCTK_REAL PDupwindNthAnti1trK CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti1(&trK[index]);
    const CCTK_REAL PDupwindNthAnti2trK CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti2(&trK[index]);
    const CCTK_REAL PDupwindNthAnti3trK CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti3(&trK[index]);
    const CCTK_REAL PDdissipationNth1trK CCTK_ATTRIBUTE_UNUSED = PDdissipationNth1(&trK[index]);
    const CCTK_REAL PDdissipationNth2trK CCTK_ATTRIBUTE_UNUSED = PDdissipationNth2(&trK[index]);
    const CCTK_REAL PDdissipationNth3trK CCTK_ATTRIBUTE_UNUSED = PDdissipationNth3(&trK[index]);
    const CCTK_REAL PDstandardNth1Xt1 CCTK_ATTRIBUTE_UNUSED = PDstandardNth1(&Xt1[index]);
    const CCTK_REAL PDstandardNth2Xt1 CCTK_ATTRIBUTE_UNUSED = PDstandardNth2(&Xt1[index]);
    const CCTK_REAL PDstandardNth3Xt1 CCTK_ATTRIBUTE_UNUSED = PDstandardNth3(&Xt1[index]);
    const CCTK_REAL PDupwindNthSymm1Xt1 CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm1(&Xt1[index]);
    const CCTK_REAL PDupwindNthSymm2Xt1 CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm2(&Xt1[index]);
    const CCTK_REAL PDupwindNthSymm3Xt1 CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm3(&Xt1[index]);
    const CCTK_REAL PDupwindNthAnti1Xt1 CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti1(&Xt1[index]);
    const CCTK_REAL PDupwindNthAnti2Xt1 CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti2(&Xt1[index]);
    const CCTK_REAL PDupwindNthAnti3Xt1 CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti3(&Xt1[index]);
    const CCTK_REAL PDdissipationNth1Xt1 CCTK_ATTRIBUTE_UNUSED = PDdissipationNth1(&Xt1[index]);
    const CCTK_REAL PDdissipationNth2Xt1 CCTK_ATTRIBUTE_UNUSED = PDdissipationNth2(&Xt1[index]);
    const CCTK_REAL PDdissipationNth3Xt1 CCTK_ATTRIBUTE_UNUSED = PDdissipationNth3(&Xt1[index]);
    const CCTK_REAL PDstandardNth1Xt2 CCTK_ATTRIBUTE_UNUSED = PDstandardNth1(&Xt2[index]);
    const CCTK_REAL PDstandardNth2Xt2 CCTK_ATTRIBUTE_UNUSED = PDstandardNth2(&Xt2[index]);
    const CCTK_REAL PDstandardNth3Xt2 CCTK_ATTRIBUTE_UNUSED = PDstandardNth3(&Xt2[index]);
    const CCTK_REAL PDupwindNthSymm1Xt2 CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm1(&Xt2[index]);
    const CCTK_REAL PDupwindNthSymm2Xt2 CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm2(&Xt2[index]);
    const CCTK_REAL PDupwindNthSymm3Xt2 CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm3(&Xt2[index]);
    const CCTK_REAL PDupwindNthAnti1Xt2 CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti1(&Xt2[index]);
    const CCTK_REAL PDupwindNthAnti2Xt2 CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti2(&Xt2[index]);
    const CCTK_REAL PDupwindNthAnti3Xt2 CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti3(&Xt2[index]);
    const CCTK_REAL PDdissipationNth1Xt2 CCTK_ATTRIBUTE_UNUSED = PDdissipationNth1(&Xt2[index]);
    const CCTK_REAL PDdissipationNth2Xt2 CCTK_ATTRIBUTE_UNUSED = PDdissipationNth2(&Xt2[index]);
    const CCTK_REAL PDdissipationNth3Xt2 CCTK_ATTRIBUTE_UNUSED = PDdissipationNth3(&Xt2[index]);
    const CCTK_REAL PDstandardNth1Xt3 CCTK_ATTRIBUTE_UNUSED = PDstandardNth1(&Xt3[index]);
    const CCTK_REAL PDstandardNth2Xt3 CCTK_ATTRIBUTE_UNUSED = PDstandardNth2(&Xt3[index]);
    const CCTK_REAL PDstandardNth3Xt3 CCTK_ATTRIBUTE_UNUSED = PDstandardNth3(&Xt3[index]);
    const CCTK_REAL PDupwindNthSymm1Xt3 CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm1(&Xt3[index]);
    const CCTK_REAL PDupwindNthSymm2Xt3 CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm2(&Xt3[index]);
    const CCTK_REAL PDupwindNthSymm3Xt3 CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm3(&Xt3[index]);
    const CCTK_REAL PDupwindNthAnti1Xt3 CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti1(&Xt3[index]);
    const CCTK_REAL PDupwindNthAnti2Xt3 CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti2(&Xt3[index]);
    const CCTK_REAL PDupwindNthAnti3Xt3 CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti3(&Xt3[index]);
    const CCTK_REAL PDdissipationNth1Xt3 CCTK_ATTRIBUTE_UNUSED = PDdissipationNth1(&Xt3[index]);
    const CCTK_REAL PDdissipationNth2Xt3 CCTK_ATTRIBUTE_UNUSED = PDdissipationNth2(&Xt3[index]);
    const CCTK_REAL PDdissipationNth3Xt3 CCTK_ATTRIBUTE_UNUSED = PDdissipationNth3(&Xt3[index]);
    /* Calculate temporaries and grid functions */
    CCTK_REAL epsdiss1 CCTK_ATTRIBUTE_UNUSED = epsDiss;
    
    CCTK_REAL epsdiss2 CCTK_ATTRIBUTE_UNUSED = epsDiss;
    
    CCTK_REAL epsdiss3 CCTK_ATTRIBUTE_UNUSED = epsDiss;
    
    CCTK_REAL detgt CCTK_ATTRIBUTE_UNUSED = 1;
    
    CCTK_REAL gtu11 CCTK_ATTRIBUTE_UNUSED = (gt22L*gt33L - 
      pow(gt23L,2))*pow(detgt,-1);
    
    CCTK_REAL gtu12 CCTK_ATTRIBUTE_UNUSED = (gt13L*gt23L - 
      gt12L*gt33L)*pow(detgt,-1);
    
    CCTK_REAL gtu13 CCTK_ATTRIBUTE_UNUSED = (-(gt13L*gt22L) + 
      gt12L*gt23L)*pow(detgt,-1);
    
    CCTK_REAL gtu22 CCTK_ATTRIBUTE_UNUSED = (gt11L*gt33L - 
      pow(gt13L,2))*pow(detgt,-1);
    
    CCTK_REAL gtu23 CCTK_ATTRIBUTE_UNUSED = (gt12L*gt13L - 
      gt11L*gt23L)*pow(detgt,-1);
    
    CCTK_REAL gtu33 CCTK_ATTRIBUTE_UNUSED = (gt11L*gt22L - 
      pow(gt12L,2))*pow(detgt,-1);
    
    CCTK_REAL Gtl111 CCTK_ATTRIBUTE_UNUSED = 0.5*PDstandardNth1gt11;
    
    CCTK_REAL Gtl112 CCTK_ATTRIBUTE_UNUSED = 0.5*PDstandardNth2gt11;
    
    CCTK_REAL Gtl113 CCTK_ATTRIBUTE_UNUSED = 0.5*PDstandardNth3gt11;
    
    CCTK_REAL Gtl122 CCTK_ATTRIBUTE_UNUSED = -0.5*PDstandardNth1gt22 + 
      PDstandardNth2gt12;
    
    CCTK_REAL Gtl123 CCTK_ATTRIBUTE_UNUSED = 0.5*(-PDstandardNth1gt23 + 
      PDstandardNth2gt13 + PDstandardNth3gt12);
    
    CCTK_REAL Gtl133 CCTK_ATTRIBUTE_UNUSED = -0.5*PDstandardNth1gt33 + 
      PDstandardNth3gt13;
    
    CCTK_REAL Gtl211 CCTK_ATTRIBUTE_UNUSED = PDstandardNth1gt12 - 
      0.5*PDstandardNth2gt11;
    
    CCTK_REAL Gtl212 CCTK_ATTRIBUTE_UNUSED = 0.5*PDstandardNth1gt22;
    
    CCTK_REAL Gtl213 CCTK_ATTRIBUTE_UNUSED = 0.5*(PDstandardNth1gt23 - 
      PDstandardNth2gt13 + PDstandardNth3gt12);
    
    CCTK_REAL Gtl222 CCTK_ATTRIBUTE_UNUSED = 0.5*PDstandardNth2gt22;
    
    CCTK_REAL Gtl223 CCTK_ATTRIBUTE_UNUSED = 0.5*PDstandardNth3gt22;
    
    CCTK_REAL Gtl233 CCTK_ATTRIBUTE_UNUSED = -0.5*PDstandardNth2gt33 + 
      PDstandardNth3gt23;
    
    CCTK_REAL Gtl311 CCTK_ATTRIBUTE_UNUSED = PDstandardNth1gt13 - 
      0.5*PDstandardNth3gt11;
    
    CCTK_REAL Gtl312 CCTK_ATTRIBUTE_UNUSED = 0.5*(PDstandardNth1gt23 + 
      PDstandardNth2gt13 - PDstandardNth3gt12);
    
    CCTK_REAL Gtl313 CCTK_ATTRIBUTE_UNUSED = 0.5*PDstandardNth1gt33;
    
    CCTK_REAL Gtl322 CCTK_ATTRIBUTE_UNUSED = PDstandardNth2gt23 - 
      0.5*PDstandardNth3gt22;
    
    CCTK_REAL Gtl323 CCTK_ATTRIBUTE_UNUSED = 0.5*PDstandardNth2gt33;
    
    CCTK_REAL Gtl333 CCTK_ATTRIBUTE_UNUSED = 0.5*PDstandardNth3gt33;
    
    CCTK_REAL Gtlu111 CCTK_ATTRIBUTE_UNUSED = Gtl111*gtu11 + Gtl112*gtu12 
      + Gtl113*gtu13;
    
    CCTK_REAL Gtlu112 CCTK_ATTRIBUTE_UNUSED = Gtl111*gtu12 + Gtl112*gtu22 
      + Gtl113*gtu23;
    
    CCTK_REAL Gtlu113 CCTK_ATTRIBUTE_UNUSED = Gtl111*gtu13 + Gtl112*gtu23 
      + Gtl113*gtu33;
    
    CCTK_REAL Gtlu121 CCTK_ATTRIBUTE_UNUSED = Gtl112*gtu11 + Gtl122*gtu12 
      + Gtl123*gtu13;
    
    CCTK_REAL Gtlu122 CCTK_ATTRIBUTE_UNUSED = Gtl112*gtu12 + Gtl122*gtu22 
      + Gtl123*gtu23;
    
    CCTK_REAL Gtlu123 CCTK_ATTRIBUTE_UNUSED = Gtl112*gtu13 + Gtl122*gtu23 
      + Gtl123*gtu33;
    
    CCTK_REAL Gtlu131 CCTK_ATTRIBUTE_UNUSED = Gtl113*gtu11 + Gtl123*gtu12 
      + Gtl133*gtu13;
    
    CCTK_REAL Gtlu132 CCTK_ATTRIBUTE_UNUSED = Gtl113*gtu12 + Gtl123*gtu22 
      + Gtl133*gtu23;
    
    CCTK_REAL Gtlu133 CCTK_ATTRIBUTE_UNUSED = Gtl113*gtu13 + Gtl123*gtu23 
      + Gtl133*gtu33;
    
    CCTK_REAL Gtlu211 CCTK_ATTRIBUTE_UNUSED = Gtl211*gtu11 + Gtl212*gtu12 
      + Gtl213*gtu13;
    
    CCTK_REAL Gtlu212 CCTK_ATTRIBUTE_UNUSED = Gtl211*gtu12 + Gtl212*gtu22 
      + Gtl213*gtu23;
    
    CCTK_REAL Gtlu213 CCTK_ATTRIBUTE_UNUSED = Gtl211*gtu13 + Gtl212*gtu23 
      + Gtl213*gtu33;
    
    CCTK_REAL Gtlu221 CCTK_ATTRIBUTE_UNUSED = Gtl212*gtu11 + Gtl222*gtu12 
      + Gtl223*gtu13;
    
    CCTK_REAL Gtlu222 CCTK_ATTRIBUTE_UNUSED = Gtl212*gtu12 + Gtl222*gtu22 
      + Gtl223*gtu23;
    
    CCTK_REAL Gtlu223 CCTK_ATTRIBUTE_UNUSED = Gtl212*gtu13 + Gtl222*gtu23 
      + Gtl223*gtu33;
    
    CCTK_REAL Gtlu231 CCTK_ATTRIBUTE_UNUSED = Gtl213*gtu11 + Gtl223*gtu12 
      + Gtl233*gtu13;
    
    CCTK_REAL Gtlu232 CCTK_ATTRIBUTE_UNUSED = Gtl213*gtu12 + Gtl223*gtu22 
      + Gtl233*gtu23;
    
    CCTK_REAL Gtlu233 CCTK_ATTRIBUTE_UNUSED = Gtl213*gtu13 + Gtl223*gtu23 
      + Gtl233*gtu33;
    
    CCTK_REAL Gtlu311 CCTK_ATTRIBUTE_UNUSED = Gtl311*gtu11 + Gtl312*gtu12 
      + Gtl313*gtu13;
    
    CCTK_REAL Gtlu312 CCTK_ATTRIBUTE_UNUSED = Gtl311*gtu12 + Gtl312*gtu22 
      + Gtl313*gtu23;
    
    CCTK_REAL Gtlu313 CCTK_ATTRIBUTE_UNUSED = Gtl311*gtu13 + Gtl312*gtu23 
      + Gtl313*gtu33;
    
    CCTK_REAL Gtlu321 CCTK_ATTRIBUTE_UNUSED = Gtl312*gtu11 + Gtl322*gtu12 
      + Gtl323*gtu13;
    
    CCTK_REAL Gtlu322 CCTK_ATTRIBUTE_UNUSED = Gtl312*gtu12 + Gtl322*gtu22 
      + Gtl323*gtu23;
    
    CCTK_REAL Gtlu323 CCTK_ATTRIBUTE_UNUSED = Gtl312*gtu13 + Gtl322*gtu23 
      + Gtl323*gtu33;
    
    CCTK_REAL Gtlu331 CCTK_ATTRIBUTE_UNUSED = Gtl313*gtu11 + Gtl323*gtu12 
      + Gtl333*gtu13;
    
    CCTK_REAL Gtlu332 CCTK_ATTRIBUTE_UNUSED = Gtl313*gtu12 + Gtl323*gtu22 
      + Gtl333*gtu23;
    
    CCTK_REAL Gtlu333 CCTK_ATTRIBUTE_UNUSED = Gtl313*gtu13 + Gtl323*gtu23 
      + Gtl333*gtu33;
    
    CCTK_REAL Gt111 CCTK_ATTRIBUTE_UNUSED = Gtl111*gtu11 + Gtl211*gtu12 + 
      Gtl311*gtu13;
    
    CCTK_REAL Gt211 CCTK_ATTRIBUTE_UNUSED = Gtl111*gtu12 + Gtl211*gtu22 + 
      Gtl311*gtu23;
    
    CCTK_REAL Gt311 CCTK_ATTRIBUTE_UNUSED = Gtl111*gtu13 + Gtl211*gtu23 + 
      Gtl311*gtu33;
    
    CCTK_REAL Gt112 CCTK_ATTRIBUTE_UNUSED = Gtl112*gtu11 + Gtl212*gtu12 + 
      Gtl312*gtu13;
    
    CCTK_REAL Gt212 CCTK_ATTRIBUTE_UNUSED = Gtl112*gtu12 + Gtl212*gtu22 + 
      Gtl312*gtu23;
    
    CCTK_REAL Gt312 CCTK_ATTRIBUTE_UNUSED = Gtl112*gtu13 + Gtl212*gtu23 + 
      Gtl312*gtu33;
    
    CCTK_REAL Gt113 CCTK_ATTRIBUTE_UNUSED = Gtl113*gtu11 + Gtl213*gtu12 + 
      Gtl313*gtu13;
    
    CCTK_REAL Gt213 CCTK_ATTRIBUTE_UNUSED = Gtl113*gtu12 + Gtl213*gtu22 + 
      Gtl313*gtu23;
    
    CCTK_REAL Gt313 CCTK_ATTRIBUTE_UNUSED = Gtl113*gtu13 + Gtl213*gtu23 + 
      Gtl313*gtu33;
    
    CCTK_REAL Gt122 CCTK_ATTRIBUTE_UNUSED = Gtl122*gtu11 + Gtl222*gtu12 + 
      Gtl322*gtu13;
    
    CCTK_REAL Gt222 CCTK_ATTRIBUTE_UNUSED = Gtl122*gtu12 + Gtl222*gtu22 + 
      Gtl322*gtu23;
    
    CCTK_REAL Gt322 CCTK_ATTRIBUTE_UNUSED = Gtl122*gtu13 + Gtl222*gtu23 + 
      Gtl322*gtu33;
    
    CCTK_REAL Gt123 CCTK_ATTRIBUTE_UNUSED = Gtl123*gtu11 + Gtl223*gtu12 + 
      Gtl323*gtu13;
    
    CCTK_REAL Gt223 CCTK_ATTRIBUTE_UNUSED = Gtl123*gtu12 + Gtl223*gtu22 + 
      Gtl323*gtu23;
    
    CCTK_REAL Gt323 CCTK_ATTRIBUTE_UNUSED = Gtl123*gtu13 + Gtl223*gtu23 + 
      Gtl323*gtu33;
    
    CCTK_REAL Gt133 CCTK_ATTRIBUTE_UNUSED = Gtl133*gtu11 + Gtl233*gtu12 + 
      Gtl333*gtu13;
    
    CCTK_REAL Gt233 CCTK_ATTRIBUTE_UNUSED = Gtl133*gtu12 + Gtl233*gtu22 + 
      Gtl333*gtu23;
    
    CCTK_REAL Gt333 CCTK_ATTRIBUTE_UNUSED = Gtl133*gtu13 + Gtl233*gtu23 + 
      Gtl333*gtu33;
    
    CCTK_REAL em4phi CCTK_ATTRIBUTE_UNUSED = pow(phiL,2);
    
    CCTK_REAL e4phi CCTK_ATTRIBUTE_UNUSED = pow(em4phi,-1);
    
    CCTK_REAL g11 CCTK_ATTRIBUTE_UNUSED = gt11L*e4phi;
    
    CCTK_REAL g12 CCTK_ATTRIBUTE_UNUSED = gt12L*e4phi;
    
    CCTK_REAL g13 CCTK_ATTRIBUTE_UNUSED = gt13L*e4phi;
    
    CCTK_REAL g22 CCTK_ATTRIBUTE_UNUSED = gt22L*e4phi;
    
    CCTK_REAL g23 CCTK_ATTRIBUTE_UNUSED = gt23L*e4phi;
    
    CCTK_REAL g33 CCTK_ATTRIBUTE_UNUSED = gt33L*e4phi;
    
    CCTK_REAL gu11 CCTK_ATTRIBUTE_UNUSED = em4phi*gtu11;
    
    CCTK_REAL gu12 CCTK_ATTRIBUTE_UNUSED = em4phi*gtu12;
    
    CCTK_REAL gu13 CCTK_ATTRIBUTE_UNUSED = em4phi*gtu13;
    
    CCTK_REAL gu22 CCTK_ATTRIBUTE_UNUSED = em4phi*gtu22;
    
    CCTK_REAL gu23 CCTK_ATTRIBUTE_UNUSED = em4phi*gtu23;
    
    CCTK_REAL gu33 CCTK_ATTRIBUTE_UNUSED = em4phi*gtu33;
    
    CCTK_REAL Xtn1 CCTK_ATTRIBUTE_UNUSED = Gt111*gtu11 + Gt122*gtu22 + 
      2*(Gt112*gtu12 + Gt113*gtu13 + Gt123*gtu23) + Gt133*gtu33;
    
    CCTK_REAL Xtn2 CCTK_ATTRIBUTE_UNUSED = Gt211*gtu11 + Gt222*gtu22 + 
      2*(Gt212*gtu12 + Gt213*gtu13 + Gt223*gtu23) + Gt233*gtu33;
    
    CCTK_REAL Xtn3 CCTK_ATTRIBUTE_UNUSED = Gt311*gtu11 + Gt322*gtu22 + 
      2*(Gt312*gtu12 + Gt313*gtu13 + Gt323*gtu23) + Gt333*gtu33;
    
    CCTK_REAL Zl1 CCTK_ATTRIBUTE_UNUSED = 0.5*(gt11L*Xt1L + gt12L*Xt2L + 
      gt13L*Xt3L - gtu11*PDstandardNth1gt11 + gtu12*(-PDstandardNth1gt12 - 
      PDstandardNth2gt11) - gtu22*PDstandardNth2gt12 + 
      gtu13*(-PDstandardNth1gt13 - PDstandardNth3gt11) + 
      gtu23*(-PDstandardNth2gt13 - PDstandardNth3gt12) - 
      gtu33*PDstandardNth3gt13);
    
    CCTK_REAL Zl2 CCTK_ATTRIBUTE_UNUSED = 0.5*(gt12L*Xt1L + gt22L*Xt2L + 
      gt23L*Xt3L - gtu11*PDstandardNth1gt12 + gtu12*(-PDstandardNth1gt22 - 
      PDstandardNth2gt12) - gtu22*PDstandardNth2gt22 + 
      gtu13*(-PDstandardNth1gt23 - PDstandardNth3gt12) + 
      gtu23*(-PDstandardNth2gt23 - PDstandardNth3gt22) - 
      gtu33*PDstandardNth3gt23);
    
    CCTK_REAL Zl3 CCTK_ATTRIBUTE_UNUSED = 0.5*(gt13L*Xt1L + gt23L*Xt2L + 
      gt33L*Xt3L - gtu11*PDstandardNth1gt13 + gtu12*(-PDstandardNth1gt23 - 
      PDstandardNth2gt13) - gtu22*PDstandardNth2gt23 + 
      gtu13*(-PDstandardNth1gt33 - PDstandardNth3gt13) + 
      gtu23*(-PDstandardNth2gt33 - PDstandardNth3gt23) - 
      gtu33*PDstandardNth3gt33);
    
    CCTK_REAL Z1 CCTK_ATTRIBUTE_UNUSED = gu11*Zl1 + gu12*Zl2 + gu13*Zl3;
    
    CCTK_REAL Z2 CCTK_ATTRIBUTE_UNUSED = gu12*Zl1 + gu22*Zl2 + gu23*Zl3;
    
    CCTK_REAL Z3 CCTK_ATTRIBUTE_UNUSED = gu13*Zl1 + gu23*Zl2 + gu33*Zl3;
    
    CCTK_REAL Rt11 CCTK_ATTRIBUTE_UNUSED = 3*(Gt111*Gtlu111 + 
      Gt112*Gtlu112 + Gt113*Gtlu113) + 2*(Gt211*Gtlu121 + Gt212*Gtlu122 + 
      Gt213*Gtlu123 + Gt311*Gtlu131 + Gt312*Gtlu132 + Gt313*Gtlu133) + 
      Gt211*Gtlu211 + Gt212*Gtlu212 + Gt213*Gtlu213 + Gt311*Gtlu311 + 
      Gt312*Gtlu312 + Gt313*Gtlu313 + gt11L*PDstandardNth1Xt1 + 
      gt12L*PDstandardNth1Xt2 + gt13L*PDstandardNth1Xt3 + 
      0.5*(-(gtu11*PDstandardNth11gt11) - 2*gtu12*PDstandardNth12gt11 - 
      2*gtu13*PDstandardNth13gt11 - gtu22*PDstandardNth22gt11 - 
      2*gtu23*PDstandardNth23gt11 - gtu33*PDstandardNth33gt11) + Gtl111*Xtn1 
      + Gtl112*Xtn2 + Gtl113*Xtn3;
    
    CCTK_REAL Rt12 CCTK_ATTRIBUTE_UNUSED = 0.5*(4*(Gt211*Gtlu221 + 
      Gt212*Gtlu222 + Gt213*Gtlu223) + 2*(Gt112*Gtlu111 + Gt122*Gtlu112 + 
      Gt123*Gtlu113 + Gt111*Gtlu121 + Gt212*Gtlu121 + Gt112*Gtlu122 + 
      Gt222*Gtlu122 + Gt113*Gtlu123 + Gt223*Gtlu123 + Gt312*Gtlu131 + 
      Gt322*Gtlu132 + Gt323*Gtlu133 + Gt111*Gtlu211 + Gt112*Gtlu212 + 
      Gt113*Gtlu213 + Gt311*Gtlu231 + Gt312*Gtlu232 + Gt313*Gtlu233 + 
      Gt311*Gtlu321 + Gt312*Gtlu322 + Gt313*Gtlu323) - 
      gtu11*PDstandardNth11gt12 - 2*gtu12*PDstandardNth12gt12 - 
      2*gtu13*PDstandardNth13gt12 + gt12L*PDstandardNth1Xt1 + 
      gt22L*PDstandardNth1Xt2 + gt23L*PDstandardNth1Xt3 - 
      gtu22*PDstandardNth22gt12 - 2*gtu23*PDstandardNth23gt12 + 
      gt11L*PDstandardNth2Xt1 + gt12L*PDstandardNth2Xt2 + 
      gt13L*PDstandardNth2Xt3 - gtu33*PDstandardNth33gt12 + Gtl112*Xtn1 + 
      Gtl211*Xtn1 + Gtl122*Xtn2 + Gtl212*Xtn2 + Gtl123*Xtn3 + Gtl213*Xtn3);
    
    CCTK_REAL Rt13 CCTK_ATTRIBUTE_UNUSED = 0.5*(2*(Gt113*Gtlu111 + 
      Gt123*Gtlu112 + Gt133*Gtlu113 + Gt213*Gtlu121 + Gt223*Gtlu122 + 
      Gt233*Gtlu123 + Gt111*Gtlu131 + Gt313*Gtlu131 + Gt112*Gtlu132 + 
      Gt323*Gtlu132 + Gt113*Gtlu133 + Gt333*Gtlu133 + Gt211*Gtlu231 + 
      Gt212*Gtlu232 + Gt213*Gtlu233 + Gt111*Gtlu311 + Gt112*Gtlu312 + 
      Gt113*Gtlu313 + Gt211*Gtlu321 + Gt212*Gtlu322 + Gt213*Gtlu323) + 
      4*(Gt311*Gtlu331 + Gt312*Gtlu332 + Gt313*Gtlu333) - 
      gtu11*PDstandardNth11gt13 - 2*gtu12*PDstandardNth12gt13 - 
      2*gtu13*PDstandardNth13gt13 + gt13L*PDstandardNth1Xt1 + 
      gt23L*PDstandardNth1Xt2 + gt33L*PDstandardNth1Xt3 - 
      gtu22*PDstandardNth22gt13 - 2*gtu23*PDstandardNth23gt13 - 
      gtu33*PDstandardNth33gt13 + gt11L*PDstandardNth3Xt1 + 
      gt12L*PDstandardNth3Xt2 + gt13L*PDstandardNth3Xt3 + Gtl113*Xtn1 + 
      Gtl311*Xtn1 + Gtl123*Xtn2 + Gtl312*Xtn2 + Gtl133*Xtn3 + Gtl313*Xtn3);
    
    CCTK_REAL Rt22 CCTK_ATTRIBUTE_UNUSED = Gt112*(Gtlu121 + 2*Gtlu211) + 
      Gt122*(Gtlu122 + 2*Gtlu212) + Gt123*(Gtlu123 + 2*Gtlu213) + 
      3*(Gt212*Gtlu221 + Gt222*Gtlu222 + Gt223*Gtlu223) + 2*(Gt312*Gtlu231 + 
      Gt322*Gtlu232 + Gt323*Gtlu233) + Gt312*Gtlu321 + Gt322*Gtlu322 + 
      Gt323*Gtlu323 + gt12L*PDstandardNth2Xt1 + gt22L*PDstandardNth2Xt2 + 
      gt23L*PDstandardNth2Xt3 + 0.5*(-(gtu11*PDstandardNth11gt22) - 
      2*gtu12*PDstandardNth12gt22 - 2*gtu13*PDstandardNth13gt22 - 
      gtu22*PDstandardNth22gt22 - 2*gtu23*PDstandardNth23gt22 - 
      gtu33*PDstandardNth33gt22) + Gtl212*Xtn1 + Gtl222*Xtn2 + Gtl223*Xtn3;
    
    CCTK_REAL Rt23 CCTK_ATTRIBUTE_UNUSED = 0.5*(2*(Gt112*Gtlu131 + 
      Gt122*Gtlu132 + Gt123*Gtlu133 + Gt113*Gtlu211 + Gt123*Gtlu212 + 
      Gt133*Gtlu213 + Gt213*Gtlu221 + Gt223*Gtlu222 + Gt233*Gtlu223 + 
      Gt212*Gtlu231 + Gt313*Gtlu231 + Gt222*Gtlu232 + Gt323*Gtlu232 + 
      Gt223*Gtlu233 + Gt333*Gtlu233 + Gt112*Gtlu311 + Gt122*Gtlu312 + 
      Gt123*Gtlu313 + Gt212*Gtlu321 + Gt222*Gtlu322 + Gt223*Gtlu323) + 
      4*(Gt312*Gtlu331 + Gt322*Gtlu332 + Gt323*Gtlu333) - 
      gtu11*PDstandardNth11gt23 - 2*gtu12*PDstandardNth12gt23 - 
      2*gtu13*PDstandardNth13gt23 - gtu22*PDstandardNth22gt23 - 
      2*gtu23*PDstandardNth23gt23 + gt13L*PDstandardNth2Xt1 + 
      gt23L*PDstandardNth2Xt2 + gt33L*PDstandardNth2Xt3 - 
      gtu33*PDstandardNth33gt23 + gt12L*PDstandardNth3Xt1 + 
      gt22L*PDstandardNth3Xt2 + gt23L*PDstandardNth3Xt3 + Gtl213*Xtn1 + 
      Gtl312*Xtn1 + Gtl223*Xtn2 + Gtl322*Xtn2 + Gtl233*Xtn3 + Gtl323*Xtn3);
    
    CCTK_REAL Rt33 CCTK_ATTRIBUTE_UNUSED = Gt113*(Gtlu131 + 2*Gtlu311) + 
      Gt123*(Gtlu132 + 2*Gtlu312) + Gt133*(Gtlu133 + 2*Gtlu313) + 
      Gt213*(Gtlu231 + 2*Gtlu321) + Gt223*(Gtlu232 + 2*Gtlu322) + 
      Gt233*(Gtlu233 + 2*Gtlu323) + 3*(Gt313*Gtlu331 + Gt323*Gtlu332 + 
      Gt333*Gtlu333) + 0.5*(-(gtu11*PDstandardNth11gt33) - 
      2*gtu12*PDstandardNth12gt33 - 2*gtu13*PDstandardNth13gt33 - 
      gtu22*PDstandardNth22gt33 - 2*gtu23*PDstandardNth23gt33 - 
      gtu33*PDstandardNth33gt33) + gt13L*PDstandardNth3Xt1 + 
      gt23L*PDstandardNth3Xt2 + gt33L*PDstandardNth3Xt3 + Gtl313*Xtn1 + 
      Gtl323*Xtn2 + Gtl333*Xtn3;
    
    CCTK_REAL fac1 CCTK_ATTRIBUTE_UNUSED = -0.5*pow(phiL,-1);
    
    CCTK_REAL cdphi1 CCTK_ATTRIBUTE_UNUSED = fac1*PDstandardNth1phi;
    
    CCTK_REAL cdphi2 CCTK_ATTRIBUTE_UNUSED = fac1*PDstandardNth2phi;
    
    CCTK_REAL cdphi3 CCTK_ATTRIBUTE_UNUSED = fac1*PDstandardNth3phi;
    
    CCTK_REAL fac2 CCTK_ATTRIBUTE_UNUSED = 0.5*pow(phiL,-2);
    
    CCTK_REAL cdphi211 CCTK_ATTRIBUTE_UNUSED = -(fac1*(-PDstandardNth11phi 
      + Gt111*PDstandardNth1phi + Gt211*PDstandardNth2phi + 
      Gt311*PDstandardNth3phi)) + fac2*pow(PDstandardNth1phi,2);
    
    CCTK_REAL cdphi212 CCTK_ATTRIBUTE_UNUSED = 
      fac2*PDstandardNth1phi*PDstandardNth2phi - fac1*(-PDstandardNth12phi + 
      Gt112*PDstandardNth1phi + Gt212*PDstandardNth2phi + 
      Gt312*PDstandardNth3phi);
    
    CCTK_REAL cdphi213 CCTK_ATTRIBUTE_UNUSED = 
      fac2*PDstandardNth1phi*PDstandardNth3phi - fac1*(-PDstandardNth13phi + 
      Gt113*PDstandardNth1phi + Gt213*PDstandardNth2phi + 
      Gt313*PDstandardNth3phi);
    
    CCTK_REAL cdphi221 CCTK_ATTRIBUTE_UNUSED = 
      fac2*PDstandardNth1phi*PDstandardNth2phi - fac1*(-PDstandardNth12phi + 
      Gt112*PDstandardNth1phi + Gt212*PDstandardNth2phi + 
      Gt312*PDstandardNth3phi);
    
    CCTK_REAL cdphi222 CCTK_ATTRIBUTE_UNUSED = 
      -(fac1*(Gt122*PDstandardNth1phi - PDstandardNth22phi + 
      Gt222*PDstandardNth2phi + Gt322*PDstandardNth3phi)) + 
      fac2*pow(PDstandardNth2phi,2);
    
    CCTK_REAL cdphi223 CCTK_ATTRIBUTE_UNUSED = 
      fac2*PDstandardNth2phi*PDstandardNth3phi - 
      fac1*(Gt123*PDstandardNth1phi - PDstandardNth23phi + 
      Gt223*PDstandardNth2phi + Gt323*PDstandardNth3phi);
    
    CCTK_REAL cdphi231 CCTK_ATTRIBUTE_UNUSED = 
      fac2*PDstandardNth1phi*PDstandardNth3phi - fac1*(-PDstandardNth13phi + 
      Gt113*PDstandardNth1phi + Gt213*PDstandardNth2phi + 
      Gt313*PDstandardNth3phi);
    
    CCTK_REAL cdphi232 CCTK_ATTRIBUTE_UNUSED = 
      fac2*PDstandardNth2phi*PDstandardNth3phi - 
      fac1*(Gt123*PDstandardNth1phi - PDstandardNth23phi + 
      Gt223*PDstandardNth2phi + Gt323*PDstandardNth3phi);
    
    CCTK_REAL cdphi233 CCTK_ATTRIBUTE_UNUSED = 
      -(fac1*(Gt133*PDstandardNth1phi + Gt233*PDstandardNth2phi - 
      PDstandardNth33phi + Gt333*PDstandardNth3phi)) + 
      fac2*pow(PDstandardNth3phi,2);
    
    CCTK_REAL Rphi11 CCTK_ATTRIBUTE_UNUSED = -8*gt11L*cdphi1*(cdphi2*gtu12 
      + cdphi3*gtu13) + (4 - 4*gt11L*gtu11)*pow(cdphi1,2) - 2*(cdphi211 + 
      gt11L*(cdphi211*gtu11 + (cdphi212 + cdphi221)*gtu12 + (cdphi213 + 
      cdphi231)*gtu13 + (cdphi223 + cdphi232 + 4*cdphi2*cdphi3)*gtu23 + 
      gtu22*(cdphi222 + 2*pow(cdphi2,2)) + gtu33*(cdphi233 + 
      2*pow(cdphi3,2))));
    
    CCTK_REAL Rphi12 CCTK_ATTRIBUTE_UNUSED = 4*cdphi1*cdphi2 - 2*(cdphi221 
      + gt12L*(cdphi211*gtu11 + (cdphi212 + cdphi221)*gtu12 + (cdphi213 + 
      cdphi231)*gtu13 + cdphi222*gtu22 + (cdphi223 + cdphi232)*gtu23 + 
      cdphi233*gtu33)) - 4*gt12L*(2*(cdphi1*(cdphi2*gtu12 + cdphi3*gtu13) + 
      cdphi2*cdphi3*gtu23) + gtu11*pow(cdphi1,2) + gtu22*pow(cdphi2,2) + 
      gtu33*pow(cdphi3,2));
    
    CCTK_REAL Rphi13 CCTK_ATTRIBUTE_UNUSED = 4*cdphi1*cdphi3 - 2*(cdphi231 
      + gt13L*(cdphi211*gtu11 + (cdphi212 + cdphi221)*gtu12 + (cdphi213 + 
      cdphi231)*gtu13 + cdphi222*gtu22 + (cdphi223 + cdphi232)*gtu23 + 
      cdphi233*gtu33)) - 4*gt13L*(2*(cdphi1*(cdphi2*gtu12 + cdphi3*gtu13) + 
      cdphi2*cdphi3*gtu23) + gtu11*pow(cdphi1,2) + gtu22*pow(cdphi2,2) + 
      gtu33*pow(cdphi3,2));
    
    CCTK_REAL Rphi22 CCTK_ATTRIBUTE_UNUSED = -8*gt22L*cdphi2*(cdphi1*gtu12 
      + cdphi3*gtu23) + (4 - 4*gt22L*gtu22)*pow(cdphi2,2) - 2*(cdphi222 + 
      gt22L*((cdphi212 + cdphi221)*gtu12 + (cdphi213 + cdphi231 + 
      4*cdphi1*cdphi3)*gtu13 + cdphi222*gtu22 + (cdphi223 + cdphi232)*gtu23 + 
      gtu11*(cdphi211 + 2*pow(cdphi1,2)) + gtu33*(cdphi233 + 
      2*pow(cdphi3,2))));
    
    CCTK_REAL Rphi23 CCTK_ATTRIBUTE_UNUSED = 4*cdphi2*cdphi3 - 2*(cdphi232 
      + gt23L*(cdphi211*gtu11 + (cdphi212 + cdphi221)*gtu12 + (cdphi213 + 
      cdphi231)*gtu13 + cdphi222*gtu22 + (cdphi223 + cdphi232)*gtu23 + 
      cdphi233*gtu33)) - 4*gt23L*(2*(cdphi1*(cdphi2*gtu12 + cdphi3*gtu13) + 
      cdphi2*cdphi3*gtu23) + gtu11*pow(cdphi1,2) + gtu22*pow(cdphi2,2) + 
      gtu33*pow(cdphi3,2));
    
    CCTK_REAL Rphi33 CCTK_ATTRIBUTE_UNUSED = -2*(cdphi233 + 
      gt33L*(cdphi211*gtu11 + (cdphi212 + cdphi221)*gtu12 + (cdphi213 + 
      cdphi231)*gtu13 + cdphi222*gtu22 + (cdphi223 + cdphi232)*gtu23 + 
      cdphi233*gtu33)) + 4*pow(cdphi3,2) - 4*gt33L*(2*(cdphi1*(cdphi2*gtu12 + 
      cdphi3*gtu13) + cdphi2*cdphi3*gtu23) + gtu11*pow(cdphi1,2) + 
      gtu22*pow(cdphi2,2) + gtu33*pow(cdphi3,2));
    
    CCTK_REAL Atm11 CCTK_ATTRIBUTE_UNUSED = At11L*gtu11 + At12L*gtu12 + 
      At13L*gtu13;
    
    CCTK_REAL Atm21 CCTK_ATTRIBUTE_UNUSED = At11L*gtu12 + At12L*gtu22 + 
      At13L*gtu23;
    
    CCTK_REAL Atm31 CCTK_ATTRIBUTE_UNUSED = At11L*gtu13 + At12L*gtu23 + 
      At13L*gtu33;
    
    CCTK_REAL Atm12 CCTK_ATTRIBUTE_UNUSED = At12L*gtu11 + At22L*gtu12 + 
      At23L*gtu13;
    
    CCTK_REAL Atm22 CCTK_ATTRIBUTE_UNUSED = At12L*gtu12 + At22L*gtu22 + 
      At23L*gtu23;
    
    CCTK_REAL Atm32 CCTK_ATTRIBUTE_UNUSED = At12L*gtu13 + At22L*gtu23 + 
      At23L*gtu33;
    
    CCTK_REAL Atm13 CCTK_ATTRIBUTE_UNUSED = At13L*gtu11 + At23L*gtu12 + 
      At33L*gtu13;
    
    CCTK_REAL Atm23 CCTK_ATTRIBUTE_UNUSED = At13L*gtu12 + At23L*gtu22 + 
      At33L*gtu23;
    
    CCTK_REAL Atm33 CCTK_ATTRIBUTE_UNUSED = At13L*gtu13 + At23L*gtu23 + 
      At33L*gtu33;
    
    CCTK_REAL Atu11 CCTK_ATTRIBUTE_UNUSED = Atm11*gtu11 + Atm12*gtu12 + 
      Atm13*gtu13;
    
    CCTK_REAL Atu12 CCTK_ATTRIBUTE_UNUSED = Atm11*gtu12 + Atm12*gtu22 + 
      Atm13*gtu23;
    
    CCTK_REAL Atu13 CCTK_ATTRIBUTE_UNUSED = Atm11*gtu13 + Atm12*gtu23 + 
      Atm13*gtu33;
    
    CCTK_REAL Atu22 CCTK_ATTRIBUTE_UNUSED = Atm21*gtu12 + Atm22*gtu22 + 
      Atm23*gtu23;
    
    CCTK_REAL Atu23 CCTK_ATTRIBUTE_UNUSED = Atm21*gtu13 + Atm22*gtu23 + 
      Atm23*gtu33;
    
    CCTK_REAL Atu33 CCTK_ATTRIBUTE_UNUSED = Atm31*gtu13 + Atm32*gtu23 + 
      Atm33*gtu33;
    
    CCTK_REAL R11 CCTK_ATTRIBUTE_UNUSED = Rphi11 + Rt11 + 
      e4phi*(PDstandardNth1gt11*Z1 + PDstandardNth2gt11*Z2 + 
      PDstandardNth3gt11*Z3) + (-2*g11*(PDstandardNth2phi*Z2 + 
      PDstandardNth3phi*Z3) + 2*PDstandardNth1phi*(g11*Z1 + 2*(g12*Z2 + 
      g13*Z3)))*pow(phiL,-1);
    
    CCTK_REAL R12 CCTK_ATTRIBUTE_UNUSED = ((2*g13*PDstandardNth2phi - 
      2*g12*PDstandardNth3phi)*Z3 + 2*(g11*PDstandardNth2phi*Z1 + 
      PDstandardNth1phi*(g22*Z2 + g23*Z3)) + phiL*(Rphi12 + Rt12 + 
      e4phi*(PDstandardNth1gt12*Z1 + PDstandardNth2gt12*Z2 + 
      PDstandardNth3gt12*Z3)))*pow(phiL,-1);
    
    CCTK_REAL R13 CCTK_ATTRIBUTE_UNUSED = ((-2*g13*PDstandardNth2phi + 
      2*g12*PDstandardNth3phi)*Z2 + 2*(g11*PDstandardNth3phi*Z1 + 
      PDstandardNth1phi*(g23*Z2 + g33*Z3)) + phiL*(Rphi13 + Rt13 + 
      e4phi*(PDstandardNth1gt13*Z1 + PDstandardNth2gt13*Z2 + 
      PDstandardNth3gt13*Z3)))*pow(phiL,-1);
    
    CCTK_REAL R22 CCTK_ATTRIBUTE_UNUSED = Rphi22 + Rt22 + 
      e4phi*(PDstandardNth1gt22*Z1 + PDstandardNth2gt22*Z2 + 
      PDstandardNth3gt22*Z3) + (-2*g22*(PDstandardNth1phi*Z1 + 
      PDstandardNth3phi*Z3) + 2*PDstandardNth2phi*(g22*Z2 + 2*(g12*Z1 + 
      g23*Z3)))*pow(phiL,-1);
    
    CCTK_REAL R23 CCTK_ATTRIBUTE_UNUSED = ((-2*g23*PDstandardNth1phi + 
      2*(g13*PDstandardNth2phi + g12*PDstandardNth3phi))*Z1 + 
      2*(g22*PDstandardNth3phi*Z2 + g33*PDstandardNth2phi*Z3) + phiL*(Rphi23 
      + Rt23 + e4phi*(PDstandardNth1gt23*Z1 + PDstandardNth2gt23*Z2 + 
      PDstandardNth3gt23*Z3)))*pow(phiL,-1);
    
    CCTK_REAL R33 CCTK_ATTRIBUTE_UNUSED = Rphi33 + Rt33 + 
      e4phi*(PDstandardNth1gt33*Z1 + PDstandardNth2gt33*Z2 + 
      PDstandardNth3gt33*Z3) + (-2*g33*(PDstandardNth1phi*Z1 + 
      PDstandardNth2phi*Z2) + 2*PDstandardNth3phi*(2*(g13*Z1 + g23*Z2) + 
      g33*Z3))*pow(phiL,-1);
    
    CCTK_REAL dotXt1 CCTK_ATTRIBUTE_UNUSED = gtu11*PDstandardNth11beta1 + 
      gtu22*PDstandardNth22beta1 + gtu33*PDstandardNth33beta1 + 
      0.333333333333333333333333333333*(gtu11*(PDstandardNth11beta1 + 
      PDstandardNth12beta2 + PDstandardNth13beta3) + 
      gtu12*(PDstandardNth12beta1 + PDstandardNth22beta2 + 
      PDstandardNth23beta3) + gtu13*(PDstandardNth13beta1 + 
      PDstandardNth23beta2 + PDstandardNth33beta3)) + 
      2*(gtu11*(-(ThetaL*PDstandardNth1alpha) + alphaL*PDstandardNth1Theta) + 
      gtu23*PDstandardNth23beta1 + gtu12*(PDstandardNth12beta1 - 
      ThetaL*PDstandardNth2alpha) + alphaL*gtu12*PDstandardNth2Theta + 
      gtu13*(PDstandardNth13beta1 - ThetaL*PDstandardNth3alpha) + 
      alphaL*gtu13*PDstandardNth3Theta + alphaL*(6*(Atu11*cdphi1 + 
      Atu12*cdphi2 + Atu13*cdphi3) + Atu11*Gt111 + 2*Atu12*Gt112 + 
      2*Atu13*Gt113 + Atu22*Gt122 + 2*Atu23*Gt123 + Atu33*Gt133 - 
      0.666666666666666666666666666667*(gtu11*PDstandardNth1trK + 
      gtu12*PDstandardNth2trK + gtu13*PDstandardNth3trK))) + 
      (-PDstandardNth1beta1 + 
      0.666666666666666666666666666667*(PDstandardNth1beta1 + 
      PDstandardNth2beta2 + PDstandardNth3beta3))*Xtn1 - 
      PDstandardNth2beta1*Xtn2 - PDstandardNth3beta1*Xtn3 - 
      1.33333333333333333333333333333*alphaL*trKL*e4phi*Z1 - 
      2*(Atu11*PDstandardNth1alpha + Atu12*PDstandardNth2alpha + 
      Atu13*PDstandardNth3alpha + alphaL*dampk1*e4phi*Z1) - 
      0.666666666666666666666666666667*e4phi*GammaShift*(PDstandardNth1beta1*Z1 
      - 2*PDstandardNth2beta2*Z1 - 2*PDstandardNth3beta3*Z1 + 
      3*PDstandardNth2beta1*Z2 + 3*PDstandardNth3beta1*Z3);
    
    CCTK_REAL dotXt2 CCTK_ATTRIBUTE_UNUSED = gtu11*PDstandardNth11beta2 + 
      gtu22*PDstandardNth22beta2 + gtu33*PDstandardNth33beta2 + 
      0.333333333333333333333333333333*(gtu12*(PDstandardNth11beta1 + 
      PDstandardNth12beta2 + PDstandardNth13beta3) + 
      gtu22*(PDstandardNth12beta1 + PDstandardNth22beta2 + 
      PDstandardNth23beta3) + gtu23*(PDstandardNth13beta1 + 
      PDstandardNth23beta2 + PDstandardNth33beta3)) + 
      2*(gtu13*PDstandardNth13beta2 + gtu12*(PDstandardNth12beta2 - 
      ThetaL*PDstandardNth1alpha) + alphaL*gtu12*PDstandardNth1Theta + 
      gtu22*(-(ThetaL*PDstandardNth2alpha) + alphaL*PDstandardNth2Theta) + 
      gtu23*(PDstandardNth23beta2 - ThetaL*PDstandardNth3alpha) + 
      alphaL*gtu23*PDstandardNth3Theta + alphaL*(6*(Atu12*cdphi1 + 
      Atu22*cdphi2 + Atu23*cdphi3) + Atu11*Gt211 + 2*Atu12*Gt212 + 
      2*Atu13*Gt213 + Atu22*Gt222 + 2*Atu23*Gt223 + Atu33*Gt233 - 
      0.666666666666666666666666666667*(gtu12*PDstandardNth1trK + 
      gtu22*PDstandardNth2trK + gtu23*PDstandardNth3trK))) - 
      PDstandardNth1beta2*Xtn1 + (-PDstandardNth2beta2 + 
      0.666666666666666666666666666667*(PDstandardNth1beta1 + 
      PDstandardNth2beta2 + PDstandardNth3beta3))*Xtn2 - 
      PDstandardNth3beta2*Xtn3 - 
      1.33333333333333333333333333333*alphaL*trKL*e4phi*Z2 - 
      2*(Atu12*PDstandardNth1alpha + Atu22*PDstandardNth2alpha + 
      Atu23*PDstandardNth3alpha + alphaL*dampk1*e4phi*Z2) - 
      0.666666666666666666666666666667*e4phi*GammaShift*(3*PDstandardNth1beta2*Z1 
      - 2*PDstandardNth1beta1*Z2 + PDstandardNth2beta2*Z2 - 
      2*PDstandardNth3beta3*Z2 + 3*PDstandardNth3beta2*Z3);
    
    CCTK_REAL dotXt3 CCTK_ATTRIBUTE_UNUSED = gtu11*PDstandardNth11beta3 + 
      gtu22*PDstandardNth22beta3 + gtu33*PDstandardNth33beta3 + 
      0.333333333333333333333333333333*(gtu13*(PDstandardNth11beta1 + 
      PDstandardNth12beta2 + PDstandardNth13beta3) + 
      gtu23*(PDstandardNth12beta1 + PDstandardNth22beta2 + 
      PDstandardNth23beta3) + gtu33*(PDstandardNth13beta1 + 
      PDstandardNth23beta2 + PDstandardNth33beta3)) + 
      2*(gtu12*PDstandardNth12beta3 + gtu13*(PDstandardNth13beta3 - 
      ThetaL*PDstandardNth1alpha) + alphaL*gtu13*PDstandardNth1Theta + 
      gtu23*(PDstandardNth23beta3 - ThetaL*PDstandardNth2alpha) + 
      alphaL*gtu23*PDstandardNth2Theta + gtu33*(-(ThetaL*PDstandardNth3alpha) 
      + alphaL*PDstandardNth3Theta) + alphaL*(6*(Atu13*cdphi1 + Atu23*cdphi2 
      + Atu33*cdphi3) + Atu11*Gt311 + 2*Atu12*Gt312 + 2*Atu13*Gt313 + 
      Atu22*Gt322 + 2*Atu23*Gt323 + Atu33*Gt333 - 
      0.666666666666666666666666666667*(gtu13*PDstandardNth1trK + 
      gtu23*PDstandardNth2trK + gtu33*PDstandardNth3trK))) - 
      PDstandardNth1beta3*Xtn1 - PDstandardNth2beta3*Xtn2 + 
      (-PDstandardNth3beta3 + 
      0.666666666666666666666666666667*(PDstandardNth1beta1 + 
      PDstandardNth2beta2 + PDstandardNth3beta3))*Xtn3 - 
      1.33333333333333333333333333333*alphaL*trKL*e4phi*Z3 - 
      2*(Atu13*PDstandardNth1alpha + Atu23*PDstandardNth2alpha + 
      Atu33*PDstandardNth3alpha + alphaL*dampk1*e4phi*Z3) - 
      0.666666666666666666666666666667*e4phi*GammaShift*(3*PDstandardNth1beta3*Z1 
      + 3*PDstandardNth2beta3*Z2 - 2*PDstandardNth1beta1*Z3 - 
      2*PDstandardNth2beta2*Z3 + PDstandardNth3beta3*Z3);
    
    CCTK_REAL Xt1rhsL CCTK_ATTRIBUTE_UNUSED = dotXt1 + 
      epsdiss1*PDdissipationNth1Xt1 + epsdiss2*PDdissipationNth2Xt1 + 
      epsdiss3*PDdissipationNth3Xt1 + beta1L*PDupwindNthAnti1Xt1 + 
      beta2L*PDupwindNthAnti2Xt1 + beta3L*PDupwindNthAnti3Xt1 + 
      PDupwindNthSymm1Xt1*fabs(beta1L) + PDupwindNthSymm2Xt1*fabs(beta2L) + 
      PDupwindNthSymm3Xt1*fabs(beta3L);
    
    CCTK_REAL Xt2rhsL CCTK_ATTRIBUTE_UNUSED = dotXt2 + 
      epsdiss1*PDdissipationNth1Xt2 + epsdiss2*PDdissipationNth2Xt2 + 
      epsdiss3*PDdissipationNth3Xt2 + beta1L*PDupwindNthAnti1Xt2 + 
      beta2L*PDupwindNthAnti2Xt2 + beta3L*PDupwindNthAnti3Xt2 + 
      PDupwindNthSymm1Xt2*fabs(beta1L) + PDupwindNthSymm2Xt2*fabs(beta2L) + 
      PDupwindNthSymm3Xt2*fabs(beta3L);
    
    CCTK_REAL Xt3rhsL CCTK_ATTRIBUTE_UNUSED = dotXt3 + 
      epsdiss1*PDdissipationNth1Xt3 + epsdiss2*PDdissipationNth2Xt3 + 
      epsdiss3*PDdissipationNth3Xt3 + beta1L*PDupwindNthAnti1Xt3 + 
      beta2L*PDupwindNthAnti2Xt3 + beta3L*PDupwindNthAnti3Xt3 + 
      PDupwindNthSymm1Xt3*fabs(beta1L) + PDupwindNthSymm2Xt3*fabs(beta2L) + 
      PDupwindNthSymm3Xt3*fabs(beta3L);
    
    CCTK_REAL trR CCTK_ATTRIBUTE_UNUSED = gu11*R11 + gu22*R22 + 
      2*(gu12*R12 + gu13*R13 + gu23*R23) + gu33*R33;
    
    CCTK_REAL dotTheta CCTK_ATTRIBUTE_UNUSED = -(PDstandardNth1alpha*Z1) - 
      PDstandardNth2alpha*Z2 - PDstandardNth3alpha*Z3 + 
      alphaL*(-(ThetaL*dampk1*(2 + dampk2)) - 
      0.166666666666666666666666666667*(6*ThetaL*trKL + 6*Atm12*Atm21 + 
      6*Atm13*Atm31 + 6*Atm23*Atm32 - 3*trR - 2*pow(trKL,2) + 3*pow(Atm11,2) 
      + 3*pow(Atm22,2) + 3*pow(Atm33,2)));
    
    CCTK_REAL ThetarhsL CCTK_ATTRIBUTE_UNUSED = dotTheta + 
      epsdiss1*PDdissipationNth1Theta + epsdiss2*PDdissipationNth2Theta + 
      epsdiss3*PDdissipationNth3Theta + beta1L*PDupwindNthAnti1Theta + 
      beta2L*PDupwindNthAnti2Theta + beta3L*PDupwindNthAnti3Theta + 
      PDupwindNthSymm1Theta*fabs(beta1L) + PDupwindNthSymm2Theta*fabs(beta2L) 
      + PDupwindNthSymm3Theta*fabs(beta3L);
    
    CCTK_REAL dottrK CCTK_ATTRIBUTE_UNUSED = 
      -(em4phi*(gtu11*PDstandardNth11alpha + gtu22*PDstandardNth22alpha + 
      gtu33*(PDstandardNth33alpha + 2*cdphi3*PDstandardNth3alpha) + 
      2*(gtu12*PDstandardNth12alpha + gtu13*(PDstandardNth13alpha + 
      cdphi1*PDstandardNth3alpha) + gtu23*(PDstandardNth23alpha + 
      cdphi2*PDstandardNth3alpha)) + PDstandardNth1alpha*(2*(cdphi1*gtu11 + 
      cdphi2*gtu12 + cdphi3*gtu13) - Xtn1) + 
      PDstandardNth2alpha*(2*(cdphi1*gtu12 + cdphi2*gtu22 + cdphi3*gtu23) - 
      Xtn2) - PDstandardNth3alpha*Xtn3)) + 2*(dotTheta + 
      PDstandardNth1alpha*Z1 + PDstandardNth2alpha*Z2 + 
      PDstandardNth3alpha*Z3) + alphaL*(2*(Atm12*Atm21 + Atm13*Atm31 + 
      Atm23*Atm32) - ThetaL*dampk1*(-1 + dampk2) + 
      0.333333333333333333333333333333*pow(trKL,2) + pow(Atm11,2) + 
      pow(Atm22,2) + pow(Atm33,2));
    
    CCTK_REAL trKrhsL CCTK_ATTRIBUTE_UNUSED = dottrK + 
      epsdiss1*PDdissipationNth1trK + epsdiss2*PDdissipationNth2trK + 
      epsdiss3*PDdissipationNth3trK + beta1L*PDupwindNthAnti1trK + 
      beta2L*PDupwindNthAnti2trK + beta3L*PDupwindNthAnti3trK + 
      PDupwindNthSymm1trK*fabs(beta1L) + PDupwindNthSymm2trK*fabs(beta2L) + 
      PDupwindNthSymm3trK*fabs(beta3L);
    
    CCTK_REAL betaDriverValue CCTK_ATTRIBUTE_UNUSED = betaDriver;
    
    CCTK_REAL shiftGammaCoeffValue CCTK_ATTRIBUTE_UNUSED = 
      shiftGammaCoeff;
    
    CCTK_REAL dotbeta1 CCTK_ATTRIBUTE_UNUSED = 
      B1L*shiftGammaCoeffValue*pow(alphaL,shiftAlphaPower);
    
    CCTK_REAL dotbeta2 CCTK_ATTRIBUTE_UNUSED = 
      B2L*shiftGammaCoeffValue*pow(alphaL,shiftAlphaPower);
    
    CCTK_REAL dotbeta3 CCTK_ATTRIBUTE_UNUSED = 
      B3L*shiftGammaCoeffValue*pow(alphaL,shiftAlphaPower);
    
    CCTK_REAL beta1rhsL CCTK_ATTRIBUTE_UNUSED = dotbeta1 + 
      epsdiss1*PDdissipationNth1beta1 + epsdiss2*PDdissipationNth2beta1 + 
      epsdiss3*PDdissipationNth3beta1 + beta1L*PDupwindNthAnti1beta1 + 
      beta2L*PDupwindNthAnti2beta1 + beta3L*PDupwindNthAnti3beta1 + 
      PDupwindNthSymm1beta1*fabs(beta1L) + PDupwindNthSymm2beta1*fabs(beta2L) 
      + PDupwindNthSymm3beta1*fabs(beta3L);
    
    CCTK_REAL beta2rhsL CCTK_ATTRIBUTE_UNUSED = dotbeta2 + 
      epsdiss1*PDdissipationNth1beta2 + epsdiss2*PDdissipationNth2beta2 + 
      epsdiss3*PDdissipationNth3beta2 + beta1L*PDupwindNthAnti1beta2 + 
      beta2L*PDupwindNthAnti2beta2 + beta3L*PDupwindNthAnti3beta2 + 
      PDupwindNthSymm1beta2*fabs(beta1L) + PDupwindNthSymm2beta2*fabs(beta2L) 
      + PDupwindNthSymm3beta2*fabs(beta3L);
    
    CCTK_REAL beta3rhsL CCTK_ATTRIBUTE_UNUSED = dotbeta3 + 
      epsdiss1*PDdissipationNth1beta3 + epsdiss2*PDdissipationNth2beta3 + 
      epsdiss3*PDdissipationNth3beta3 + beta1L*PDupwindNthAnti1beta3 + 
      beta2L*PDupwindNthAnti2beta3 + beta3L*PDupwindNthAnti3beta3 + 
      PDupwindNthSymm1beta3*fabs(beta1L) + PDupwindNthSymm2beta3*fabs(beta2L) 
      + PDupwindNthSymm3beta3*fabs(beta3L);
    
    CCTK_REAL B1rhsL CCTK_ATTRIBUTE_UNUSED = -(B1L*betaDriverValue) + 
      dotXt1 + epsdiss1*PDdissipationNth1B1 + epsdiss2*PDdissipationNth2B1 + 
      epsdiss3*PDdissipationNth3B1 + beta1L*PDupwindNthAnti1B1 + 
      beta2L*PDupwindNthAnti2B1 + beta3L*PDupwindNthAnti3B1 + 
      PDupwindNthSymm1B1*fabs(beta1L) + PDupwindNthSymm2B1*fabs(beta2L) + 
      PDupwindNthSymm3B1*fabs(beta3L);
    
    CCTK_REAL B2rhsL CCTK_ATTRIBUTE_UNUSED = -(B2L*betaDriverValue) + 
      dotXt2 + epsdiss1*PDdissipationNth1B2 + epsdiss2*PDdissipationNth2B2 + 
      epsdiss3*PDdissipationNth3B2 + beta1L*PDupwindNthAnti1B2 + 
      beta2L*PDupwindNthAnti2B2 + beta3L*PDupwindNthAnti3B2 + 
      PDupwindNthSymm1B2*fabs(beta1L) + PDupwindNthSymm2B2*fabs(beta2L) + 
      PDupwindNthSymm3B2*fabs(beta3L);
    
    CCTK_REAL B3rhsL CCTK_ATTRIBUTE_UNUSED = -(B3L*betaDriverValue) + 
      dotXt3 + epsdiss1*PDdissipationNth1B3 + epsdiss2*PDdissipationNth2B3 + 
      epsdiss3*PDdissipationNth3B3 + beta1L*PDupwindNthAnti1B3 + 
      beta2L*PDupwindNthAnti2B3 + beta3L*PDupwindNthAnti3B3 + 
      PDupwindNthSymm1B3*fabs(beta1L) + PDupwindNthSymm2B3*fabs(beta2L) + 
      PDupwindNthSymm3B3*fabs(beta3L);
    /* Copy local copies back to grid functions */
    B1rhs[index] = B1rhsL;
    B2rhs[index] = B2rhsL;
    B3rhs[index] = B3rhsL;
    beta1rhs[index] = beta1rhsL;
    beta2rhs[index] = beta2rhsL;
    beta3rhs[index] = beta3rhsL;
    Thetarhs[index] = ThetarhsL;
    trKrhs[index] = trKrhsL;
    Xt1rhs[index] = Xt1rhsL;
    Xt2rhs[index] = Xt2rhsL;
    Xt3rhs[index] = Xt3rhsL;
  }
  CCTK_ENDLOOP3(ML_CCZ4_EvolutionInteriorSplitBy2);
}
extern "C" void ML_CCZ4_EvolutionInteriorSplitBy2(CCTK_ARGUMENTS)
{
  #ifdef DECLARE_CCTK_ARGUMENTS_ML_CCZ4_EvolutionInteriorSplitBy2
  DECLARE_CCTK_ARGUMENTS_CHECKED(ML_CCZ4_EvolutionInteriorSplitBy2);
  #else
  DECLARE_CCTK_ARGUMENTS
  #endif
  DECLARE_CCTK_PARAMETERS
  
  if (verbose > 1)
  {
    CCTK_VInfo(CCTK_THORNSTRING,"Entering ML_CCZ4_EvolutionInteriorSplitBy2_Body");
  }
  if (cctk_iteration % ML_CCZ4_EvolutionInteriorSplitBy2_calc_every != ML_CCZ4_EvolutionInteriorSplitBy2_calc_offset)
  {
    return;
  }
  
  const char* const groups[] = {
    "ML_CCZ4::ML_curv",
    "ML_CCZ4::ML_dtshift",
    "ML_CCZ4::ML_dtshiftrhs",
    "ML_CCZ4::ML_Gamma",
    "ML_CCZ4::ML_Gammarhs",
    "ML_CCZ4::ML_lapse",
    "ML_CCZ4::ML_log_confac",
    "ML_CCZ4::ML_metric",
    "ML_CCZ4::ML_shift",
    "ML_CCZ4::ML_shiftrhs",
    "ML_CCZ4::ML_Theta",
    "ML_CCZ4::ML_Thetarhs",
    "ML_CCZ4::ML_trace_curv",
    "ML_CCZ4::ML_trace_curvrhs"};
  AssertGroupStorage(cctkGH, "ML_CCZ4_EvolutionInteriorSplitBy2", 14, groups);
  
  EnsureStencilFits(cctkGH, "ML_CCZ4_EvolutionInteriorSplitBy2", 5, 5, 5);
  
  LoopOverInterior(cctkGH, ML_CCZ4_EvolutionInteriorSplitBy2_Body);
  if (verbose > 1)
  {
    CCTK_VInfo(CCTK_THORNSTRING,"Leaving ML_CCZ4_EvolutionInteriorSplitBy2_Body");
  }
}

} // namespace ML_CCZ4
