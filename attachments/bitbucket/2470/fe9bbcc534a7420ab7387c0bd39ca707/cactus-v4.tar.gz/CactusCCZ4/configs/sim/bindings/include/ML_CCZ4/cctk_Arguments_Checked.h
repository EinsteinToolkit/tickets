#ifndef CCTK_ARGUMENTS_CHECKED_H
#define CCTK_ARGUMENTS_CHECKED_H 1

/* needed for CCTK_ANSI_FPP */
#include "cctk_Types.h"

#ifdef CCODE
#define DECLARE_CCTK_ARGUMENTS_CHECKED(func) DECLARE_CCTK_ARGUMENTS_##func
#endif
#ifdef FCODE
#if CCTK_ANSI_FPP
#define DECLARE_CCTK_ARGUMENTS_CHECKED(func) DECLARE_CCTK_ARGUMENTS_##func
#else
#define DECLARE_CCTK_ARGUMENTS_CHECKED(func) DECLARE_CCTK_ARGUMENTS_/**/func
#endif
#endif

#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_ML_CCZ4_ADMBaseBoundaryScalar 
#define DECLARE_CCTK_ARGUMENTS_ML_CCZ4_ADMBaseBoundaryScalar \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_REAL  * restrict const dtalp __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).dtalp));; /* TL: ML_CCZ4_ADMBaseBoundaryScalar_C --> 0 no*/\
CCTK_REAL  * restrict const dtbetax __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).dtbetax));; /* TL: ML_CCZ4_ADMBaseBoundaryScalar_C --> 0 no*/\
CCTK_REAL  * restrict const dtbetay __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).dtbetay));; /* TL: ML_CCZ4_ADMBaseBoundaryScalar_C --> 0 no*/\
CCTK_REAL  * restrict const dtbetaz __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).dtbetaz));; /* TL: ML_CCZ4_ADMBaseBoundaryScalar_C --> 0 no*/\
  /* end ML_CCZ4_ADMBaseBoundaryScalar */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_ML_CCZ4_ADMBaseEverywhere 
#define DECLARE_CCTK_ARGUMENTS_ML_CCZ4_ADMBaseEverywhere \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_REAL  * restrict const alp __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).alp));; /* TL: ML_CCZ4_ADMBaseEverywhere_C --> 0 no*/\
CCTK_REAL  * restrict const betax __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).betax));; /* TL: ML_CCZ4_ADMBaseEverywhere_C --> 0 no*/\
CCTK_REAL  * restrict const betay __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).betay));; /* TL: ML_CCZ4_ADMBaseEverywhere_C --> 0 no*/\
CCTK_REAL  * restrict const betaz __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).betaz));; /* TL: ML_CCZ4_ADMBaseEverywhere_C --> 0 no*/\
CCTK_REAL  * restrict const gxx __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gxx));; /* TL: ML_CCZ4_ADMBaseEverywhere_C --> 0 no*/\
CCTK_REAL  * restrict const gxy __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gxy));; /* TL: ML_CCZ4_ADMBaseEverywhere_C --> 0 no*/\
CCTK_REAL  * restrict const gxz __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gxz));; /* TL: ML_CCZ4_ADMBaseEverywhere_C --> 0 no*/\
CCTK_REAL  * restrict const gyy __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gyy));; /* TL: ML_CCZ4_ADMBaseEverywhere_C --> 0 no*/\
CCTK_REAL  * restrict const gyz __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gyz));; /* TL: ML_CCZ4_ADMBaseEverywhere_C --> 0 no*/\
CCTK_REAL  * restrict const gzz __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gzz));; /* TL: ML_CCZ4_ADMBaseEverywhere_C --> 0 no*/\
CCTK_REAL  * restrict const kxx __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).kxx));; /* TL: ML_CCZ4_ADMBaseEverywhere_C --> 0 no*/\
CCTK_REAL  * restrict const kxy __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).kxy));; /* TL: ML_CCZ4_ADMBaseEverywhere_C --> 0 no*/\
CCTK_REAL  * restrict const kxz __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).kxz));; /* TL: ML_CCZ4_ADMBaseEverywhere_C --> 0 no*/\
CCTK_REAL  * restrict const kyy __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).kyy));; /* TL: ML_CCZ4_ADMBaseEverywhere_C --> 0 no*/\
CCTK_REAL  * restrict const kyz __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).kyz));; /* TL: ML_CCZ4_ADMBaseEverywhere_C --> 0 no*/\
CCTK_REAL  * restrict const kzz __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).kzz));; /* TL: ML_CCZ4_ADMBaseEverywhere_C --> 0 no*/\
CCTK_REAL const * restrict const alpha __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).alpha));; /* TL: ML_CCZ4_ADMBaseEverywhere_C --> 0 no*/\
CCTK_REAL const * restrict const At11 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At11));; /* TL: ML_CCZ4_ADMBaseEverywhere_C --> 0 no*/\
CCTK_REAL const * restrict const At12 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At12));; /* TL: ML_CCZ4_ADMBaseEverywhere_C --> 0 no*/\
CCTK_REAL const * restrict const At13 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At13));; /* TL: ML_CCZ4_ADMBaseEverywhere_C --> 0 no*/\
CCTK_REAL const * restrict const At22 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At22));; /* TL: ML_CCZ4_ADMBaseEverywhere_C --> 0 no*/\
CCTK_REAL const * restrict const At23 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At23));; /* TL: ML_CCZ4_ADMBaseEverywhere_C --> 0 no*/\
CCTK_REAL const * restrict const At33 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At33));; /* TL: ML_CCZ4_ADMBaseEverywhere_C --> 0 no*/\
CCTK_REAL const * restrict const B1 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).B1));; /* TL: ML_CCZ4_ADMBaseEverywhere_C --> 0 no*/\
CCTK_REAL const * restrict const B2 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).B2));; /* TL: ML_CCZ4_ADMBaseEverywhere_C --> 0 no*/\
CCTK_REAL const * restrict const B3 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).B3));; /* TL: ML_CCZ4_ADMBaseEverywhere_C --> 0 no*/\
CCTK_REAL const * restrict const beta1 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).beta1));; /* TL: ML_CCZ4_ADMBaseEverywhere_C --> 0 no*/\
CCTK_REAL const * restrict const beta2 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).beta2));; /* TL: ML_CCZ4_ADMBaseEverywhere_C --> 0 no*/\
CCTK_REAL const * restrict const beta3 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).beta3));; /* TL: ML_CCZ4_ADMBaseEverywhere_C --> 0 no*/\
CCTK_REAL const * restrict const gt11 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt11));; /* TL: ML_CCZ4_ADMBaseEverywhere_C --> 0 no*/\
CCTK_REAL const * restrict const gt12 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt12));; /* TL: ML_CCZ4_ADMBaseEverywhere_C --> 0 no*/\
CCTK_REAL const * restrict const gt13 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt13));; /* TL: ML_CCZ4_ADMBaseEverywhere_C --> 0 no*/\
CCTK_REAL const * restrict const gt22 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt22));; /* TL: ML_CCZ4_ADMBaseEverywhere_C --> 0 no*/\
CCTK_REAL const * restrict const gt23 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt23));; /* TL: ML_CCZ4_ADMBaseEverywhere_C --> 0 no*/\
CCTK_REAL const * restrict const gt33 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt33));; /* TL: ML_CCZ4_ADMBaseEverywhere_C --> 0 no*/\
CCTK_REAL const * restrict const phi __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).phi));; /* TL: ML_CCZ4_ADMBaseEverywhere_C --> 0 no*/\
CCTK_REAL const * restrict const Theta __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Theta));; /* TL: ML_CCZ4_ADMBaseEverywhere_C --> 0 no*/\
CCTK_REAL const * restrict const trK __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).trK));; /* TL: ML_CCZ4_ADMBaseEverywhere_C --> 0 no*/\
CCTK_REAL const * restrict const Xt1 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Xt1));; /* TL: ML_CCZ4_ADMBaseEverywhere_C --> 0 no*/\
CCTK_REAL const * restrict const Xt2 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Xt2));; /* TL: ML_CCZ4_ADMBaseEverywhere_C --> 0 no*/\
CCTK_REAL const * restrict const Xt3 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Xt3));; /* TL: ML_CCZ4_ADMBaseEverywhere_C --> 0 no*/\
  /* end ML_CCZ4_ADMBaseEverywhere */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_ML_CCZ4_ADMBaseInterior 
#define DECLARE_CCTK_ARGUMENTS_ML_CCZ4_ADMBaseInterior \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_REAL  * restrict const dtalp __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).dtalp));; /* TL: ML_CCZ4_ADMBaseInterior_C --> 0 no*/\
CCTK_REAL  * restrict const dtbetax __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).dtbetax));; /* TL: ML_CCZ4_ADMBaseInterior_C --> 0 no*/\
CCTK_REAL  * restrict const dtbetay __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).dtbetay));; /* TL: ML_CCZ4_ADMBaseInterior_C --> 0 no*/\
CCTK_REAL  * restrict const dtbetaz __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).dtbetaz));; /* TL: ML_CCZ4_ADMBaseInterior_C --> 0 no*/\
CCTK_REAL const * restrict const alpha __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).alpha));; /* TL: ML_CCZ4_ADMBaseInterior_C --> 0 no*/\
CCTK_REAL const * restrict const At11 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At11));; /* TL: ML_CCZ4_ADMBaseInterior_C --> 0 no*/\
CCTK_REAL const * restrict const At12 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At12));; /* TL: ML_CCZ4_ADMBaseInterior_C --> 0 no*/\
CCTK_REAL const * restrict const At13 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At13));; /* TL: ML_CCZ4_ADMBaseInterior_C --> 0 no*/\
CCTK_REAL const * restrict const At22 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At22));; /* TL: ML_CCZ4_ADMBaseInterior_C --> 0 no*/\
CCTK_REAL const * restrict const At23 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At23));; /* TL: ML_CCZ4_ADMBaseInterior_C --> 0 no*/\
CCTK_REAL const * restrict const At33 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At33));; /* TL: ML_CCZ4_ADMBaseInterior_C --> 0 no*/\
CCTK_REAL const * restrict const B1 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).B1));; /* TL: ML_CCZ4_ADMBaseInterior_C --> 0 no*/\
CCTK_REAL const * restrict const B2 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).B2));; /* TL: ML_CCZ4_ADMBaseInterior_C --> 0 no*/\
CCTK_REAL const * restrict const B3 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).B3));; /* TL: ML_CCZ4_ADMBaseInterior_C --> 0 no*/\
CCTK_REAL const * restrict const beta1 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).beta1));; /* TL: ML_CCZ4_ADMBaseInterior_C --> 0 no*/\
CCTK_REAL const * restrict const beta2 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).beta2));; /* TL: ML_CCZ4_ADMBaseInterior_C --> 0 no*/\
CCTK_REAL const * restrict const beta3 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).beta3));; /* TL: ML_CCZ4_ADMBaseInterior_C --> 0 no*/\
CCTK_REAL const * restrict const gt11 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt11));; /* TL: ML_CCZ4_ADMBaseInterior_C --> 0 no*/\
CCTK_REAL const * restrict const gt12 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt12));; /* TL: ML_CCZ4_ADMBaseInterior_C --> 0 no*/\
CCTK_REAL const * restrict const gt13 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt13));; /* TL: ML_CCZ4_ADMBaseInterior_C --> 0 no*/\
CCTK_REAL const * restrict const gt22 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt22));; /* TL: ML_CCZ4_ADMBaseInterior_C --> 0 no*/\
CCTK_REAL const * restrict const gt23 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt23));; /* TL: ML_CCZ4_ADMBaseInterior_C --> 0 no*/\
CCTK_REAL const * restrict const gt33 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt33));; /* TL: ML_CCZ4_ADMBaseInterior_C --> 0 no*/\
CCTK_REAL const * restrict const phi __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).phi));; /* TL: ML_CCZ4_ADMBaseInterior_C --> 0 no*/\
CCTK_REAL const * restrict const Theta __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Theta));; /* TL: ML_CCZ4_ADMBaseInterior_C --> 0 no*/\
CCTK_REAL const * restrict const trK __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).trK));; /* TL: ML_CCZ4_ADMBaseInterior_C --> 0 no*/\
CCTK_REAL const * restrict const Xt1 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Xt1));; /* TL: ML_CCZ4_ADMBaseInterior_C --> 0 no*/\
CCTK_REAL const * restrict const Xt2 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Xt2));; /* TL: ML_CCZ4_ADMBaseInterior_C --> 0 no*/\
CCTK_REAL const * restrict const Xt3 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Xt3));; /* TL: ML_CCZ4_ADMBaseInterior_C --> 0 no*/\
  /* end ML_CCZ4_ADMBaseInterior */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_ML_CCZ4_CheckBoundaries 
#define DECLARE_CCTK_ARGUMENTS_ML_CCZ4_CheckBoundaries \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end ML_CCZ4_CheckBoundaries */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_ML_CCZ4_ConstraintsEverywhere 
#define DECLARE_CCTK_ARGUMENTS_ML_CCZ4_ConstraintsEverywhere \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_REAL const * restrict const alpha __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).alpha));; /* TL: ML_CCZ4_ConstraintsEverywhere_C --> 0 no*/\
CCTK_REAL const * restrict const At11 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At11));; /* TL: ML_CCZ4_ConstraintsEverywhere_C --> 0 no*/\
CCTK_REAL const * restrict const At12 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At12));; /* TL: ML_CCZ4_ConstraintsEverywhere_C --> 0 no*/\
CCTK_REAL const * restrict const At13 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At13));; /* TL: ML_CCZ4_ConstraintsEverywhere_C --> 0 no*/\
CCTK_REAL const * restrict const At22 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At22));; /* TL: ML_CCZ4_ConstraintsEverywhere_C --> 0 no*/\
CCTK_REAL const * restrict const At23 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At23));; /* TL: ML_CCZ4_ConstraintsEverywhere_C --> 0 no*/\
CCTK_REAL const * restrict const At33 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At33));; /* TL: ML_CCZ4_ConstraintsEverywhere_C --> 0 no*/\
CCTK_REAL const * restrict const B1 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).B1));; /* TL: ML_CCZ4_ConstraintsEverywhere_C --> 0 no*/\
CCTK_REAL const * restrict const B2 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).B2));; /* TL: ML_CCZ4_ConstraintsEverywhere_C --> 0 no*/\
CCTK_REAL const * restrict const B3 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).B3));; /* TL: ML_CCZ4_ConstraintsEverywhere_C --> 0 no*/\
CCTK_REAL const * restrict const beta1 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).beta1));; /* TL: ML_CCZ4_ConstraintsEverywhere_C --> 0 no*/\
CCTK_REAL const * restrict const beta2 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).beta2));; /* TL: ML_CCZ4_ConstraintsEverywhere_C --> 0 no*/\
CCTK_REAL const * restrict const beta3 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).beta3));; /* TL: ML_CCZ4_ConstraintsEverywhere_C --> 0 no*/\
CCTK_REAL  * restrict const cA __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).cA));; /* TL: ML_CCZ4_ConstraintsEverywhere_C --> 0 no*/\
CCTK_REAL  * restrict const cS __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).cS));; /* TL: ML_CCZ4_ConstraintsEverywhere_C --> 0 no*/\
CCTK_REAL const * restrict const gt11 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt11));; /* TL: ML_CCZ4_ConstraintsEverywhere_C --> 0 no*/\
CCTK_REAL const * restrict const gt12 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt12));; /* TL: ML_CCZ4_ConstraintsEverywhere_C --> 0 no*/\
CCTK_REAL const * restrict const gt13 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt13));; /* TL: ML_CCZ4_ConstraintsEverywhere_C --> 0 no*/\
CCTK_REAL const * restrict const gt22 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt22));; /* TL: ML_CCZ4_ConstraintsEverywhere_C --> 0 no*/\
CCTK_REAL const * restrict const gt23 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt23));; /* TL: ML_CCZ4_ConstraintsEverywhere_C --> 0 no*/\
CCTK_REAL const * restrict const gt33 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt33));; /* TL: ML_CCZ4_ConstraintsEverywhere_C --> 0 no*/\
CCTK_REAL const * restrict const phi __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).phi));; /* TL: ML_CCZ4_ConstraintsEverywhere_C --> 0 no*/\
CCTK_REAL const * restrict const Theta __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Theta));; /* TL: ML_CCZ4_ConstraintsEverywhere_C --> 0 no*/\
CCTK_REAL const * restrict const trK __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).trK));; /* TL: ML_CCZ4_ConstraintsEverywhere_C --> 0 no*/\
CCTK_REAL const * restrict const Xt1 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Xt1));; /* TL: ML_CCZ4_ConstraintsEverywhere_C --> 0 no*/\
CCTK_REAL const * restrict const Xt2 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Xt2));; /* TL: ML_CCZ4_ConstraintsEverywhere_C --> 0 no*/\
CCTK_REAL const * restrict const Xt3 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Xt3));; /* TL: ML_CCZ4_ConstraintsEverywhere_C --> 0 no*/\
  /* end ML_CCZ4_ConstraintsEverywhere */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_ML_CCZ4_ConstraintsEverywhere_SelectBCs 
#define DECLARE_CCTK_ARGUMENTS_ML_CCZ4_ConstraintsEverywhere_SelectBCs \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end ML_CCZ4_ConstraintsEverywhere_SelectBCs */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_ML_CCZ4_ConstraintsInterior 
#define DECLARE_CCTK_ARGUMENTS_ML_CCZ4_ConstraintsInterior \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_REAL const * restrict const alpha __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).alpha));; /* TL: ML_CCZ4_ConstraintsInterior_C --> 0 no*/\
CCTK_REAL const * restrict const At11 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At11));; /* TL: ML_CCZ4_ConstraintsInterior_C --> 0 no*/\
CCTK_REAL const * restrict const At12 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At12));; /* TL: ML_CCZ4_ConstraintsInterior_C --> 0 no*/\
CCTK_REAL const * restrict const At13 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At13));; /* TL: ML_CCZ4_ConstraintsInterior_C --> 0 no*/\
CCTK_REAL const * restrict const At22 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At22));; /* TL: ML_CCZ4_ConstraintsInterior_C --> 0 no*/\
CCTK_REAL const * restrict const At23 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At23));; /* TL: ML_CCZ4_ConstraintsInterior_C --> 0 no*/\
CCTK_REAL const * restrict const At33 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At33));; /* TL: ML_CCZ4_ConstraintsInterior_C --> 0 no*/\
CCTK_REAL const * restrict const B1 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).B1));; /* TL: ML_CCZ4_ConstraintsInterior_C --> 0 no*/\
CCTK_REAL const * restrict const B2 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).B2));; /* TL: ML_CCZ4_ConstraintsInterior_C --> 0 no*/\
CCTK_REAL const * restrict const B3 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).B3));; /* TL: ML_CCZ4_ConstraintsInterior_C --> 0 no*/\
CCTK_REAL const * restrict const beta1 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).beta1));; /* TL: ML_CCZ4_ConstraintsInterior_C --> 0 no*/\
CCTK_REAL const * restrict const beta2 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).beta2));; /* TL: ML_CCZ4_ConstraintsInterior_C --> 0 no*/\
CCTK_REAL const * restrict const beta3 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).beta3));; /* TL: ML_CCZ4_ConstraintsInterior_C --> 0 no*/\
CCTK_REAL  * restrict const cXt1 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).cXt1));; /* TL: ML_CCZ4_ConstraintsInterior_C --> 0 no*/\
CCTK_REAL  * restrict const cXt2 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).cXt2));; /* TL: ML_CCZ4_ConstraintsInterior_C --> 0 no*/\
CCTK_REAL  * restrict const cXt3 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).cXt3));; /* TL: ML_CCZ4_ConstraintsInterior_C --> 0 no*/\
CCTK_REAL const * restrict const gt11 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt11));; /* TL: ML_CCZ4_ConstraintsInterior_C --> 0 no*/\
CCTK_REAL const * restrict const gt12 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt12));; /* TL: ML_CCZ4_ConstraintsInterior_C --> 0 no*/\
CCTK_REAL const * restrict const gt13 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt13));; /* TL: ML_CCZ4_ConstraintsInterior_C --> 0 no*/\
CCTK_REAL const * restrict const gt22 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt22));; /* TL: ML_CCZ4_ConstraintsInterior_C --> 0 no*/\
CCTK_REAL const * restrict const gt23 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt23));; /* TL: ML_CCZ4_ConstraintsInterior_C --> 0 no*/\
CCTK_REAL const * restrict const gt33 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt33));; /* TL: ML_CCZ4_ConstraintsInterior_C --> 0 no*/\
CCTK_REAL  * restrict const H __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).H));; /* TL: ML_CCZ4_ConstraintsInterior_C --> 0 no*/\
CCTK_REAL  * restrict const M1 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).M1));; /* TL: ML_CCZ4_ConstraintsInterior_C --> 0 no*/\
CCTK_REAL  * restrict const M2 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).M2));; /* TL: ML_CCZ4_ConstraintsInterior_C --> 0 no*/\
CCTK_REAL  * restrict const M3 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).M3));; /* TL: ML_CCZ4_ConstraintsInterior_C --> 0 no*/\
CCTK_REAL const * restrict const phi __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).phi));; /* TL: ML_CCZ4_ConstraintsInterior_C --> 0 no*/\
CCTK_REAL const * restrict const Theta __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Theta));; /* TL: ML_CCZ4_ConstraintsInterior_C --> 0 no*/\
CCTK_REAL const * restrict const trK __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).trK));; /* TL: ML_CCZ4_ConstraintsInterior_C --> 0 no*/\
CCTK_REAL const * restrict const Xt1 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Xt1));; /* TL: ML_CCZ4_ConstraintsInterior_C --> 0 no*/\
CCTK_REAL const * restrict const Xt2 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Xt2));; /* TL: ML_CCZ4_ConstraintsInterior_C --> 0 no*/\
CCTK_REAL const * restrict const Xt3 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Xt3));; /* TL: ML_CCZ4_ConstraintsInterior_C --> 0 no*/\
  /* end ML_CCZ4_ConstraintsInterior */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_ML_CCZ4_ConstraintsInterior_SelectBCs 
#define DECLARE_CCTK_ARGUMENTS_ML_CCZ4_ConstraintsInterior_SelectBCs \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end ML_CCZ4_ConstraintsInterior_SelectBCs */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_ML_CCZ4_EnforceEverywhere 
#define DECLARE_CCTK_ARGUMENTS_ML_CCZ4_EnforceEverywhere \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_REAL  * restrict const alpha __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).alpha));; /* TL: ML_CCZ4_EnforceEverywhere_C --> 0 no*/\
CCTK_REAL  * restrict const At11 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At11));; /* TL: ML_CCZ4_EnforceEverywhere_C --> 0 no*/\
CCTK_REAL  * restrict const At12 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At12));; /* TL: ML_CCZ4_EnforceEverywhere_C --> 0 no*/\
CCTK_REAL  * restrict const At13 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At13));; /* TL: ML_CCZ4_EnforceEverywhere_C --> 0 no*/\
CCTK_REAL  * restrict const At22 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At22));; /* TL: ML_CCZ4_EnforceEverywhere_C --> 0 no*/\
CCTK_REAL  * restrict const At23 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At23));; /* TL: ML_CCZ4_EnforceEverywhere_C --> 0 no*/\
CCTK_REAL  * restrict const At33 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At33));; /* TL: ML_CCZ4_EnforceEverywhere_C --> 0 no*/\
CCTK_REAL  * restrict const gt11 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt11));; /* TL: ML_CCZ4_EnforceEverywhere_C --> 0 no*/\
CCTK_REAL  * restrict const gt12 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt12));; /* TL: ML_CCZ4_EnforceEverywhere_C --> 0 no*/\
CCTK_REAL  * restrict const gt13 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt13));; /* TL: ML_CCZ4_EnforceEverywhere_C --> 0 no*/\
CCTK_REAL  * restrict const gt22 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt22));; /* TL: ML_CCZ4_EnforceEverywhere_C --> 0 no*/\
CCTK_REAL  * restrict const gt23 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt23));; /* TL: ML_CCZ4_EnforceEverywhere_C --> 0 no*/\
CCTK_REAL  * restrict const gt33 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt33));; /* TL: ML_CCZ4_EnforceEverywhere_C --> 0 no*/\
  /* end ML_CCZ4_EnforceEverywhere */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_ML_CCZ4_EvolutionAnalysisInit 
#define DECLARE_CCTK_ARGUMENTS_ML_CCZ4_EvolutionAnalysisInit \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_REAL  * restrict const alpharhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).alpharhs));; /* TL: ML_CCZ4_EvolutionAnalysisInit_C --> 0 no*/\
CCTK_REAL  * restrict const At11rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At11rhs));; /* TL: ML_CCZ4_EvolutionAnalysisInit_C --> 0 no*/\
CCTK_REAL  * restrict const At12rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At12rhs));; /* TL: ML_CCZ4_EvolutionAnalysisInit_C --> 0 no*/\
CCTK_REAL  * restrict const At13rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At13rhs));; /* TL: ML_CCZ4_EvolutionAnalysisInit_C --> 0 no*/\
CCTK_REAL  * restrict const At22rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At22rhs));; /* TL: ML_CCZ4_EvolutionAnalysisInit_C --> 0 no*/\
CCTK_REAL  * restrict const At23rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At23rhs));; /* TL: ML_CCZ4_EvolutionAnalysisInit_C --> 0 no*/\
CCTK_REAL  * restrict const At33rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At33rhs));; /* TL: ML_CCZ4_EvolutionAnalysisInit_C --> 0 no*/\
CCTK_REAL  * restrict const B1rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).B1rhs));; /* TL: ML_CCZ4_EvolutionAnalysisInit_C --> 0 no*/\
CCTK_REAL  * restrict const B2rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).B2rhs));; /* TL: ML_CCZ4_EvolutionAnalysisInit_C --> 0 no*/\
CCTK_REAL  * restrict const B3rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).B3rhs));; /* TL: ML_CCZ4_EvolutionAnalysisInit_C --> 0 no*/\
CCTK_REAL  * restrict const beta1rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).beta1rhs));; /* TL: ML_CCZ4_EvolutionAnalysisInit_C --> 0 no*/\
CCTK_REAL  * restrict const beta2rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).beta2rhs));; /* TL: ML_CCZ4_EvolutionAnalysisInit_C --> 0 no*/\
CCTK_REAL  * restrict const beta3rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).beta3rhs));; /* TL: ML_CCZ4_EvolutionAnalysisInit_C --> 0 no*/\
CCTK_REAL  * restrict const gt11rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt11rhs));; /* TL: ML_CCZ4_EvolutionAnalysisInit_C --> 0 no*/\
CCTK_REAL  * restrict const gt12rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt12rhs));; /* TL: ML_CCZ4_EvolutionAnalysisInit_C --> 0 no*/\
CCTK_REAL  * restrict const gt13rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt13rhs));; /* TL: ML_CCZ4_EvolutionAnalysisInit_C --> 0 no*/\
CCTK_REAL  * restrict const gt22rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt22rhs));; /* TL: ML_CCZ4_EvolutionAnalysisInit_C --> 0 no*/\
CCTK_REAL  * restrict const gt23rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt23rhs));; /* TL: ML_CCZ4_EvolutionAnalysisInit_C --> 0 no*/\
CCTK_REAL  * restrict const gt33rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt33rhs));; /* TL: ML_CCZ4_EvolutionAnalysisInit_C --> 0 no*/\
CCTK_REAL  * restrict const phirhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).phirhs));; /* TL: ML_CCZ4_EvolutionAnalysisInit_C --> 0 no*/\
CCTK_REAL  * restrict const Thetarhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Thetarhs));; /* TL: ML_CCZ4_EvolutionAnalysisInit_C --> 0 no*/\
CCTK_REAL  * restrict const trKrhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).trKrhs));; /* TL: ML_CCZ4_EvolutionAnalysisInit_C --> 0 no*/\
CCTK_REAL  * restrict const Xt1rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Xt1rhs));; /* TL: ML_CCZ4_EvolutionAnalysisInit_C --> 0 no*/\
CCTK_REAL  * restrict const Xt2rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Xt2rhs));; /* TL: ML_CCZ4_EvolutionAnalysisInit_C --> 0 no*/\
CCTK_REAL  * restrict const Xt3rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Xt3rhs));; /* TL: ML_CCZ4_EvolutionAnalysisInit_C --> 0 no*/\
  /* end ML_CCZ4_EvolutionAnalysisInit */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_ML_CCZ4_EvolutionAnalysisInterior 
#define DECLARE_CCTK_ARGUMENTS_ML_CCZ4_EvolutionAnalysisInterior \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_REAL const * restrict const alpha __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).alpha));; /* TL: ML_CCZ4_EvolutionAnalysisInterior_C --> 0 no*/\
CCTK_REAL  * restrict const alpharhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).alpharhs));; /* TL: ML_CCZ4_EvolutionAnalysisInterior_C --> 0 no*/\
CCTK_REAL const * restrict const At11 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At11));; /* TL: ML_CCZ4_EvolutionAnalysisInterior_C --> 0 no*/\
CCTK_REAL  * restrict const At11rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At11rhs));; /* TL: ML_CCZ4_EvolutionAnalysisInterior_C --> 0 no*/\
CCTK_REAL const * restrict const At12 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At12));; /* TL: ML_CCZ4_EvolutionAnalysisInterior_C --> 0 no*/\
CCTK_REAL  * restrict const At12rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At12rhs));; /* TL: ML_CCZ4_EvolutionAnalysisInterior_C --> 0 no*/\
CCTK_REAL const * restrict const At13 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At13));; /* TL: ML_CCZ4_EvolutionAnalysisInterior_C --> 0 no*/\
CCTK_REAL  * restrict const At13rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At13rhs));; /* TL: ML_CCZ4_EvolutionAnalysisInterior_C --> 0 no*/\
CCTK_REAL const * restrict const At22 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At22));; /* TL: ML_CCZ4_EvolutionAnalysisInterior_C --> 0 no*/\
CCTK_REAL  * restrict const At22rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At22rhs));; /* TL: ML_CCZ4_EvolutionAnalysisInterior_C --> 0 no*/\
CCTK_REAL const * restrict const At23 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At23));; /* TL: ML_CCZ4_EvolutionAnalysisInterior_C --> 0 no*/\
CCTK_REAL  * restrict const At23rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At23rhs));; /* TL: ML_CCZ4_EvolutionAnalysisInterior_C --> 0 no*/\
CCTK_REAL const * restrict const At33 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At33));; /* TL: ML_CCZ4_EvolutionAnalysisInterior_C --> 0 no*/\
CCTK_REAL  * restrict const At33rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At33rhs));; /* TL: ML_CCZ4_EvolutionAnalysisInterior_C --> 0 no*/\
CCTK_REAL const * restrict const B1 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).B1));; /* TL: ML_CCZ4_EvolutionAnalysisInterior_C --> 0 no*/\
CCTK_REAL  * restrict const B1rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).B1rhs));; /* TL: ML_CCZ4_EvolutionAnalysisInterior_C --> 0 no*/\
CCTK_REAL const * restrict const B2 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).B2));; /* TL: ML_CCZ4_EvolutionAnalysisInterior_C --> 0 no*/\
CCTK_REAL  * restrict const B2rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).B2rhs));; /* TL: ML_CCZ4_EvolutionAnalysisInterior_C --> 0 no*/\
CCTK_REAL const * restrict const B3 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).B3));; /* TL: ML_CCZ4_EvolutionAnalysisInterior_C --> 0 no*/\
CCTK_REAL  * restrict const B3rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).B3rhs));; /* TL: ML_CCZ4_EvolutionAnalysisInterior_C --> 0 no*/\
CCTK_REAL const * restrict const beta1 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).beta1));; /* TL: ML_CCZ4_EvolutionAnalysisInterior_C --> 0 no*/\
CCTK_REAL  * restrict const beta1rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).beta1rhs));; /* TL: ML_CCZ4_EvolutionAnalysisInterior_C --> 0 no*/\
CCTK_REAL const * restrict const beta2 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).beta2));; /* TL: ML_CCZ4_EvolutionAnalysisInterior_C --> 0 no*/\
CCTK_REAL  * restrict const beta2rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).beta2rhs));; /* TL: ML_CCZ4_EvolutionAnalysisInterior_C --> 0 no*/\
CCTK_REAL const * restrict const beta3 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).beta3));; /* TL: ML_CCZ4_EvolutionAnalysisInterior_C --> 0 no*/\
CCTK_REAL  * restrict const beta3rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).beta3rhs));; /* TL: ML_CCZ4_EvolutionAnalysisInterior_C --> 0 no*/\
CCTK_REAL const * restrict const gt11 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt11));; /* TL: ML_CCZ4_EvolutionAnalysisInterior_C --> 0 no*/\
CCTK_REAL  * restrict const gt11rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt11rhs));; /* TL: ML_CCZ4_EvolutionAnalysisInterior_C --> 0 no*/\
CCTK_REAL const * restrict const gt12 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt12));; /* TL: ML_CCZ4_EvolutionAnalysisInterior_C --> 0 no*/\
CCTK_REAL  * restrict const gt12rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt12rhs));; /* TL: ML_CCZ4_EvolutionAnalysisInterior_C --> 0 no*/\
CCTK_REAL const * restrict const gt13 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt13));; /* TL: ML_CCZ4_EvolutionAnalysisInterior_C --> 0 no*/\
CCTK_REAL  * restrict const gt13rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt13rhs));; /* TL: ML_CCZ4_EvolutionAnalysisInterior_C --> 0 no*/\
CCTK_REAL const * restrict const gt22 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt22));; /* TL: ML_CCZ4_EvolutionAnalysisInterior_C --> 0 no*/\
CCTK_REAL  * restrict const gt22rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt22rhs));; /* TL: ML_CCZ4_EvolutionAnalysisInterior_C --> 0 no*/\
CCTK_REAL const * restrict const gt23 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt23));; /* TL: ML_CCZ4_EvolutionAnalysisInterior_C --> 0 no*/\
CCTK_REAL  * restrict const gt23rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt23rhs));; /* TL: ML_CCZ4_EvolutionAnalysisInterior_C --> 0 no*/\
CCTK_REAL const * restrict const gt33 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt33));; /* TL: ML_CCZ4_EvolutionAnalysisInterior_C --> 0 no*/\
CCTK_REAL  * restrict const gt33rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt33rhs));; /* TL: ML_CCZ4_EvolutionAnalysisInterior_C --> 0 no*/\
CCTK_REAL const * restrict const phi __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).phi));; /* TL: ML_CCZ4_EvolutionAnalysisInterior_C --> 0 no*/\
CCTK_REAL  * restrict const phirhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).phirhs));; /* TL: ML_CCZ4_EvolutionAnalysisInterior_C --> 0 no*/\
CCTK_REAL const * restrict const Theta __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Theta));; /* TL: ML_CCZ4_EvolutionAnalysisInterior_C --> 0 no*/\
CCTK_REAL  * restrict const Thetarhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Thetarhs));; /* TL: ML_CCZ4_EvolutionAnalysisInterior_C --> 0 no*/\
CCTK_REAL const * restrict const trK __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).trK));; /* TL: ML_CCZ4_EvolutionAnalysisInterior_C --> 0 no*/\
CCTK_REAL  * restrict const trKrhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).trKrhs));; /* TL: ML_CCZ4_EvolutionAnalysisInterior_C --> 0 no*/\
CCTK_REAL const * restrict const Xt1 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Xt1));; /* TL: ML_CCZ4_EvolutionAnalysisInterior_C --> 0 no*/\
CCTK_REAL  * restrict const Xt1rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Xt1rhs));; /* TL: ML_CCZ4_EvolutionAnalysisInterior_C --> 0 no*/\
CCTK_REAL const * restrict const Xt2 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Xt2));; /* TL: ML_CCZ4_EvolutionAnalysisInterior_C --> 0 no*/\
CCTK_REAL  * restrict const Xt2rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Xt2rhs));; /* TL: ML_CCZ4_EvolutionAnalysisInterior_C --> 0 no*/\
CCTK_REAL const * restrict const Xt3 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Xt3));; /* TL: ML_CCZ4_EvolutionAnalysisInterior_C --> 0 no*/\
CCTK_REAL  * restrict const Xt3rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Xt3rhs));; /* TL: ML_CCZ4_EvolutionAnalysisInterior_C --> 0 no*/\
  /* end ML_CCZ4_EvolutionAnalysisInterior */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_ML_CCZ4_EvolutionBoundaryScalar 
#define DECLARE_CCTK_ARGUMENTS_ML_CCZ4_EvolutionBoundaryScalar \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_REAL  * restrict const alpharhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).alpharhs));; /* TL: ML_CCZ4_EvolutionBoundaryScalar_C --> 0 no*/\
CCTK_REAL  * restrict const At11rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At11rhs));; /* TL: ML_CCZ4_EvolutionBoundaryScalar_C --> 0 no*/\
CCTK_REAL  * restrict const At12rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At12rhs));; /* TL: ML_CCZ4_EvolutionBoundaryScalar_C --> 0 no*/\
CCTK_REAL  * restrict const At13rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At13rhs));; /* TL: ML_CCZ4_EvolutionBoundaryScalar_C --> 0 no*/\
CCTK_REAL  * restrict const At22rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At22rhs));; /* TL: ML_CCZ4_EvolutionBoundaryScalar_C --> 0 no*/\
CCTK_REAL  * restrict const At23rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At23rhs));; /* TL: ML_CCZ4_EvolutionBoundaryScalar_C --> 0 no*/\
CCTK_REAL  * restrict const At33rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At33rhs));; /* TL: ML_CCZ4_EvolutionBoundaryScalar_C --> 0 no*/\
CCTK_REAL  * restrict const B1rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).B1rhs));; /* TL: ML_CCZ4_EvolutionBoundaryScalar_C --> 0 no*/\
CCTK_REAL  * restrict const B2rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).B2rhs));; /* TL: ML_CCZ4_EvolutionBoundaryScalar_C --> 0 no*/\
CCTK_REAL  * restrict const B3rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).B3rhs));; /* TL: ML_CCZ4_EvolutionBoundaryScalar_C --> 0 no*/\
CCTK_REAL  * restrict const beta1rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).beta1rhs));; /* TL: ML_CCZ4_EvolutionBoundaryScalar_C --> 0 no*/\
CCTK_REAL  * restrict const beta2rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).beta2rhs));; /* TL: ML_CCZ4_EvolutionBoundaryScalar_C --> 0 no*/\
CCTK_REAL  * restrict const beta3rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).beta3rhs));; /* TL: ML_CCZ4_EvolutionBoundaryScalar_C --> 0 no*/\
CCTK_REAL  * restrict const gt11rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt11rhs));; /* TL: ML_CCZ4_EvolutionBoundaryScalar_C --> 0 no*/\
CCTK_REAL  * restrict const gt12rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt12rhs));; /* TL: ML_CCZ4_EvolutionBoundaryScalar_C --> 0 no*/\
CCTK_REAL  * restrict const gt13rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt13rhs));; /* TL: ML_CCZ4_EvolutionBoundaryScalar_C --> 0 no*/\
CCTK_REAL  * restrict const gt22rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt22rhs));; /* TL: ML_CCZ4_EvolutionBoundaryScalar_C --> 0 no*/\
CCTK_REAL  * restrict const gt23rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt23rhs));; /* TL: ML_CCZ4_EvolutionBoundaryScalar_C --> 0 no*/\
CCTK_REAL  * restrict const gt33rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt33rhs));; /* TL: ML_CCZ4_EvolutionBoundaryScalar_C --> 0 no*/\
CCTK_REAL  * restrict const phirhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).phirhs));; /* TL: ML_CCZ4_EvolutionBoundaryScalar_C --> 0 no*/\
CCTK_REAL  * restrict const Thetarhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Thetarhs));; /* TL: ML_CCZ4_EvolutionBoundaryScalar_C --> 0 no*/\
CCTK_REAL  * restrict const trKrhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).trKrhs));; /* TL: ML_CCZ4_EvolutionBoundaryScalar_C --> 0 no*/\
CCTK_REAL  * restrict const Xt1rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Xt1rhs));; /* TL: ML_CCZ4_EvolutionBoundaryScalar_C --> 0 no*/\
CCTK_REAL  * restrict const Xt2rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Xt2rhs));; /* TL: ML_CCZ4_EvolutionBoundaryScalar_C --> 0 no*/\
CCTK_REAL  * restrict const Xt3rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Xt3rhs));; /* TL: ML_CCZ4_EvolutionBoundaryScalar_C --> 0 no*/\
  /* end ML_CCZ4_EvolutionBoundaryScalar */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_ML_CCZ4_EvolutionInteriorSplitBy1 
#define DECLARE_CCTK_ARGUMENTS_ML_CCZ4_EvolutionInteriorSplitBy1 \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_REAL const * restrict const alpha __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).alpha));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy1_C --> 0 no*/\
CCTK_REAL  * restrict const alpharhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).alpharhs));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy1_C --> 0 no*/\
CCTK_REAL const * restrict const At11 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At11));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy1_C --> 0 no*/\
CCTK_REAL const * restrict const At12 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At12));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy1_C --> 0 no*/\
CCTK_REAL const * restrict const At13 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At13));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy1_C --> 0 no*/\
CCTK_REAL const * restrict const At22 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At22));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy1_C --> 0 no*/\
CCTK_REAL const * restrict const At23 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At23));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy1_C --> 0 no*/\
CCTK_REAL const * restrict const At33 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At33));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy1_C --> 0 no*/\
CCTK_REAL const * restrict const B1 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).B1));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy1_C --> 0 no*/\
CCTK_REAL const * restrict const B2 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).B2));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy1_C --> 0 no*/\
CCTK_REAL const * restrict const B3 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).B3));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy1_C --> 0 no*/\
CCTK_REAL const * restrict const beta1 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).beta1));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy1_C --> 0 no*/\
CCTK_REAL const * restrict const beta2 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).beta2));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy1_C --> 0 no*/\
CCTK_REAL const * restrict const beta3 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).beta3));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy1_C --> 0 no*/\
CCTK_REAL const * restrict const gt11 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt11));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy1_C --> 0 no*/\
CCTK_REAL  * restrict const gt11rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt11rhs));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy1_C --> 0 no*/\
CCTK_REAL const * restrict const gt12 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt12));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy1_C --> 0 no*/\
CCTK_REAL  * restrict const gt12rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt12rhs));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy1_C --> 0 no*/\
CCTK_REAL const * restrict const gt13 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt13));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy1_C --> 0 no*/\
CCTK_REAL  * restrict const gt13rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt13rhs));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy1_C --> 0 no*/\
CCTK_REAL const * restrict const gt22 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt22));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy1_C --> 0 no*/\
CCTK_REAL  * restrict const gt22rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt22rhs));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy1_C --> 0 no*/\
CCTK_REAL const * restrict const gt23 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt23));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy1_C --> 0 no*/\
CCTK_REAL  * restrict const gt23rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt23rhs));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy1_C --> 0 no*/\
CCTK_REAL const * restrict const gt33 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt33));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy1_C --> 0 no*/\
CCTK_REAL  * restrict const gt33rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt33rhs));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy1_C --> 0 no*/\
CCTK_REAL const * restrict const phi __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).phi));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy1_C --> 0 no*/\
CCTK_REAL  * restrict const phirhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).phirhs));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy1_C --> 0 no*/\
CCTK_REAL const * restrict const Theta __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Theta));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy1_C --> 0 no*/\
CCTK_REAL const * restrict const trK __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).trK));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy1_C --> 0 no*/\
CCTK_REAL const * restrict const Xt1 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Xt1));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy1_C --> 0 no*/\
CCTK_REAL const * restrict const Xt2 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Xt2));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy1_C --> 0 no*/\
CCTK_REAL const * restrict const Xt3 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Xt3));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy1_C --> 0 no*/\
  /* end ML_CCZ4_EvolutionInteriorSplitBy1 */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_ML_CCZ4_EvolutionInteriorSplitBy2 
#define DECLARE_CCTK_ARGUMENTS_ML_CCZ4_EvolutionInteriorSplitBy2 \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_REAL const * restrict const alpha __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).alpha));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy2_C --> 0 no*/\
CCTK_REAL const * restrict const At11 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At11));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy2_C --> 0 no*/\
CCTK_REAL const * restrict const At12 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At12));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy2_C --> 0 no*/\
CCTK_REAL const * restrict const At13 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At13));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy2_C --> 0 no*/\
CCTK_REAL const * restrict const At22 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At22));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy2_C --> 0 no*/\
CCTK_REAL const * restrict const At23 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At23));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy2_C --> 0 no*/\
CCTK_REAL const * restrict const At33 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At33));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy2_C --> 0 no*/\
CCTK_REAL const * restrict const B1 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).B1));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy2_C --> 0 no*/\
CCTK_REAL  * restrict const B1rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).B1rhs));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy2_C --> 0 no*/\
CCTK_REAL const * restrict const B2 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).B2));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy2_C --> 0 no*/\
CCTK_REAL  * restrict const B2rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).B2rhs));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy2_C --> 0 no*/\
CCTK_REAL const * restrict const B3 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).B3));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy2_C --> 0 no*/\
CCTK_REAL  * restrict const B3rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).B3rhs));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy2_C --> 0 no*/\
CCTK_REAL const * restrict const beta1 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).beta1));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy2_C --> 0 no*/\
CCTK_REAL  * restrict const beta1rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).beta1rhs));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy2_C --> 0 no*/\
CCTK_REAL const * restrict const beta2 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).beta2));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy2_C --> 0 no*/\
CCTK_REAL  * restrict const beta2rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).beta2rhs));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy2_C --> 0 no*/\
CCTK_REAL const * restrict const beta3 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).beta3));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy2_C --> 0 no*/\
CCTK_REAL  * restrict const beta3rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).beta3rhs));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy2_C --> 0 no*/\
CCTK_REAL const * restrict const gt11 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt11));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy2_C --> 0 no*/\
CCTK_REAL const * restrict const gt12 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt12));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy2_C --> 0 no*/\
CCTK_REAL const * restrict const gt13 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt13));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy2_C --> 0 no*/\
CCTK_REAL const * restrict const gt22 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt22));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy2_C --> 0 no*/\
CCTK_REAL const * restrict const gt23 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt23));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy2_C --> 0 no*/\
CCTK_REAL const * restrict const gt33 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt33));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy2_C --> 0 no*/\
CCTK_REAL const * restrict const phi __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).phi));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy2_C --> 0 no*/\
CCTK_REAL const * restrict const Theta __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Theta));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy2_C --> 0 no*/\
CCTK_REAL  * restrict const Thetarhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Thetarhs));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy2_C --> 0 no*/\
CCTK_REAL const * restrict const trK __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).trK));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy2_C --> 0 no*/\
CCTK_REAL  * restrict const trKrhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).trKrhs));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy2_C --> 0 no*/\
CCTK_REAL const * restrict const Xt1 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Xt1));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy2_C --> 0 no*/\
CCTK_REAL  * restrict const Xt1rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Xt1rhs));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy2_C --> 0 no*/\
CCTK_REAL const * restrict const Xt2 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Xt2));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy2_C --> 0 no*/\
CCTK_REAL  * restrict const Xt2rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Xt2rhs));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy2_C --> 0 no*/\
CCTK_REAL const * restrict const Xt3 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Xt3));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy2_C --> 0 no*/\
CCTK_REAL  * restrict const Xt3rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Xt3rhs));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy2_C --> 0 no*/\
  /* end ML_CCZ4_EvolutionInteriorSplitBy2 */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_ML_CCZ4_EvolutionInteriorSplitBy3 
#define DECLARE_CCTK_ARGUMENTS_ML_CCZ4_EvolutionInteriorSplitBy3 \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_REAL const * restrict const alpha __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).alpha));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy3_C --> 0 no*/\
CCTK_REAL const * restrict const At11 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At11));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy3_C --> 0 no*/\
CCTK_REAL  * restrict const At11rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At11rhs));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy3_C --> 0 no*/\
CCTK_REAL const * restrict const At12 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At12));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy3_C --> 0 no*/\
CCTK_REAL  * restrict const At12rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At12rhs));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy3_C --> 0 no*/\
CCTK_REAL const * restrict const At13 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At13));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy3_C --> 0 no*/\
CCTK_REAL  * restrict const At13rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At13rhs));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy3_C --> 0 no*/\
CCTK_REAL const * restrict const At22 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At22));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy3_C --> 0 no*/\
CCTK_REAL  * restrict const At22rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At22rhs));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy3_C --> 0 no*/\
CCTK_REAL const * restrict const At23 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At23));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy3_C --> 0 no*/\
CCTK_REAL  * restrict const At23rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At23rhs));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy3_C --> 0 no*/\
CCTK_REAL const * restrict const At33 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At33));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy3_C --> 0 no*/\
CCTK_REAL  * restrict const At33rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At33rhs));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy3_C --> 0 no*/\
CCTK_REAL const * restrict const B1 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).B1));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy3_C --> 0 no*/\
CCTK_REAL const * restrict const B2 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).B2));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy3_C --> 0 no*/\
CCTK_REAL const * restrict const B3 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).B3));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy3_C --> 0 no*/\
CCTK_REAL const * restrict const beta1 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).beta1));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy3_C --> 0 no*/\
CCTK_REAL const * restrict const beta2 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).beta2));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy3_C --> 0 no*/\
CCTK_REAL const * restrict const beta3 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).beta3));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy3_C --> 0 no*/\
CCTK_REAL const * restrict const gt11 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt11));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy3_C --> 0 no*/\
CCTK_REAL const * restrict const gt12 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt12));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy3_C --> 0 no*/\
CCTK_REAL const * restrict const gt13 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt13));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy3_C --> 0 no*/\
CCTK_REAL const * restrict const gt22 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt22));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy3_C --> 0 no*/\
CCTK_REAL const * restrict const gt23 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt23));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy3_C --> 0 no*/\
CCTK_REAL const * restrict const gt33 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt33));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy3_C --> 0 no*/\
CCTK_REAL const * restrict const phi __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).phi));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy3_C --> 0 no*/\
CCTK_REAL const * restrict const Theta __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Theta));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy3_C --> 0 no*/\
CCTK_REAL const * restrict const trK __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).trK));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy3_C --> 0 no*/\
CCTK_REAL const * restrict const Xt1 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Xt1));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy3_C --> 0 no*/\
CCTK_REAL const * restrict const Xt2 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Xt2));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy3_C --> 0 no*/\
CCTK_REAL const * restrict const Xt3 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Xt3));; /* TL: ML_CCZ4_EvolutionInteriorSplitBy3_C --> 0 no*/\
  /* end ML_CCZ4_EvolutionInteriorSplitBy3 */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_ML_CCZ4_EvolutionInterior 
#define DECLARE_CCTK_ARGUMENTS_ML_CCZ4_EvolutionInterior \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_REAL const * restrict const alpha __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).alpha));; /* TL: ML_CCZ4_EvolutionInterior_C --> 0 no*/\
CCTK_REAL  * restrict const alpharhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).alpharhs));; /* TL: ML_CCZ4_EvolutionInterior_C --> 0 no*/\
CCTK_REAL const * restrict const At11 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At11));; /* TL: ML_CCZ4_EvolutionInterior_C --> 0 no*/\
CCTK_REAL  * restrict const At11rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At11rhs));; /* TL: ML_CCZ4_EvolutionInterior_C --> 0 no*/\
CCTK_REAL const * restrict const At12 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At12));; /* TL: ML_CCZ4_EvolutionInterior_C --> 0 no*/\
CCTK_REAL  * restrict const At12rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At12rhs));; /* TL: ML_CCZ4_EvolutionInterior_C --> 0 no*/\
CCTK_REAL const * restrict const At13 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At13));; /* TL: ML_CCZ4_EvolutionInterior_C --> 0 no*/\
CCTK_REAL  * restrict const At13rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At13rhs));; /* TL: ML_CCZ4_EvolutionInterior_C --> 0 no*/\
CCTK_REAL const * restrict const At22 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At22));; /* TL: ML_CCZ4_EvolutionInterior_C --> 0 no*/\
CCTK_REAL  * restrict const At22rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At22rhs));; /* TL: ML_CCZ4_EvolutionInterior_C --> 0 no*/\
CCTK_REAL const * restrict const At23 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At23));; /* TL: ML_CCZ4_EvolutionInterior_C --> 0 no*/\
CCTK_REAL  * restrict const At23rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At23rhs));; /* TL: ML_CCZ4_EvolutionInterior_C --> 0 no*/\
CCTK_REAL const * restrict const At33 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At33));; /* TL: ML_CCZ4_EvolutionInterior_C --> 0 no*/\
CCTK_REAL  * restrict const At33rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At33rhs));; /* TL: ML_CCZ4_EvolutionInterior_C --> 0 no*/\
CCTK_REAL const * restrict const B1 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).B1));; /* TL: ML_CCZ4_EvolutionInterior_C --> 0 no*/\
CCTK_REAL  * restrict const B1rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).B1rhs));; /* TL: ML_CCZ4_EvolutionInterior_C --> 0 no*/\
CCTK_REAL const * restrict const B2 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).B2));; /* TL: ML_CCZ4_EvolutionInterior_C --> 0 no*/\
CCTK_REAL  * restrict const B2rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).B2rhs));; /* TL: ML_CCZ4_EvolutionInterior_C --> 0 no*/\
CCTK_REAL const * restrict const B3 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).B3));; /* TL: ML_CCZ4_EvolutionInterior_C --> 0 no*/\
CCTK_REAL  * restrict const B3rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).B3rhs));; /* TL: ML_CCZ4_EvolutionInterior_C --> 0 no*/\
CCTK_REAL const * restrict const beta1 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).beta1));; /* TL: ML_CCZ4_EvolutionInterior_C --> 0 no*/\
CCTK_REAL  * restrict const beta1rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).beta1rhs));; /* TL: ML_CCZ4_EvolutionInterior_C --> 0 no*/\
CCTK_REAL const * restrict const beta2 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).beta2));; /* TL: ML_CCZ4_EvolutionInterior_C --> 0 no*/\
CCTK_REAL  * restrict const beta2rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).beta2rhs));; /* TL: ML_CCZ4_EvolutionInterior_C --> 0 no*/\
CCTK_REAL const * restrict const beta3 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).beta3));; /* TL: ML_CCZ4_EvolutionInterior_C --> 0 no*/\
CCTK_REAL  * restrict const beta3rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).beta3rhs));; /* TL: ML_CCZ4_EvolutionInterior_C --> 0 no*/\
CCTK_REAL const * restrict const gt11 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt11));; /* TL: ML_CCZ4_EvolutionInterior_C --> 0 no*/\
CCTK_REAL  * restrict const gt11rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt11rhs));; /* TL: ML_CCZ4_EvolutionInterior_C --> 0 no*/\
CCTK_REAL const * restrict const gt12 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt12));; /* TL: ML_CCZ4_EvolutionInterior_C --> 0 no*/\
CCTK_REAL  * restrict const gt12rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt12rhs));; /* TL: ML_CCZ4_EvolutionInterior_C --> 0 no*/\
CCTK_REAL const * restrict const gt13 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt13));; /* TL: ML_CCZ4_EvolutionInterior_C --> 0 no*/\
CCTK_REAL  * restrict const gt13rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt13rhs));; /* TL: ML_CCZ4_EvolutionInterior_C --> 0 no*/\
CCTK_REAL const * restrict const gt22 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt22));; /* TL: ML_CCZ4_EvolutionInterior_C --> 0 no*/\
CCTK_REAL  * restrict const gt22rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt22rhs));; /* TL: ML_CCZ4_EvolutionInterior_C --> 0 no*/\
CCTK_REAL const * restrict const gt23 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt23));; /* TL: ML_CCZ4_EvolutionInterior_C --> 0 no*/\
CCTK_REAL  * restrict const gt23rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt23rhs));; /* TL: ML_CCZ4_EvolutionInterior_C --> 0 no*/\
CCTK_REAL const * restrict const gt33 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt33));; /* TL: ML_CCZ4_EvolutionInterior_C --> 0 no*/\
CCTK_REAL  * restrict const gt33rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt33rhs));; /* TL: ML_CCZ4_EvolutionInterior_C --> 0 no*/\
CCTK_REAL const * restrict const phi __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).phi));; /* TL: ML_CCZ4_EvolutionInterior_C --> 0 no*/\
CCTK_REAL  * restrict const phirhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).phirhs));; /* TL: ML_CCZ4_EvolutionInterior_C --> 0 no*/\
CCTK_REAL const * restrict const Theta __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Theta));; /* TL: ML_CCZ4_EvolutionInterior_C --> 0 no*/\
CCTK_REAL  * restrict const Thetarhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Thetarhs));; /* TL: ML_CCZ4_EvolutionInterior_C --> 0 no*/\
CCTK_REAL const * restrict const trK __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).trK));; /* TL: ML_CCZ4_EvolutionInterior_C --> 0 no*/\
CCTK_REAL  * restrict const trKrhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).trKrhs));; /* TL: ML_CCZ4_EvolutionInterior_C --> 0 no*/\
CCTK_REAL const * restrict const Xt1 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Xt1));; /* TL: ML_CCZ4_EvolutionInterior_C --> 0 no*/\
CCTK_REAL  * restrict const Xt1rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Xt1rhs));; /* TL: ML_CCZ4_EvolutionInterior_C --> 0 no*/\
CCTK_REAL const * restrict const Xt2 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Xt2));; /* TL: ML_CCZ4_EvolutionInterior_C --> 0 no*/\
CCTK_REAL  * restrict const Xt2rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Xt2rhs));; /* TL: ML_CCZ4_EvolutionInterior_C --> 0 no*/\
CCTK_REAL const * restrict const Xt3 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Xt3));; /* TL: ML_CCZ4_EvolutionInterior_C --> 0 no*/\
CCTK_REAL  * restrict const Xt3rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Xt3rhs));; /* TL: ML_CCZ4_EvolutionInterior_C --> 0 no*/\
  /* end ML_CCZ4_EvolutionInterior */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_ML_CCZ4_InitialADMBase1Everywhere 
#define DECLARE_CCTK_ARGUMENTS_ML_CCZ4_InitialADMBase1Everywhere \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_REAL const * restrict const alp __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).alp));; /* TL: ML_CCZ4_InitialADMBase1Everywhere_C --> 0 no*/\
CCTK_REAL const * restrict const betax __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).betax));; /* TL: ML_CCZ4_InitialADMBase1Everywhere_C --> 0 no*/\
CCTK_REAL const * restrict const betay __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).betay));; /* TL: ML_CCZ4_InitialADMBase1Everywhere_C --> 0 no*/\
CCTK_REAL const * restrict const betaz __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).betaz));; /* TL: ML_CCZ4_InitialADMBase1Everywhere_C --> 0 no*/\
CCTK_REAL const * restrict const gxx __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gxx));; /* TL: ML_CCZ4_InitialADMBase1Everywhere_C --> 0 no*/\
CCTK_REAL const * restrict const gxy __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gxy));; /* TL: ML_CCZ4_InitialADMBase1Everywhere_C --> 0 no*/\
CCTK_REAL const * restrict const gxz __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gxz));; /* TL: ML_CCZ4_InitialADMBase1Everywhere_C --> 0 no*/\
CCTK_REAL const * restrict const gyy __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gyy));; /* TL: ML_CCZ4_InitialADMBase1Everywhere_C --> 0 no*/\
CCTK_REAL const * restrict const gyz __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gyz));; /* TL: ML_CCZ4_InitialADMBase1Everywhere_C --> 0 no*/\
CCTK_REAL const * restrict const gzz __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gzz));; /* TL: ML_CCZ4_InitialADMBase1Everywhere_C --> 0 no*/\
CCTK_REAL const * restrict const kxx __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).kxx));; /* TL: ML_CCZ4_InitialADMBase1Everywhere_C --> 0 no*/\
CCTK_REAL const * restrict const kxy __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).kxy));; /* TL: ML_CCZ4_InitialADMBase1Everywhere_C --> 0 no*/\
CCTK_REAL const * restrict const kxz __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).kxz));; /* TL: ML_CCZ4_InitialADMBase1Everywhere_C --> 0 no*/\
CCTK_REAL const * restrict const kyy __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).kyy));; /* TL: ML_CCZ4_InitialADMBase1Everywhere_C --> 0 no*/\
CCTK_REAL const * restrict const kyz __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).kyz));; /* TL: ML_CCZ4_InitialADMBase1Everywhere_C --> 0 no*/\
CCTK_REAL const * restrict const kzz __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).kzz));; /* TL: ML_CCZ4_InitialADMBase1Everywhere_C --> 0 no*/\
CCTK_REAL  * restrict const alpha __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).alpha));; /* TL: ML_CCZ4_InitialADMBase1Everywhere_C --> 0 no*/\
CCTK_REAL  * restrict const At11 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At11));; /* TL: ML_CCZ4_InitialADMBase1Everywhere_C --> 0 no*/\
CCTK_REAL  * restrict const At12 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At12));; /* TL: ML_CCZ4_InitialADMBase1Everywhere_C --> 0 no*/\
CCTK_REAL  * restrict const At13 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At13));; /* TL: ML_CCZ4_InitialADMBase1Everywhere_C --> 0 no*/\
CCTK_REAL  * restrict const At22 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At22));; /* TL: ML_CCZ4_InitialADMBase1Everywhere_C --> 0 no*/\
CCTK_REAL  * restrict const At23 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At23));; /* TL: ML_CCZ4_InitialADMBase1Everywhere_C --> 0 no*/\
CCTK_REAL  * restrict const At33 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At33));; /* TL: ML_CCZ4_InitialADMBase1Everywhere_C --> 0 no*/\
CCTK_REAL  * restrict const beta1 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).beta1));; /* TL: ML_CCZ4_InitialADMBase1Everywhere_C --> 0 no*/\
CCTK_REAL  * restrict const beta2 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).beta2));; /* TL: ML_CCZ4_InitialADMBase1Everywhere_C --> 0 no*/\
CCTK_REAL  * restrict const beta3 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).beta3));; /* TL: ML_CCZ4_InitialADMBase1Everywhere_C --> 0 no*/\
CCTK_REAL  * restrict const gt11 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt11));; /* TL: ML_CCZ4_InitialADMBase1Everywhere_C --> 0 no*/\
CCTK_REAL  * restrict const gt12 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt12));; /* TL: ML_CCZ4_InitialADMBase1Everywhere_C --> 0 no*/\
CCTK_REAL  * restrict const gt13 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt13));; /* TL: ML_CCZ4_InitialADMBase1Everywhere_C --> 0 no*/\
CCTK_REAL  * restrict const gt22 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt22));; /* TL: ML_CCZ4_InitialADMBase1Everywhere_C --> 0 no*/\
CCTK_REAL  * restrict const gt23 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt23));; /* TL: ML_CCZ4_InitialADMBase1Everywhere_C --> 0 no*/\
CCTK_REAL  * restrict const gt33 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt33));; /* TL: ML_CCZ4_InitialADMBase1Everywhere_C --> 0 no*/\
CCTK_REAL  * restrict const phi __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).phi));; /* TL: ML_CCZ4_InitialADMBase1Everywhere_C --> 0 no*/\
CCTK_REAL  * restrict const Theta __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Theta));; /* TL: ML_CCZ4_InitialADMBase1Everywhere_C --> 0 no*/\
CCTK_REAL  * restrict const trK __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).trK));; /* TL: ML_CCZ4_InitialADMBase1Everywhere_C --> 0 no*/\
  /* end ML_CCZ4_InitialADMBase1Everywhere */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_ML_CCZ4_InitialADMBase2BoundaryScalar 
#define DECLARE_CCTK_ARGUMENTS_ML_CCZ4_InitialADMBase2BoundaryScalar \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_REAL  * restrict const B1 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).B1));; /* TL: ML_CCZ4_InitialADMBase2BoundaryScalar_C --> 0 no*/\
CCTK_REAL  * restrict const B2 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).B2));; /* TL: ML_CCZ4_InitialADMBase2BoundaryScalar_C --> 0 no*/\
CCTK_REAL  * restrict const B3 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).B3));; /* TL: ML_CCZ4_InitialADMBase2BoundaryScalar_C --> 0 no*/\
CCTK_REAL  * restrict const Xt1 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Xt1));; /* TL: ML_CCZ4_InitialADMBase2BoundaryScalar_C --> 0 no*/\
CCTK_REAL  * restrict const Xt2 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Xt2));; /* TL: ML_CCZ4_InitialADMBase2BoundaryScalar_C --> 0 no*/\
CCTK_REAL  * restrict const Xt3 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Xt3));; /* TL: ML_CCZ4_InitialADMBase2BoundaryScalar_C --> 0 no*/\
  /* end ML_CCZ4_InitialADMBase2BoundaryScalar */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_ML_CCZ4_InitialADMBase2Interior 
#define DECLARE_CCTK_ARGUMENTS_ML_CCZ4_InitialADMBase2Interior \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_REAL const * restrict const alp __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).alp));; /* TL: ML_CCZ4_InitialADMBase2Interior_C --> 0 no*/\
CCTK_REAL const * restrict const betax __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).betax));; /* TL: ML_CCZ4_InitialADMBase2Interior_C --> 0 no*/\
CCTK_REAL const * restrict const betay __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).betay));; /* TL: ML_CCZ4_InitialADMBase2Interior_C --> 0 no*/\
CCTK_REAL const * restrict const betaz __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).betaz));; /* TL: ML_CCZ4_InitialADMBase2Interior_C --> 0 no*/\
CCTK_REAL const * restrict const dtbetax __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).dtbetax));; /* TL: ML_CCZ4_InitialADMBase2Interior_C --> 0 no*/\
CCTK_REAL const * restrict const dtbetay __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).dtbetay));; /* TL: ML_CCZ4_InitialADMBase2Interior_C --> 0 no*/\
CCTK_REAL const * restrict const dtbetaz __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).dtbetaz));; /* TL: ML_CCZ4_InitialADMBase2Interior_C --> 0 no*/\
CCTK_REAL const * restrict const gxx __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gxx));; /* TL: ML_CCZ4_InitialADMBase2Interior_C --> 0 no*/\
CCTK_REAL const * restrict const gxy __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gxy));; /* TL: ML_CCZ4_InitialADMBase2Interior_C --> 0 no*/\
CCTK_REAL const * restrict const gxz __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gxz));; /* TL: ML_CCZ4_InitialADMBase2Interior_C --> 0 no*/\
CCTK_REAL const * restrict const gyy __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gyy));; /* TL: ML_CCZ4_InitialADMBase2Interior_C --> 0 no*/\
CCTK_REAL const * restrict const gyz __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gyz));; /* TL: ML_CCZ4_InitialADMBase2Interior_C --> 0 no*/\
CCTK_REAL const * restrict const gzz __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gzz));; /* TL: ML_CCZ4_InitialADMBase2Interior_C --> 0 no*/\
CCTK_REAL  * restrict const B1 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).B1));; /* TL: ML_CCZ4_InitialADMBase2Interior_C --> 0 no*/\
CCTK_REAL  * restrict const B2 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).B2));; /* TL: ML_CCZ4_InitialADMBase2Interior_C --> 0 no*/\
CCTK_REAL  * restrict const B3 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).B3));; /* TL: ML_CCZ4_InitialADMBase2Interior_C --> 0 no*/\
CCTK_REAL const * restrict const gt11 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt11));; /* TL: ML_CCZ4_InitialADMBase2Interior_C --> 0 no*/\
CCTK_REAL const * restrict const gt12 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt12));; /* TL: ML_CCZ4_InitialADMBase2Interior_C --> 0 no*/\
CCTK_REAL const * restrict const gt13 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt13));; /* TL: ML_CCZ4_InitialADMBase2Interior_C --> 0 no*/\
CCTK_REAL const * restrict const gt22 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt22));; /* TL: ML_CCZ4_InitialADMBase2Interior_C --> 0 no*/\
CCTK_REAL const * restrict const gt23 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt23));; /* TL: ML_CCZ4_InitialADMBase2Interior_C --> 0 no*/\
CCTK_REAL const * restrict const gt33 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt33));; /* TL: ML_CCZ4_InitialADMBase2Interior_C --> 0 no*/\
CCTK_REAL const * restrict const phi __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).phi));; /* TL: ML_CCZ4_InitialADMBase2Interior_C --> 0 no*/\
CCTK_REAL  * restrict const Xt1 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Xt1));; /* TL: ML_CCZ4_InitialADMBase2Interior_C --> 0 no*/\
CCTK_REAL  * restrict const Xt2 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Xt2));; /* TL: ML_CCZ4_InitialADMBase2Interior_C --> 0 no*/\
CCTK_REAL  * restrict const Xt3 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Xt3));; /* TL: ML_CCZ4_InitialADMBase2Interior_C --> 0 no*/\
  /* end ML_CCZ4_InitialADMBase2Interior */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_ML_CCZ4_RegisterSymmetries 
#define DECLARE_CCTK_ARGUMENTS_ML_CCZ4_RegisterSymmetries \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end ML_CCZ4_RegisterSymmetries */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_ML_CCZ4_RegisterVars 
#define DECLARE_CCTK_ARGUMENTS_ML_CCZ4_RegisterVars \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end ML_CCZ4_RegisterVars */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_ML_CCZ4_SelectBoundConds 
#define DECLARE_CCTK_ARGUMENTS_ML_CCZ4_SelectBoundConds \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end ML_CCZ4_SelectBoundConds */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_ML_CCZ4_Startup 
#define DECLARE_CCTK_ARGUMENTS_ML_CCZ4_Startup \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end ML_CCZ4_Startup */
#endif
#endif
#endif