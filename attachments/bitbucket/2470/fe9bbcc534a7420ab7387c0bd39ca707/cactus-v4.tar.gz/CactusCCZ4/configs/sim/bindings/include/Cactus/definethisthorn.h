/* Defines for thorn this file is part of */

#ifndef DEFINE_THIS_THORN_H
#define DEFINE_THIS_THORN_H 1
#define THORN_IS_Cactus 1
#define CCTK_THORN src
#define CCTK_THORNSTRING "src"
#define CCTK_ARRANGEMENT CactusSpec8Try2
#define CCTK_ARRANGEMENTSTRING "CactusSpec8Try2"
#endif

