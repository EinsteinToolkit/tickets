#ifndef CCTK_ARGUMENTS_CHECKED_H
#define CCTK_ARGUMENTS_CHECKED_H 1

/* needed for CCTK_ANSI_FPP */
#include "cctk_Types.h"

#ifdef CCODE
#define DECLARE_CCTK_ARGUMENTS_CHECKED(func) DECLARE_CCTK_ARGUMENTS_##func
#endif
#ifdef FCODE
#if CCTK_ANSI_FPP
#define DECLARE_CCTK_ARGUMENTS_CHECKED(func) DECLARE_CCTK_ARGUMENTS_##func
#else
#define DECLARE_CCTK_ARGUMENTS_CHECKED(func) DECLARE_CCTK_ARGUMENTS_/**/func
#endif
#endif

#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_IOBasic_Init 
#define DECLARE_CCTK_ARGUMENTS_IOBasic_Init \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_REAL  * restrict const next_info_output_time __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).next_info_output_time));; /* TL: IOBasic_Init_C --> 0 no*/\
CCTK_REAL  * restrict const next_scalar_output_time __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).next_scalar_output_time));; /* TL: IOBasic_Init_C --> 0 no*/\
  /* end IOBasic_Init */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_IOBasic_Startup 
#define DECLARE_CCTK_ARGUMENTS_IOBasic_Startup \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end IOBasic_Startup */
#endif
#endif
#endif