/*  File produced by Kranc */

#define KRANC_C

#include <algorithm>
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cctk.h"
#include "cctk_Arguments.h"
#include "cctk_Parameters.h"
#include "Kranc.hh"
#include "Differencing.h"

namespace ML_CCZ4 {

extern "C" void ML_CCZ4_ADMBaseInterior_SelectBCs(CCTK_ARGUMENTS)
{
  #ifdef DECLARE_CCTK_ARGUMENTS_ML_CCZ4_ADMBaseInterior_SelectBCs
  DECLARE_CCTK_ARGUMENTS_CHECKED(ML_CCZ4_ADMBaseInterior_SelectBCs);
  #else
  DECLARE_CCTK_ARGUMENTS;
  #endif
  DECLARE_CCTK_PARAMETERS;
  
  if (cctk_iteration % ML_CCZ4_ADMBaseInterior_calc_every != ML_CCZ4_ADMBaseInterior_calc_offset)
    return;
  CCTK_INT ierr CCTK_ATTRIBUTE_UNUSED = 0;
  ierr = KrancBdy_SelectGroupForBC(cctkGH, CCTK_ALL_FACES, GetBoundaryWidth(cctkGH), -1 /* no table */, "ADMBase::dtlapse","flat");
  if (ierr < 0)
    CCTK_WARN(CCTK_WARN_ALERT, "Failed to register flat BC for ADMBase::dtlapse.");
  ierr = KrancBdy_SelectGroupForBC(cctkGH, CCTK_ALL_FACES, GetBoundaryWidth(cctkGH), -1 /* no table */, "ADMBase::dtshift","flat");
  if (ierr < 0)
    CCTK_WARN(CCTK_WARN_ALERT, "Failed to register flat BC for ADMBase::dtshift.");
  return;
}

static void ML_CCZ4_ADMBaseInterior_Body(const cGH* restrict const cctkGH, const int dir, const int face, const CCTK_REAL normal[3], const CCTK_REAL tangentA[3], const CCTK_REAL tangentB[3], const int imin[3], const int imax[3], const int n_subblock_gfs, CCTK_REAL* restrict const subblock_gfs[])
{
  DECLARE_CCTK_ARGUMENTS;
  DECLARE_CCTK_PARAMETERS;
  
  /* Include user-supplied include files */
  /* Initialise finite differencing variables */
  const ptrdiff_t di CCTK_ATTRIBUTE_UNUSED = 1;
  const ptrdiff_t dj CCTK_ATTRIBUTE_UNUSED = 
    CCTK_GFINDEX3D(cctkGH,0,1,0) - CCTK_GFINDEX3D(cctkGH,0,0,0);
  const ptrdiff_t dk CCTK_ATTRIBUTE_UNUSED = 
    CCTK_GFINDEX3D(cctkGH,0,0,1) - CCTK_GFINDEX3D(cctkGH,0,0,0);
  const ptrdiff_t cdi CCTK_ATTRIBUTE_UNUSED = sizeof(CCTK_REAL) * di;
  const ptrdiff_t cdj CCTK_ATTRIBUTE_UNUSED = sizeof(CCTK_REAL) * dj;
  const ptrdiff_t cdk CCTK_ATTRIBUTE_UNUSED = sizeof(CCTK_REAL) * dk;
  const ptrdiff_t cctkLbnd1 CCTK_ATTRIBUTE_UNUSED = cctk_lbnd[0];
  const ptrdiff_t cctkLbnd2 CCTK_ATTRIBUTE_UNUSED = cctk_lbnd[1];
  const ptrdiff_t cctkLbnd3 CCTK_ATTRIBUTE_UNUSED = cctk_lbnd[2];
  const CCTK_REAL t CCTK_ATTRIBUTE_UNUSED = cctk_time;
  const CCTK_REAL cctkOriginSpace1 CCTK_ATTRIBUTE_UNUSED = 
    CCTK_ORIGIN_SPACE(0);
  const CCTK_REAL cctkOriginSpace2 CCTK_ATTRIBUTE_UNUSED = 
    CCTK_ORIGIN_SPACE(1);
  const CCTK_REAL cctkOriginSpace3 CCTK_ATTRIBUTE_UNUSED = 
    CCTK_ORIGIN_SPACE(2);
  const CCTK_REAL dt CCTK_ATTRIBUTE_UNUSED = CCTK_DELTA_TIME;
  const CCTK_REAL dx CCTK_ATTRIBUTE_UNUSED = CCTK_DELTA_SPACE(0);
  const CCTK_REAL dy CCTK_ATTRIBUTE_UNUSED = CCTK_DELTA_SPACE(1);
  const CCTK_REAL dz CCTK_ATTRIBUTE_UNUSED = CCTK_DELTA_SPACE(2);
  const CCTK_REAL dxi CCTK_ATTRIBUTE_UNUSED = pow(dx,-1);
  const CCTK_REAL dyi CCTK_ATTRIBUTE_UNUSED = pow(dy,-1);
  const CCTK_REAL dzi CCTK_ATTRIBUTE_UNUSED = pow(dz,-1);
  const CCTK_REAL khalf CCTK_ATTRIBUTE_UNUSED = 0.5;
  const CCTK_REAL kthird CCTK_ATTRIBUTE_UNUSED = 
    0.333333333333333333333333333333;
  const CCTK_REAL ktwothird CCTK_ATTRIBUTE_UNUSED = 
    0.666666666666666666666666666667;
  const CCTK_REAL kfourthird CCTK_ATTRIBUTE_UNUSED = 
    1.33333333333333333333333333333;
  const CCTK_REAL hdxi CCTK_ATTRIBUTE_UNUSED = 0.5*dxi;
  const CCTK_REAL hdyi CCTK_ATTRIBUTE_UNUSED = 0.5*dyi;
  const CCTK_REAL hdzi CCTK_ATTRIBUTE_UNUSED = 0.5*dzi;
  /* Initialize predefined quantities */
  const CCTK_REAL p1o1024dx CCTK_ATTRIBUTE_UNUSED = 0.0009765625*pow(dx,-1);
  const CCTK_REAL p1o1024dy CCTK_ATTRIBUTE_UNUSED = 0.0009765625*pow(dy,-1);
  const CCTK_REAL p1o1024dz CCTK_ATTRIBUTE_UNUSED = 0.0009765625*pow(dz,-1);
  const CCTK_REAL p1o1680dx CCTK_ATTRIBUTE_UNUSED = 0.000595238095238095238095238095238*pow(dx,-1);
  const CCTK_REAL p1o1680dy CCTK_ATTRIBUTE_UNUSED = 0.000595238095238095238095238095238*pow(dy,-1);
  const CCTK_REAL p1o1680dz CCTK_ATTRIBUTE_UNUSED = 0.000595238095238095238095238095238*pow(dz,-1);
  const CCTK_REAL p1o5040dx2 CCTK_ATTRIBUTE_UNUSED = 0.000198412698412698412698412698413*pow(dx,-2);
  const CCTK_REAL p1o5040dy2 CCTK_ATTRIBUTE_UNUSED = 0.000198412698412698412698412698413*pow(dy,-2);
  const CCTK_REAL p1o5040dz2 CCTK_ATTRIBUTE_UNUSED = 0.000198412698412698412698412698413*pow(dz,-2);
  const CCTK_REAL p1o560dx CCTK_ATTRIBUTE_UNUSED = 0.00178571428571428571428571428571*pow(dx,-1);
  const CCTK_REAL p1o560dy CCTK_ATTRIBUTE_UNUSED = 0.00178571428571428571428571428571*pow(dy,-1);
  const CCTK_REAL p1o560dz CCTK_ATTRIBUTE_UNUSED = 0.00178571428571428571428571428571*pow(dz,-1);
  const CCTK_REAL p1o60dx CCTK_ATTRIBUTE_UNUSED = 0.0166666666666666666666666666667*pow(dx,-1);
  const CCTK_REAL p1o60dy CCTK_ATTRIBUTE_UNUSED = 0.0166666666666666666666666666667*pow(dy,-1);
  const CCTK_REAL p1o60dz CCTK_ATTRIBUTE_UNUSED = 0.0166666666666666666666666666667*pow(dz,-1);
  const CCTK_REAL p1o705600dxdy CCTK_ATTRIBUTE_UNUSED = 1.41723356009070294784580498866e-6*pow(dx,-1)*pow(dy,-1);
  const CCTK_REAL p1o705600dxdz CCTK_ATTRIBUTE_UNUSED = 1.41723356009070294784580498866e-6*pow(dx,-1)*pow(dz,-1);
  const CCTK_REAL p1o705600dydz CCTK_ATTRIBUTE_UNUSED = 1.41723356009070294784580498866e-6*pow(dy,-1)*pow(dz,-1);
  const CCTK_REAL p1o840dx CCTK_ATTRIBUTE_UNUSED = 0.00119047619047619047619047619048*pow(dx,-1);
  const CCTK_REAL p1o840dy CCTK_ATTRIBUTE_UNUSED = 0.00119047619047619047619047619048*pow(dy,-1);
  const CCTK_REAL p1o840dz CCTK_ATTRIBUTE_UNUSED = 0.00119047619047619047619047619048*pow(dz,-1);
  const CCTK_REAL pm1o840dx CCTK_ATTRIBUTE_UNUSED = -0.00119047619047619047619047619048*pow(dx,-1);
  const CCTK_REAL pm1o840dy CCTK_ATTRIBUTE_UNUSED = -0.00119047619047619047619047619048*pow(dy,-1);
  const CCTK_REAL pm1o840dz CCTK_ATTRIBUTE_UNUSED = -0.00119047619047619047619047619048*pow(dz,-1);
  /* Assign local copies of arrays functions */
  
  
  /* Calculate temporaries and arrays functions */
  /* Copy local copies back to grid functions */
  /* Loop over the grid points */
  const int imin0=imin[0];
  const int imin1=imin[1];
  const int imin2=imin[2];
  const int imax0=imax[0];
  const int imax1=imax[1];
  const int imax2=imax[2];
  #pragma omp parallel
  CCTK_LOOP3(ML_CCZ4_ADMBaseInterior,
    i,j,k, imin0,imin1,imin2, imax0,imax1,imax2,
    cctk_ash[0],cctk_ash[1],cctk_ash[2])
  {
    const ptrdiff_t index CCTK_ATTRIBUTE_UNUSED = di*i + dj*j + dk*k;
    /* Assign local copies of grid functions */
    
    CCTK_REAL alphaL CCTK_ATTRIBUTE_UNUSED = alpha[index];
    CCTK_REAL B1L CCTK_ATTRIBUTE_UNUSED = B1[index];
    CCTK_REAL B2L CCTK_ATTRIBUTE_UNUSED = B2[index];
    CCTK_REAL B3L CCTK_ATTRIBUTE_UNUSED = B3[index];
    CCTK_REAL beta1L CCTK_ATTRIBUTE_UNUSED = beta1[index];
    CCTK_REAL beta2L CCTK_ATTRIBUTE_UNUSED = beta2[index];
    CCTK_REAL beta3L CCTK_ATTRIBUTE_UNUSED = beta3[index];
    CCTK_REAL gt11L CCTK_ATTRIBUTE_UNUSED = gt11[index];
    CCTK_REAL gt12L CCTK_ATTRIBUTE_UNUSED = gt12[index];
    CCTK_REAL gt13L CCTK_ATTRIBUTE_UNUSED = gt13[index];
    CCTK_REAL gt22L CCTK_ATTRIBUTE_UNUSED = gt22[index];
    CCTK_REAL gt23L CCTK_ATTRIBUTE_UNUSED = gt23[index];
    CCTK_REAL gt33L CCTK_ATTRIBUTE_UNUSED = gt33[index];
    CCTK_REAL phiL CCTK_ATTRIBUTE_UNUSED = phi[index];
    CCTK_REAL rL CCTK_ATTRIBUTE_UNUSED = r[index];
    CCTK_REAL ThetaL CCTK_ATTRIBUTE_UNUSED = Theta[index];
    CCTK_REAL trKL CCTK_ATTRIBUTE_UNUSED = trK[index];
    
    /* Include user supplied include files */
    /* Precompute derivatives */
    const CCTK_REAL PDstandardNth1alpha CCTK_ATTRIBUTE_UNUSED = PDstandardNth1(&alpha[index]);
    const CCTK_REAL PDstandardNth2alpha CCTK_ATTRIBUTE_UNUSED = PDstandardNth2(&alpha[index]);
    const CCTK_REAL PDstandardNth3alpha CCTK_ATTRIBUTE_UNUSED = PDstandardNth3(&alpha[index]);
    const CCTK_REAL PDupwindNthSymm1alpha CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm1(&alpha[index]);
    const CCTK_REAL PDupwindNthSymm2alpha CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm2(&alpha[index]);
    const CCTK_REAL PDupwindNthSymm3alpha CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm3(&alpha[index]);
    const CCTK_REAL PDupwindNthAnti1alpha CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti1(&alpha[index]);
    const CCTK_REAL PDupwindNthAnti2alpha CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti2(&alpha[index]);
    const CCTK_REAL PDupwindNthAnti3alpha CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti3(&alpha[index]);
    const CCTK_REAL PDupwindNthSymm1beta1 CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm1(&beta1[index]);
    const CCTK_REAL PDupwindNthSymm2beta1 CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm2(&beta1[index]);
    const CCTK_REAL PDupwindNthSymm3beta1 CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm3(&beta1[index]);
    const CCTK_REAL PDupwindNthAnti1beta1 CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti1(&beta1[index]);
    const CCTK_REAL PDupwindNthAnti2beta1 CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti2(&beta1[index]);
    const CCTK_REAL PDupwindNthAnti3beta1 CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti3(&beta1[index]);
    const CCTK_REAL PDupwindNthSymm1beta2 CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm1(&beta2[index]);
    const CCTK_REAL PDupwindNthSymm2beta2 CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm2(&beta2[index]);
    const CCTK_REAL PDupwindNthSymm3beta2 CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm3(&beta2[index]);
    const CCTK_REAL PDupwindNthAnti1beta2 CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti1(&beta2[index]);
    const CCTK_REAL PDupwindNthAnti2beta2 CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti2(&beta2[index]);
    const CCTK_REAL PDupwindNthAnti3beta2 CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti3(&beta2[index]);
    const CCTK_REAL PDupwindNthSymm1beta3 CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm1(&beta3[index]);
    const CCTK_REAL PDupwindNthSymm2beta3 CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm2(&beta3[index]);
    const CCTK_REAL PDupwindNthSymm3beta3 CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm3(&beta3[index]);
    const CCTK_REAL PDupwindNthAnti1beta3 CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti1(&beta3[index]);
    const CCTK_REAL PDupwindNthAnti2beta3 CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti2(&beta3[index]);
    const CCTK_REAL PDupwindNthAnti3beta3 CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti3(&beta3[index]);
    const CCTK_REAL PDstandardNth1gt11 CCTK_ATTRIBUTE_UNUSED = PDstandardNth1(&gt11[index]);
    const CCTK_REAL PDstandardNth2gt11 CCTK_ATTRIBUTE_UNUSED = PDstandardNth2(&gt11[index]);
    const CCTK_REAL PDstandardNth3gt11 CCTK_ATTRIBUTE_UNUSED = PDstandardNth3(&gt11[index]);
    const CCTK_REAL PDstandardNth1gt12 CCTK_ATTRIBUTE_UNUSED = PDstandardNth1(&gt12[index]);
    const CCTK_REAL PDstandardNth2gt12 CCTK_ATTRIBUTE_UNUSED = PDstandardNth2(&gt12[index]);
    const CCTK_REAL PDstandardNth3gt12 CCTK_ATTRIBUTE_UNUSED = PDstandardNth3(&gt12[index]);
    const CCTK_REAL PDstandardNth1gt13 CCTK_ATTRIBUTE_UNUSED = PDstandardNth1(&gt13[index]);
    const CCTK_REAL PDstandardNth2gt13 CCTK_ATTRIBUTE_UNUSED = PDstandardNth2(&gt13[index]);
    const CCTK_REAL PDstandardNth3gt13 CCTK_ATTRIBUTE_UNUSED = PDstandardNth3(&gt13[index]);
    const CCTK_REAL PDstandardNth1gt22 CCTK_ATTRIBUTE_UNUSED = PDstandardNth1(&gt22[index]);
    const CCTK_REAL PDstandardNth2gt22 CCTK_ATTRIBUTE_UNUSED = PDstandardNth2(&gt22[index]);
    const CCTK_REAL PDstandardNth3gt22 CCTK_ATTRIBUTE_UNUSED = PDstandardNth3(&gt22[index]);
    const CCTK_REAL PDstandardNth1gt23 CCTK_ATTRIBUTE_UNUSED = PDstandardNth1(&gt23[index]);
    const CCTK_REAL PDstandardNth2gt23 CCTK_ATTRIBUTE_UNUSED = PDstandardNth2(&gt23[index]);
    const CCTK_REAL PDstandardNth3gt23 CCTK_ATTRIBUTE_UNUSED = PDstandardNth3(&gt23[index]);
    const CCTK_REAL PDstandardNth1gt33 CCTK_ATTRIBUTE_UNUSED = PDstandardNth1(&gt33[index]);
    const CCTK_REAL PDstandardNth2gt33 CCTK_ATTRIBUTE_UNUSED = PDstandardNth2(&gt33[index]);
    const CCTK_REAL PDstandardNth3gt33 CCTK_ATTRIBUTE_UNUSED = PDstandardNth3(&gt33[index]);
    const CCTK_REAL PDstandardNth1phi CCTK_ATTRIBUTE_UNUSED = PDstandardNth1(&phi[index]);
    const CCTK_REAL PDstandardNth2phi CCTK_ATTRIBUTE_UNUSED = PDstandardNth2(&phi[index]);
    const CCTK_REAL PDstandardNth3phi CCTK_ATTRIBUTE_UNUSED = PDstandardNth3(&phi[index]);
    /* Calculate temporaries and grid functions */
    CCTK_REAL detgt CCTK_ATTRIBUTE_UNUSED = 1;
    
    CCTK_REAL gtu11 CCTK_ATTRIBUTE_UNUSED = (gt22L*gt33L - 
      pow(gt23L,2))*pow(detgt,-1);
    
    CCTK_REAL gtu12 CCTK_ATTRIBUTE_UNUSED = (gt13L*gt23L - 
      gt12L*gt33L)*pow(detgt,-1);
    
    CCTK_REAL gtu13 CCTK_ATTRIBUTE_UNUSED = (-(gt13L*gt22L) + 
      gt12L*gt23L)*pow(detgt,-1);
    
    CCTK_REAL gtu22 CCTK_ATTRIBUTE_UNUSED = (gt11L*gt33L - 
      pow(gt13L,2))*pow(detgt,-1);
    
    CCTK_REAL gtu23 CCTK_ATTRIBUTE_UNUSED = (gt12L*gt13L - 
      gt11L*gt23L)*pow(detgt,-1);
    
    CCTK_REAL gtu33 CCTK_ATTRIBUTE_UNUSED = (gt11L*gt22L - 
      pow(gt12L,2))*pow(detgt,-1);
    
    CCTK_REAL em4phi CCTK_ATTRIBUTE_UNUSED = pow(phiL,2);
    
    CCTK_REAL gu11 CCTK_ATTRIBUTE_UNUSED = em4phi*gtu11;
    
    CCTK_REAL gu12 CCTK_ATTRIBUTE_UNUSED = em4phi*gtu12;
    
    CCTK_REAL gu13 CCTK_ATTRIBUTE_UNUSED = em4phi*gtu13;
    
    CCTK_REAL gu22 CCTK_ATTRIBUTE_UNUSED = em4phi*gtu22;
    
    CCTK_REAL gu23 CCTK_ATTRIBUTE_UNUSED = em4phi*gtu23;
    
    CCTK_REAL gu33 CCTK_ATTRIBUTE_UNUSED = em4phi*gtu33;
    
    CCTK_REAL fac1 CCTK_ATTRIBUTE_UNUSED = -0.5*pow(phiL,-1);
    
    CCTK_REAL cdphi1 CCTK_ATTRIBUTE_UNUSED = fac1*PDstandardNth1phi;
    
    CCTK_REAL cdphi2 CCTK_ATTRIBUTE_UNUSED = fac1*PDstandardNth2phi;
    
    CCTK_REAL cdphi3 CCTK_ATTRIBUTE_UNUSED = fac1*PDstandardNth3phi;
    
    CCTK_REAL dotalpha CCTK_ATTRIBUTE_UNUSED = -((-2*ThetaL + trKL + (-1 + 
      alphaL)*alphaDriver)*harmonicF*pow(alphaL,harmonicN));
    
    CCTK_REAL shiftGammaCoeffValue CCTK_ATTRIBUTE_UNUSED = 
      IfThen(useSpatialShiftGammaCoeff != 0,shiftGammaCoeff*fmin(1,exp(1 - 
      rL*pow(spatialShiftGammaCoeffRadius,-1))),shiftGammaCoeff);
    
    CCTK_REAL ddetgt1 CCTK_ATTRIBUTE_UNUSED = gtu11*PDstandardNth1gt11 + 
      gtu22*PDstandardNth1gt22 + 2*(gtu12*PDstandardNth1gt12 + 
      gtu13*PDstandardNth1gt13 + gtu23*PDstandardNth1gt23) + 
      gtu33*PDstandardNth1gt33;
    
    CCTK_REAL ddetgt2 CCTK_ATTRIBUTE_UNUSED = gtu11*PDstandardNth2gt11 + 
      gtu22*PDstandardNth2gt22 + 2*(gtu12*PDstandardNth2gt12 + 
      gtu13*PDstandardNth2gt13 + gtu23*PDstandardNth2gt23) + 
      gtu33*PDstandardNth2gt33;
    
    CCTK_REAL ddetgt3 CCTK_ATTRIBUTE_UNUSED = gtu11*PDstandardNth3gt11 + 
      gtu22*PDstandardNth3gt22 + 2*(gtu12*PDstandardNth3gt12 + 
      gtu13*PDstandardNth3gt13 + gtu23*PDstandardNth3gt23) + 
      gtu33*PDstandardNth3gt33;
    
    CCTK_REAL dotbeta1 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL dotbeta2 CCTK_ATTRIBUTE_UNUSED;
    CCTK_REAL dotbeta3 CCTK_ATTRIBUTE_UNUSED;
    
    if (shiftFormulation == 0)
    {
      dotbeta1 = B1L*shiftGammaCoeffValue*pow(alphaL,shiftAlphaPower);
      
      dotbeta2 = B2L*shiftGammaCoeffValue*pow(alphaL,shiftAlphaPower);
      
      dotbeta3 = B3L*shiftGammaCoeffValue*pow(alphaL,shiftAlphaPower);
    }
    else
    {
      dotbeta1 = -(alphaL*(gu11*(PDstandardNth1alpha + alphaL*(2*cdphi1 + 
        0.5*ddetgt1 - gtu11*PDstandardNth1gt11 + gtu12*(-PDstandardNth1gt12 - 
        PDstandardNth2gt11) - gtu22*PDstandardNth2gt12 + 
        gtu13*(-PDstandardNth1gt13 - PDstandardNth3gt11) + 
        gtu23*(-PDstandardNth2gt13 - PDstandardNth3gt12) - 
        gtu33*PDstandardNth3gt13)) + gu12*(PDstandardNth2alpha + 
        alphaL*(2*cdphi2 + 0.5*ddetgt2 - gtu11*PDstandardNth1gt12 + 
        gtu12*(-PDstandardNth1gt22 - PDstandardNth2gt12) - 
        gtu22*PDstandardNth2gt22 + gtu13*(-PDstandardNth1gt23 - 
        PDstandardNth3gt12) + gtu23*(-PDstandardNth2gt23 - PDstandardNth3gt22) 
        - gtu33*PDstandardNth3gt23)) + gu13*(PDstandardNth3alpha + 
        alphaL*(2*cdphi3 + 0.5*ddetgt3 - gtu11*PDstandardNth1gt13 + 
        gtu12*(-PDstandardNth1gt23 - PDstandardNth2gt13) - 
        gtu22*PDstandardNth2gt23 + gtu13*(-PDstandardNth1gt33 - 
        PDstandardNth3gt13) + gtu23*(-PDstandardNth2gt33 - PDstandardNth3gt23) 
        - gtu33*PDstandardNth3gt33))));
      
      dotbeta2 = -(alphaL*(gu12*(PDstandardNth1alpha + alphaL*(2*cdphi1 + 
        0.5*ddetgt1 - gtu11*PDstandardNth1gt11 + gtu12*(-PDstandardNth1gt12 - 
        PDstandardNth2gt11) - gtu22*PDstandardNth2gt12 + 
        gtu13*(-PDstandardNth1gt13 - PDstandardNth3gt11) + 
        gtu23*(-PDstandardNth2gt13 - PDstandardNth3gt12) - 
        gtu33*PDstandardNth3gt13)) + gu22*(PDstandardNth2alpha + 
        alphaL*(2*cdphi2 + 0.5*ddetgt2 - gtu11*PDstandardNth1gt12 + 
        gtu12*(-PDstandardNth1gt22 - PDstandardNth2gt12) - 
        gtu22*PDstandardNth2gt22 + gtu13*(-PDstandardNth1gt23 - 
        PDstandardNth3gt12) + gtu23*(-PDstandardNth2gt23 - PDstandardNth3gt22) 
        - gtu33*PDstandardNth3gt23)) + gu23*(PDstandardNth3alpha + 
        alphaL*(2*cdphi3 + 0.5*ddetgt3 - gtu11*PDstandardNth1gt13 + 
        gtu12*(-PDstandardNth1gt23 - PDstandardNth2gt13) - 
        gtu22*PDstandardNth2gt23 + gtu13*(-PDstandardNth1gt33 - 
        PDstandardNth3gt13) + gtu23*(-PDstandardNth2gt33 - PDstandardNth3gt23) 
        - gtu33*PDstandardNth3gt33))));
      
      dotbeta3 = -(alphaL*(gu13*(PDstandardNth1alpha + alphaL*(2*cdphi1 + 
        0.5*ddetgt1 - gtu11*PDstandardNth1gt11 + gtu12*(-PDstandardNth1gt12 - 
        PDstandardNth2gt11) - gtu22*PDstandardNth2gt12 + 
        gtu13*(-PDstandardNth1gt13 - PDstandardNth3gt11) + 
        gtu23*(-PDstandardNth2gt13 - PDstandardNth3gt12) - 
        gtu33*PDstandardNth3gt13)) + gu23*(PDstandardNth2alpha + 
        alphaL*(2*cdphi2 + 0.5*ddetgt2 - gtu11*PDstandardNth1gt12 + 
        gtu12*(-PDstandardNth1gt22 - PDstandardNth2gt12) - 
        gtu22*PDstandardNth2gt22 + gtu13*(-PDstandardNth1gt23 - 
        PDstandardNth3gt12) + gtu23*(-PDstandardNth2gt23 - PDstandardNth3gt22) 
        - gtu33*PDstandardNth3gt23)) + gu33*(PDstandardNth3alpha + 
        alphaL*(2*cdphi3 + 0.5*ddetgt3 - gtu11*PDstandardNth1gt13 + 
        gtu12*(-PDstandardNth1gt23 - PDstandardNth2gt13) - 
        gtu22*PDstandardNth2gt23 + gtu13*(-PDstandardNth1gt33 - 
        PDstandardNth3gt13) + gtu23*(-PDstandardNth2gt33 - PDstandardNth3gt23) 
        - gtu33*PDstandardNth3gt33))));
    }
    
    CCTK_REAL dtalpL CCTK_ATTRIBUTE_UNUSED = dotalpha + IfThen(advectLapse 
      != 0,beta1L*PDupwindNthAnti1alpha + beta2L*PDupwindNthAnti2alpha + 
      beta3L*PDupwindNthAnti3alpha + PDupwindNthSymm1alpha*fabs(beta1L) + 
      PDupwindNthSymm2alpha*fabs(beta2L) + 
      PDupwindNthSymm3alpha*fabs(beta3L),0);
    
    CCTK_REAL dtbetaxL CCTK_ATTRIBUTE_UNUSED = dotbeta1 + 
      IfThen(advectShift != 0,beta1L*PDupwindNthAnti1beta1 + 
      beta2L*PDupwindNthAnti2beta1 + beta3L*PDupwindNthAnti3beta1 + 
      PDupwindNthSymm1beta1*fabs(beta1L) + PDupwindNthSymm2beta1*fabs(beta2L) 
      + PDupwindNthSymm3beta1*fabs(beta3L),0);
    
    CCTK_REAL dtbetayL CCTK_ATTRIBUTE_UNUSED = dotbeta2 + 
      IfThen(advectShift != 0,beta1L*PDupwindNthAnti1beta2 + 
      beta2L*PDupwindNthAnti2beta2 + beta3L*PDupwindNthAnti3beta2 + 
      PDupwindNthSymm1beta2*fabs(beta1L) + PDupwindNthSymm2beta2*fabs(beta2L) 
      + PDupwindNthSymm3beta2*fabs(beta3L),0);
    
    CCTK_REAL dtbetazL CCTK_ATTRIBUTE_UNUSED = dotbeta3 + 
      IfThen(advectShift != 0,beta1L*PDupwindNthAnti1beta3 + 
      beta2L*PDupwindNthAnti2beta3 + beta3L*PDupwindNthAnti3beta3 + 
      PDupwindNthSymm1beta3*fabs(beta1L) + PDupwindNthSymm2beta3*fabs(beta2L) 
      + PDupwindNthSymm3beta3*fabs(beta3L),0);
    /* Copy local copies back to grid functions */
    dtalp[index] = dtalpL;
    dtbetax[index] = dtbetaxL;
    dtbetay[index] = dtbetayL;
    dtbetaz[index] = dtbetazL;
  }
  CCTK_ENDLOOP3(ML_CCZ4_ADMBaseInterior);
}
extern "C" void ML_CCZ4_ADMBaseInterior(CCTK_ARGUMENTS)
{
  #ifdef DECLARE_CCTK_ARGUMENTS_ML_CCZ4_ADMBaseInterior
  DECLARE_CCTK_ARGUMENTS_CHECKED(ML_CCZ4_ADMBaseInterior);
  #else
  DECLARE_CCTK_ARGUMENTS;
  #endif
  DECLARE_CCTK_PARAMETERS;
  
  if (verbose > 1)
  {
    CCTK_VInfo(CCTK_THORNSTRING,"Entering ML_CCZ4_ADMBaseInterior_Body");
  }
  if (cctk_iteration % ML_CCZ4_ADMBaseInterior_calc_every != ML_CCZ4_ADMBaseInterior_calc_offset)
  {
    return;
  }
  
  const char* const groups[] = {
    "ADMBase::dtlapse",
    "ADMBase::dtshift",
    "grid::coordinates",
    "ML_CCZ4::ML_dtshift",
    "ML_CCZ4::ML_lapse",
    "ML_CCZ4::ML_log_confac",
    "ML_CCZ4::ML_metric",
    "ML_CCZ4::ML_shift",
    "ML_CCZ4::ML_Theta",
    "ML_CCZ4::ML_trace_curv"};
  AssertGroupStorage(cctkGH, "ML_CCZ4_ADMBaseInterior", 10, groups);
  
  EnsureStencilFits(cctkGH, "ML_CCZ4_ADMBaseInterior", 5, 5, 5);
  
  LoopOverInterior(cctkGH, ML_CCZ4_ADMBaseInterior_Body);
  if (verbose > 1)
  {
    CCTK_VInfo(CCTK_THORNSTRING,"Leaving ML_CCZ4_ADMBaseInterior_Body");
  }
}

} // namespace ML_CCZ4
