/*  File produced by Kranc */

#define KRANC_C

#include <algorithm>
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cctk.h"
#include "cctk_Arguments.h"
#include "cctk_Parameters.h"
#include "Kranc.hh"
#include "Differencing.h"

namespace ML_CCZ4 {

extern "C" void ML_CCZ4_InitialADMBase2Interior_SelectBCs(CCTK_ARGUMENTS)
{
  #ifdef DECLARE_CCTK_ARGUMENTS_ML_CCZ4_InitialADMBase2Interior_SelectBCs
  DECLARE_CCTK_ARGUMENTS_CHECKED(ML_CCZ4_InitialADMBase2Interior_SelectBCs);
  #else
  DECLARE_CCTK_ARGUMENTS;
  #endif
  DECLARE_CCTK_PARAMETERS;
  
  if (cctk_iteration % ML_CCZ4_InitialADMBase2Interior_calc_every != ML_CCZ4_InitialADMBase2Interior_calc_offset)
    return;
  CCTK_INT ierr CCTK_ATTRIBUTE_UNUSED = 0;
  ierr = KrancBdy_SelectGroupForBC(cctkGH, CCTK_ALL_FACES, GetBoundaryWidth(cctkGH), -1 /* no table */, "ML_CCZ4::ML_dtshift","flat");
  if (ierr < 0)
    CCTK_WARN(CCTK_WARN_ALERT, "Failed to register flat BC for ML_CCZ4::ML_dtshift.");
  ierr = KrancBdy_SelectGroupForBC(cctkGH, CCTK_ALL_FACES, GetBoundaryWidth(cctkGH), -1 /* no table */, "ML_CCZ4::ML_Gamma","flat");
  if (ierr < 0)
    CCTK_WARN(CCTK_WARN_ALERT, "Failed to register flat BC for ML_CCZ4::ML_Gamma.");
  return;
}

static void ML_CCZ4_InitialADMBase2Interior_Body(const cGH* restrict const cctkGH, const int dir, const int face, const CCTK_REAL normal[3], const CCTK_REAL tangentA[3], const CCTK_REAL tangentB[3], const int imin[3], const int imax[3], const int n_subblock_gfs, CCTK_REAL* restrict const subblock_gfs[])
{
  DECLARE_CCTK_ARGUMENTS;
  DECLARE_CCTK_PARAMETERS;
  
  /* Include user-supplied include files */
  /* Initialise finite differencing variables */
  const ptrdiff_t di CCTK_ATTRIBUTE_UNUSED = 1;
  const ptrdiff_t dj CCTK_ATTRIBUTE_UNUSED = 
    CCTK_GFINDEX3D(cctkGH,0,1,0) - CCTK_GFINDEX3D(cctkGH,0,0,0);
  const ptrdiff_t dk CCTK_ATTRIBUTE_UNUSED = 
    CCTK_GFINDEX3D(cctkGH,0,0,1) - CCTK_GFINDEX3D(cctkGH,0,0,0);
  const ptrdiff_t cdi CCTK_ATTRIBUTE_UNUSED = sizeof(CCTK_REAL) * di;
  const ptrdiff_t cdj CCTK_ATTRIBUTE_UNUSED = sizeof(CCTK_REAL) * dj;
  const ptrdiff_t cdk CCTK_ATTRIBUTE_UNUSED = sizeof(CCTK_REAL) * dk;
  const ptrdiff_t cctkLbnd1 CCTK_ATTRIBUTE_UNUSED = cctk_lbnd[0];
  const ptrdiff_t cctkLbnd2 CCTK_ATTRIBUTE_UNUSED = cctk_lbnd[1];
  const ptrdiff_t cctkLbnd3 CCTK_ATTRIBUTE_UNUSED = cctk_lbnd[2];
  const CCTK_REAL t CCTK_ATTRIBUTE_UNUSED = cctk_time;
  const CCTK_REAL cctkOriginSpace1 CCTK_ATTRIBUTE_UNUSED = 
    CCTK_ORIGIN_SPACE(0);
  const CCTK_REAL cctkOriginSpace2 CCTK_ATTRIBUTE_UNUSED = 
    CCTK_ORIGIN_SPACE(1);
  const CCTK_REAL cctkOriginSpace3 CCTK_ATTRIBUTE_UNUSED = 
    CCTK_ORIGIN_SPACE(2);
  const CCTK_REAL dt CCTK_ATTRIBUTE_UNUSED = CCTK_DELTA_TIME;
  const CCTK_REAL dx CCTK_ATTRIBUTE_UNUSED = CCTK_DELTA_SPACE(0);
  const CCTK_REAL dy CCTK_ATTRIBUTE_UNUSED = CCTK_DELTA_SPACE(1);
  const CCTK_REAL dz CCTK_ATTRIBUTE_UNUSED = CCTK_DELTA_SPACE(2);
  const CCTK_REAL dxi CCTK_ATTRIBUTE_UNUSED = pow(dx,-1);
  const CCTK_REAL dyi CCTK_ATTRIBUTE_UNUSED = pow(dy,-1);
  const CCTK_REAL dzi CCTK_ATTRIBUTE_UNUSED = pow(dz,-1);
  const CCTK_REAL khalf CCTK_ATTRIBUTE_UNUSED = 0.5;
  const CCTK_REAL kthird CCTK_ATTRIBUTE_UNUSED = 
    0.333333333333333333333333333333;
  const CCTK_REAL ktwothird CCTK_ATTRIBUTE_UNUSED = 
    0.666666666666666666666666666667;
  const CCTK_REAL kfourthird CCTK_ATTRIBUTE_UNUSED = 
    1.33333333333333333333333333333;
  const CCTK_REAL hdxi CCTK_ATTRIBUTE_UNUSED = 0.5*dxi;
  const CCTK_REAL hdyi CCTK_ATTRIBUTE_UNUSED = 0.5*dyi;
  const CCTK_REAL hdzi CCTK_ATTRIBUTE_UNUSED = 0.5*dzi;
  /* Initialize predefined quantities */
  const CCTK_REAL p1o1024dx CCTK_ATTRIBUTE_UNUSED = 0.0009765625*pow(dx,-1);
  const CCTK_REAL p1o1024dy CCTK_ATTRIBUTE_UNUSED = 0.0009765625*pow(dy,-1);
  const CCTK_REAL p1o1024dz CCTK_ATTRIBUTE_UNUSED = 0.0009765625*pow(dz,-1);
  const CCTK_REAL p1o1680dx CCTK_ATTRIBUTE_UNUSED = 0.000595238095238095238095238095238*pow(dx,-1);
  const CCTK_REAL p1o1680dy CCTK_ATTRIBUTE_UNUSED = 0.000595238095238095238095238095238*pow(dy,-1);
  const CCTK_REAL p1o1680dz CCTK_ATTRIBUTE_UNUSED = 0.000595238095238095238095238095238*pow(dz,-1);
  const CCTK_REAL p1o5040dx2 CCTK_ATTRIBUTE_UNUSED = 0.000198412698412698412698412698413*pow(dx,-2);
  const CCTK_REAL p1o5040dy2 CCTK_ATTRIBUTE_UNUSED = 0.000198412698412698412698412698413*pow(dy,-2);
  const CCTK_REAL p1o5040dz2 CCTK_ATTRIBUTE_UNUSED = 0.000198412698412698412698412698413*pow(dz,-2);
  const CCTK_REAL p1o560dx CCTK_ATTRIBUTE_UNUSED = 0.00178571428571428571428571428571*pow(dx,-1);
  const CCTK_REAL p1o560dy CCTK_ATTRIBUTE_UNUSED = 0.00178571428571428571428571428571*pow(dy,-1);
  const CCTK_REAL p1o560dz CCTK_ATTRIBUTE_UNUSED = 0.00178571428571428571428571428571*pow(dz,-1);
  const CCTK_REAL p1o60dx CCTK_ATTRIBUTE_UNUSED = 0.0166666666666666666666666666667*pow(dx,-1);
  const CCTK_REAL p1o60dy CCTK_ATTRIBUTE_UNUSED = 0.0166666666666666666666666666667*pow(dy,-1);
  const CCTK_REAL p1o60dz CCTK_ATTRIBUTE_UNUSED = 0.0166666666666666666666666666667*pow(dz,-1);
  const CCTK_REAL p1o705600dxdy CCTK_ATTRIBUTE_UNUSED = 1.41723356009070294784580498866e-6*pow(dx,-1)*pow(dy,-1);
  const CCTK_REAL p1o705600dxdz CCTK_ATTRIBUTE_UNUSED = 1.41723356009070294784580498866e-6*pow(dx,-1)*pow(dz,-1);
  const CCTK_REAL p1o705600dydz CCTK_ATTRIBUTE_UNUSED = 1.41723356009070294784580498866e-6*pow(dy,-1)*pow(dz,-1);
  const CCTK_REAL p1o840dx CCTK_ATTRIBUTE_UNUSED = 0.00119047619047619047619047619048*pow(dx,-1);
  const CCTK_REAL p1o840dy CCTK_ATTRIBUTE_UNUSED = 0.00119047619047619047619047619048*pow(dy,-1);
  const CCTK_REAL p1o840dz CCTK_ATTRIBUTE_UNUSED = 0.00119047619047619047619047619048*pow(dz,-1);
  const CCTK_REAL pm1o840dx CCTK_ATTRIBUTE_UNUSED = -0.00119047619047619047619047619048*pow(dx,-1);
  const CCTK_REAL pm1o840dy CCTK_ATTRIBUTE_UNUSED = -0.00119047619047619047619047619048*pow(dy,-1);
  const CCTK_REAL pm1o840dz CCTK_ATTRIBUTE_UNUSED = -0.00119047619047619047619047619048*pow(dz,-1);
  /* Assign local copies of arrays functions */
  
  
  /* Calculate temporaries and arrays functions */
  /* Copy local copies back to grid functions */
  /* Loop over the grid points */
  const int imin0=imin[0];
  const int imin1=imin[1];
  const int imin2=imin[2];
  const int imax0=imax[0];
  const int imax1=imax[1];
  const int imax2=imax[2];
  #pragma omp parallel
  CCTK_LOOP3(ML_CCZ4_InitialADMBase2Interior,
    i,j,k, imin0,imin1,imin2, imax0,imax1,imax2,
    cctk_ash[0],cctk_ash[1],cctk_ash[2])
  {
    const ptrdiff_t index CCTK_ATTRIBUTE_UNUSED = di*i + dj*j + dk*k;
    /* Assign local copies of grid functions */
    
    CCTK_REAL alpL CCTK_ATTRIBUTE_UNUSED = alp[index];
    CCTK_REAL betaxL CCTK_ATTRIBUTE_UNUSED = betax[index];
    CCTK_REAL betayL CCTK_ATTRIBUTE_UNUSED = betay[index];
    CCTK_REAL betazL CCTK_ATTRIBUTE_UNUSED = betaz[index];
    CCTK_REAL dtbetaxL CCTK_ATTRIBUTE_UNUSED = dtbetax[index];
    CCTK_REAL dtbetayL CCTK_ATTRIBUTE_UNUSED = dtbetay[index];
    CCTK_REAL dtbetazL CCTK_ATTRIBUTE_UNUSED = dtbetaz[index];
    CCTK_REAL gt11L CCTK_ATTRIBUTE_UNUSED = gt11[index];
    CCTK_REAL gt12L CCTK_ATTRIBUTE_UNUSED = gt12[index];
    CCTK_REAL gt13L CCTK_ATTRIBUTE_UNUSED = gt13[index];
    CCTK_REAL gt22L CCTK_ATTRIBUTE_UNUSED = gt22[index];
    CCTK_REAL gt23L CCTK_ATTRIBUTE_UNUSED = gt23[index];
    CCTK_REAL gt33L CCTK_ATTRIBUTE_UNUSED = gt33[index];
    CCTK_REAL gxxL CCTK_ATTRIBUTE_UNUSED = gxx[index];
    CCTK_REAL gxyL CCTK_ATTRIBUTE_UNUSED = gxy[index];
    CCTK_REAL gxzL CCTK_ATTRIBUTE_UNUSED = gxz[index];
    CCTK_REAL gyyL CCTK_ATTRIBUTE_UNUSED = gyy[index];
    CCTK_REAL gyzL CCTK_ATTRIBUTE_UNUSED = gyz[index];
    CCTK_REAL gzzL CCTK_ATTRIBUTE_UNUSED = gzz[index];
    CCTK_REAL phiL CCTK_ATTRIBUTE_UNUSED = phi[index];
    CCTK_REAL rL CCTK_ATTRIBUTE_UNUSED = r[index];
    
    /* Include user supplied include files */
    /* Precompute derivatives */
    const CCTK_REAL PDupwindNthSymm1betax CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm1(&betax[index]);
    const CCTK_REAL PDupwindNthSymm2betax CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm2(&betax[index]);
    const CCTK_REAL PDupwindNthSymm3betax CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm3(&betax[index]);
    const CCTK_REAL PDupwindNthAnti1betax CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti1(&betax[index]);
    const CCTK_REAL PDupwindNthAnti2betax CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti2(&betax[index]);
    const CCTK_REAL PDupwindNthAnti3betax CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti3(&betax[index]);
    const CCTK_REAL PDupwindNthSymm1betay CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm1(&betay[index]);
    const CCTK_REAL PDupwindNthSymm2betay CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm2(&betay[index]);
    const CCTK_REAL PDupwindNthSymm3betay CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm3(&betay[index]);
    const CCTK_REAL PDupwindNthAnti1betay CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti1(&betay[index]);
    const CCTK_REAL PDupwindNthAnti2betay CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti2(&betay[index]);
    const CCTK_REAL PDupwindNthAnti3betay CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti3(&betay[index]);
    const CCTK_REAL PDupwindNthSymm1betaz CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm1(&betaz[index]);
    const CCTK_REAL PDupwindNthSymm2betaz CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm2(&betaz[index]);
    const CCTK_REAL PDupwindNthSymm3betaz CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm3(&betaz[index]);
    const CCTK_REAL PDupwindNthAnti1betaz CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti1(&betaz[index]);
    const CCTK_REAL PDupwindNthAnti2betaz CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti2(&betaz[index]);
    const CCTK_REAL PDupwindNthAnti3betaz CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti3(&betaz[index]);
    const CCTK_REAL PDstandardNth1gt11 CCTK_ATTRIBUTE_UNUSED = PDstandardNth1(&gt11[index]);
    const CCTK_REAL PDstandardNth2gt11 CCTK_ATTRIBUTE_UNUSED = PDstandardNth2(&gt11[index]);
    const CCTK_REAL PDstandardNth3gt11 CCTK_ATTRIBUTE_UNUSED = PDstandardNth3(&gt11[index]);
    const CCTK_REAL PDstandardNth1gt12 CCTK_ATTRIBUTE_UNUSED = PDstandardNth1(&gt12[index]);
    const CCTK_REAL PDstandardNth2gt12 CCTK_ATTRIBUTE_UNUSED = PDstandardNth2(&gt12[index]);
    const CCTK_REAL PDstandardNth3gt12 CCTK_ATTRIBUTE_UNUSED = PDstandardNth3(&gt12[index]);
    const CCTK_REAL PDstandardNth1gt13 CCTK_ATTRIBUTE_UNUSED = PDstandardNth1(&gt13[index]);
    const CCTK_REAL PDstandardNth2gt13 CCTK_ATTRIBUTE_UNUSED = PDstandardNth2(&gt13[index]);
    const CCTK_REAL PDstandardNth3gt13 CCTK_ATTRIBUTE_UNUSED = PDstandardNth3(&gt13[index]);
    const CCTK_REAL PDstandardNth1gt22 CCTK_ATTRIBUTE_UNUSED = PDstandardNth1(&gt22[index]);
    const CCTK_REAL PDstandardNth2gt22 CCTK_ATTRIBUTE_UNUSED = PDstandardNth2(&gt22[index]);
    const CCTK_REAL PDstandardNth3gt22 CCTK_ATTRIBUTE_UNUSED = PDstandardNth3(&gt22[index]);
    const CCTK_REAL PDstandardNth1gt23 CCTK_ATTRIBUTE_UNUSED = PDstandardNth1(&gt23[index]);
    const CCTK_REAL PDstandardNth2gt23 CCTK_ATTRIBUTE_UNUSED = PDstandardNth2(&gt23[index]);
    const CCTK_REAL PDstandardNth3gt23 CCTK_ATTRIBUTE_UNUSED = PDstandardNth3(&gt23[index]);
    const CCTK_REAL PDstandardNth1gt33 CCTK_ATTRIBUTE_UNUSED = PDstandardNth1(&gt33[index]);
    const CCTK_REAL PDstandardNth2gt33 CCTK_ATTRIBUTE_UNUSED = PDstandardNth2(&gt33[index]);
    const CCTK_REAL PDstandardNth3gt33 CCTK_ATTRIBUTE_UNUSED = PDstandardNth3(&gt33[index]);
    /* Calculate temporaries and grid functions */
    CCTK_REAL g11 CCTK_ATTRIBUTE_UNUSED = gxxL;
    
    CCTK_REAL g12 CCTK_ATTRIBUTE_UNUSED = gxyL;
    
    CCTK_REAL g13 CCTK_ATTRIBUTE_UNUSED = gxzL;
    
    CCTK_REAL g22 CCTK_ATTRIBUTE_UNUSED = gyyL;
    
    CCTK_REAL g23 CCTK_ATTRIBUTE_UNUSED = gyzL;
    
    CCTK_REAL g33 CCTK_ATTRIBUTE_UNUSED = gzzL;
    
    CCTK_REAL detg CCTK_ATTRIBUTE_UNUSED = 2*g12*g13*g23 - g33*pow(g12,2) 
      + g22*(g11*g33 - pow(g13,2)) - g11*pow(g23,2);
    
    CCTK_REAL gu11 CCTK_ATTRIBUTE_UNUSED = pow(detg,-1)*(g22*g33 - 
      pow(g23,2));
    
    CCTK_REAL gu12 CCTK_ATTRIBUTE_UNUSED = (g13*g23 - 
      g12*g33)*pow(detg,-1);
    
    CCTK_REAL gu13 CCTK_ATTRIBUTE_UNUSED = (-(g13*g22) + 
      g12*g23)*pow(detg,-1);
    
    CCTK_REAL gu22 CCTK_ATTRIBUTE_UNUSED = pow(detg,-1)*(g11*g33 - 
      pow(g13,2));
    
    CCTK_REAL gu23 CCTK_ATTRIBUTE_UNUSED = (g12*g13 - 
      g11*g23)*pow(detg,-1);
    
    CCTK_REAL gu33 CCTK_ATTRIBUTE_UNUSED = pow(detg,-1)*(g11*g22 - 
      pow(g12,2));
    
    CCTK_REAL em4phi CCTK_ATTRIBUTE_UNUSED = pow(phiL,2);
    
    CCTK_REAL gtu11 CCTK_ATTRIBUTE_UNUSED = gu11*pow(em4phi,-1);
    
    CCTK_REAL gtu12 CCTK_ATTRIBUTE_UNUSED = gu12*pow(em4phi,-1);
    
    CCTK_REAL gtu13 CCTK_ATTRIBUTE_UNUSED = gu13*pow(em4phi,-1);
    
    CCTK_REAL gtu22 CCTK_ATTRIBUTE_UNUSED = gu22*pow(em4phi,-1);
    
    CCTK_REAL gtu23 CCTK_ATTRIBUTE_UNUSED = gu23*pow(em4phi,-1);
    
    CCTK_REAL gtu33 CCTK_ATTRIBUTE_UNUSED = gu33*pow(em4phi,-1);
    
    CCTK_REAL Gt111 CCTK_ATTRIBUTE_UNUSED = 0.5*(gtu11*PDstandardNth1gt11 
      + 2*(gtu12*PDstandardNth1gt12 + gtu13*PDstandardNth1gt13) - 
      gtu12*PDstandardNth2gt11 - gtu13*PDstandardNth3gt11);
    
    CCTK_REAL Gt211 CCTK_ATTRIBUTE_UNUSED = 0.5*(gtu12*PDstandardNth1gt11 
      + 2*(gtu22*PDstandardNth1gt12 + gtu23*PDstandardNth1gt13) - 
      gtu22*PDstandardNth2gt11 - gtu23*PDstandardNth3gt11);
    
    CCTK_REAL Gt311 CCTK_ATTRIBUTE_UNUSED = 0.5*(gtu13*PDstandardNth1gt11 
      + 2*(gtu23*PDstandardNth1gt12 + gtu33*PDstandardNth1gt13) - 
      gtu23*PDstandardNth2gt11 - gtu33*PDstandardNth3gt11);
    
    CCTK_REAL Gt112 CCTK_ATTRIBUTE_UNUSED = 0.5*(gtu12*PDstandardNth1gt22 
      + gtu11*PDstandardNth2gt11 + gtu13*(PDstandardNth1gt23 + 
      PDstandardNth2gt13 - PDstandardNth3gt12));
    
    CCTK_REAL Gt212 CCTK_ATTRIBUTE_UNUSED = 0.5*(gtu22*PDstandardNth1gt22 
      + gtu12*PDstandardNth2gt11 + gtu23*(PDstandardNth1gt23 + 
      PDstandardNth2gt13 - PDstandardNth3gt12));
    
    CCTK_REAL Gt312 CCTK_ATTRIBUTE_UNUSED = 0.5*(gtu23*PDstandardNth1gt22 
      + gtu13*PDstandardNth2gt11 + gtu33*(PDstandardNth1gt23 + 
      PDstandardNth2gt13 - PDstandardNth3gt12));
    
    CCTK_REAL Gt113 CCTK_ATTRIBUTE_UNUSED = 0.5*(gtu13*PDstandardNth1gt33 
      + gtu11*PDstandardNth3gt11 + gtu12*(PDstandardNth1gt23 - 
      PDstandardNth2gt13 + PDstandardNth3gt12));
    
    CCTK_REAL Gt213 CCTK_ATTRIBUTE_UNUSED = 0.5*(gtu23*PDstandardNth1gt33 
      + gtu12*PDstandardNth3gt11 + gtu22*(PDstandardNth1gt23 - 
      PDstandardNth2gt13 + PDstandardNth3gt12));
    
    CCTK_REAL Gt313 CCTK_ATTRIBUTE_UNUSED = 0.5*(gtu33*PDstandardNth1gt33 
      + gtu13*PDstandardNth3gt11 + gtu23*(PDstandardNth1gt23 - 
      PDstandardNth2gt13 + PDstandardNth3gt12));
    
    CCTK_REAL Gt122 CCTK_ATTRIBUTE_UNUSED = 
      0.5*(gtu11*(-PDstandardNth1gt22 + 2*PDstandardNth2gt12) + 
      gtu12*PDstandardNth2gt22 + gtu13*(2*PDstandardNth2gt23 - 
      PDstandardNth3gt22));
    
    CCTK_REAL Gt222 CCTK_ATTRIBUTE_UNUSED = 
      0.5*(gtu12*(-PDstandardNth1gt22 + 2*PDstandardNth2gt12) + 
      gtu22*PDstandardNth2gt22 + gtu23*(2*PDstandardNth2gt23 - 
      PDstandardNth3gt22));
    
    CCTK_REAL Gt322 CCTK_ATTRIBUTE_UNUSED = 
      0.5*(gtu13*(-PDstandardNth1gt22 + 2*PDstandardNth2gt12) + 
      gtu23*PDstandardNth2gt22 + gtu33*(2*PDstandardNth2gt23 - 
      PDstandardNth3gt22));
    
    CCTK_REAL Gt123 CCTK_ATTRIBUTE_UNUSED = 0.5*(gtu13*PDstandardNth2gt33 
      + gtu11*(-PDstandardNth1gt23 + PDstandardNth2gt13 + PDstandardNth3gt12) 
      + gtu12*PDstandardNth3gt22);
    
    CCTK_REAL Gt223 CCTK_ATTRIBUTE_UNUSED = 0.5*(gtu23*PDstandardNth2gt33 
      + gtu12*(-PDstandardNth1gt23 + PDstandardNth2gt13 + PDstandardNth3gt12) 
      + gtu22*PDstandardNth3gt22);
    
    CCTK_REAL Gt323 CCTK_ATTRIBUTE_UNUSED = 0.5*(gtu33*PDstandardNth2gt33 
      + gtu13*(-PDstandardNth1gt23 + PDstandardNth2gt13 + PDstandardNth3gt12) 
      + gtu23*PDstandardNth3gt22);
    
    CCTK_REAL Gt133 CCTK_ATTRIBUTE_UNUSED = 
      0.5*(gtu11*(-PDstandardNth1gt33 + 2*PDstandardNth3gt13) + 
      gtu12*(-PDstandardNth2gt33 + 2*PDstandardNth3gt23) + 
      gtu13*PDstandardNth3gt33);
    
    CCTK_REAL Gt233 CCTK_ATTRIBUTE_UNUSED = 
      0.5*(gtu12*(-PDstandardNth1gt33 + 2*PDstandardNth3gt13) + 
      gtu22*(-PDstandardNth2gt33 + 2*PDstandardNth3gt23) + 
      gtu23*PDstandardNth3gt33);
    
    CCTK_REAL Gt333 CCTK_ATTRIBUTE_UNUSED = 
      0.5*(gtu13*(-PDstandardNth1gt33 + 2*PDstandardNth3gt13) + 
      gtu23*(-PDstandardNth2gt33 + 2*PDstandardNth3gt23) + 
      gtu33*PDstandardNth3gt33);
    
    CCTK_REAL Xt1L CCTK_ATTRIBUTE_UNUSED = Gt111*gtu11 + Gt122*gtu22 + 
      2*(Gt112*gtu12 + Gt113*gtu13 + Gt123*gtu23) + Gt133*gtu33;
    
    CCTK_REAL Xt2L CCTK_ATTRIBUTE_UNUSED = Gt211*gtu11 + Gt222*gtu22 + 
      2*(Gt212*gtu12 + Gt213*gtu13 + Gt223*gtu23) + Gt233*gtu33;
    
    CCTK_REAL Xt3L CCTK_ATTRIBUTE_UNUSED = Gt311*gtu11 + Gt322*gtu22 + 
      2*(Gt312*gtu12 + Gt313*gtu13 + Gt323*gtu23) + Gt333*gtu33;
    
    CCTK_REAL shiftGammaCoeffValue CCTK_ATTRIBUTE_UNUSED = 
      IfThen(useSpatialShiftGammaCoeff != 0,shiftGammaCoeff*fmin(1,exp(1 - 
      rL*pow(spatialShiftGammaCoeffRadius,-1))),shiftGammaCoeff);
    
    CCTK_REAL B1L CCTK_ATTRIBUTE_UNUSED = (dtbetaxL - IfThen(advectShift 
      != 0,betaxL*PDupwindNthAnti1betax + betayL*PDupwindNthAnti2betax + 
      betazL*PDupwindNthAnti3betax + PDupwindNthSymm1betax*fabs(betaxL) + 
      PDupwindNthSymm2betax*fabs(betayL) + 
      PDupwindNthSymm3betax*fabs(betazL),0))*pow(alpL,-shiftAlphaPower)*pow(shiftGammaCoeffValue,-1);
    
    CCTK_REAL B2L CCTK_ATTRIBUTE_UNUSED = (dtbetayL - IfThen(advectShift 
      != 0,betaxL*PDupwindNthAnti1betay + betayL*PDupwindNthAnti2betay + 
      betazL*PDupwindNthAnti3betay + PDupwindNthSymm1betay*fabs(betaxL) + 
      PDupwindNthSymm2betay*fabs(betayL) + 
      PDupwindNthSymm3betay*fabs(betazL),0))*pow(alpL,-shiftAlphaPower)*pow(shiftGammaCoeffValue,-1);
    
    CCTK_REAL B3L CCTK_ATTRIBUTE_UNUSED = (dtbetazL - IfThen(advectShift 
      != 0,betaxL*PDupwindNthAnti1betaz + betayL*PDupwindNthAnti2betaz + 
      betazL*PDupwindNthAnti3betaz + PDupwindNthSymm1betaz*fabs(betaxL) + 
      PDupwindNthSymm2betaz*fabs(betayL) + 
      PDupwindNthSymm3betaz*fabs(betazL),0))*pow(alpL,-shiftAlphaPower)*pow(shiftGammaCoeffValue,-1);
    /* Copy local copies back to grid functions */
    B1[index] = B1L;
    B2[index] = B2L;
    B3[index] = B3L;
    Xt1[index] = Xt1L;
    Xt2[index] = Xt2L;
    Xt3[index] = Xt3L;
  }
  CCTK_ENDLOOP3(ML_CCZ4_InitialADMBase2Interior);
}
extern "C" void ML_CCZ4_InitialADMBase2Interior(CCTK_ARGUMENTS)
{
  #ifdef DECLARE_CCTK_ARGUMENTS_ML_CCZ4_InitialADMBase2Interior
  DECLARE_CCTK_ARGUMENTS_CHECKED(ML_CCZ4_InitialADMBase2Interior);
  #else
  DECLARE_CCTK_ARGUMENTS;
  #endif
  DECLARE_CCTK_PARAMETERS;
  
  if (verbose > 1)
  {
    CCTK_VInfo(CCTK_THORNSTRING,"Entering ML_CCZ4_InitialADMBase2Interior_Body");
  }
  if (cctk_iteration % ML_CCZ4_InitialADMBase2Interior_calc_every != ML_CCZ4_InitialADMBase2Interior_calc_offset)
  {
    return;
  }
  
  const char* const groups[] = {
    "ADMBase::dtshift",
    "ADMBase::lapse",
    "ADMBase::metric",
    "ADMBase::shift",
    "grid::coordinates",
    "ML_CCZ4::ML_dtshift",
    "ML_CCZ4::ML_Gamma",
    "ML_CCZ4::ML_log_confac",
    "ML_CCZ4::ML_metric"};
  AssertGroupStorage(cctkGH, "ML_CCZ4_InitialADMBase2Interior", 9, groups);
  
  EnsureStencilFits(cctkGH, "ML_CCZ4_InitialADMBase2Interior", 5, 5, 5);
  
  LoopOverInterior(cctkGH, ML_CCZ4_InitialADMBase2Interior_Body);
  if (verbose > 1)
  {
    CCTK_VInfo(CCTK_THORNSTRING,"Leaving ML_CCZ4_InitialADMBase2Interior_Body");
  }
}

} // namespace ML_CCZ4
