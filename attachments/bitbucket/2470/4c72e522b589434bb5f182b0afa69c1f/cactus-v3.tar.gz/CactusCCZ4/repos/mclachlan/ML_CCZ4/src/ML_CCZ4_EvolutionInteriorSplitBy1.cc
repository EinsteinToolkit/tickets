/*  File produced by Kranc */

#define KRANC_C

#include <algorithm>
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cctk.h"
#include "cctk_Arguments.h"
#include "cctk_Parameters.h"
#include "Kranc.hh"
#include "Differencing.h"

namespace ML_CCZ4 {

extern "C" void ML_CCZ4_EvolutionInteriorSplitBy1_SelectBCs(CCTK_ARGUMENTS)
{
  #ifdef DECLARE_CCTK_ARGUMENTS_ML_CCZ4_EvolutionInteriorSplitBy1_SelectBCs
  DECLARE_CCTK_ARGUMENTS_CHECKED(ML_CCZ4_EvolutionInteriorSplitBy1_SelectBCs);
  #else
  DECLARE_CCTK_ARGUMENTS
  #endif
  DECLARE_CCTK_PARAMETERS
  
  if (cctk_iteration % ML_CCZ4_EvolutionInteriorSplitBy1_calc_every != ML_CCZ4_EvolutionInteriorSplitBy1_calc_offset)
    return;
  CCTK_INT ierr CCTK_ATTRIBUTE_UNUSED = 0;
  ierr = KrancBdy_SelectGroupForBC(cctkGH, CCTK_ALL_FACES, GetBoundaryWidth(cctkGH), -1 /* no table */, "ML_CCZ4::ML_lapserhs","flat");
  if (ierr < 0)
    CCTK_WARN(CCTK_WARN_ALERT, "Failed to register flat BC for ML_CCZ4::ML_lapserhs.");
  ierr = KrancBdy_SelectGroupForBC(cctkGH, CCTK_ALL_FACES, GetBoundaryWidth(cctkGH), -1 /* no table */, "ML_CCZ4::ML_log_confacrhs","flat");
  if (ierr < 0)
    CCTK_WARN(CCTK_WARN_ALERT, "Failed to register flat BC for ML_CCZ4::ML_log_confacrhs.");
  ierr = KrancBdy_SelectGroupForBC(cctkGH, CCTK_ALL_FACES, GetBoundaryWidth(cctkGH), -1 /* no table */, "ML_CCZ4::ML_metricrhs","flat");
  if (ierr < 0)
    CCTK_WARN(CCTK_WARN_ALERT, "Failed to register flat BC for ML_CCZ4::ML_metricrhs.");
  return;
}

static void ML_CCZ4_EvolutionInteriorSplitBy1_Body(const cGH* restrict const cctkGH, const int dir, const int face, const CCTK_REAL normal[3], const CCTK_REAL tangentA[3], const CCTK_REAL tangentB[3], const int imin[3], const int imax[3], const int n_subblock_gfs, CCTK_REAL* restrict const subblock_gfs[])
{
  DECLARE_CCTK_ARGUMENTS
  DECLARE_CCTK_PARAMETERS
  
  /* Include user-supplied include files */
  /* Initialise finite differencing variables */
  const ptrdiff_t di CCTK_ATTRIBUTE_UNUSED = 1;
  const ptrdiff_t dj CCTK_ATTRIBUTE_UNUSED = 
    CCTK_GFINDEX3D(cctkGH,0,1,0) - CCTK_GFINDEX3D(cctkGH,0,0,0);
  const ptrdiff_t dk CCTK_ATTRIBUTE_UNUSED = 
    CCTK_GFINDEX3D(cctkGH,0,0,1) - CCTK_GFINDEX3D(cctkGH,0,0,0);
  const ptrdiff_t cdi CCTK_ATTRIBUTE_UNUSED = sizeof(CCTK_REAL) * di;
  const ptrdiff_t cdj CCTK_ATTRIBUTE_UNUSED = sizeof(CCTK_REAL) * dj;
  const ptrdiff_t cdk CCTK_ATTRIBUTE_UNUSED = sizeof(CCTK_REAL) * dk;
  const ptrdiff_t cctkLbnd1 CCTK_ATTRIBUTE_UNUSED = cctk_lbnd[0];
  const ptrdiff_t cctkLbnd2 CCTK_ATTRIBUTE_UNUSED = cctk_lbnd[1];
  const ptrdiff_t cctkLbnd3 CCTK_ATTRIBUTE_UNUSED = cctk_lbnd[2];
  const CCTK_REAL t CCTK_ATTRIBUTE_UNUSED = cctk_time;
  const CCTK_REAL cctkOriginSpace1 CCTK_ATTRIBUTE_UNUSED = 
    CCTK_ORIGIN_SPACE(0);
  const CCTK_REAL cctkOriginSpace2 CCTK_ATTRIBUTE_UNUSED = 
    CCTK_ORIGIN_SPACE(1);
  const CCTK_REAL cctkOriginSpace3 CCTK_ATTRIBUTE_UNUSED = 
    CCTK_ORIGIN_SPACE(2);
  const CCTK_REAL dt CCTK_ATTRIBUTE_UNUSED = CCTK_DELTA_TIME;
  const CCTK_REAL dx CCTK_ATTRIBUTE_UNUSED = CCTK_DELTA_SPACE(0);
  const CCTK_REAL dy CCTK_ATTRIBUTE_UNUSED = CCTK_DELTA_SPACE(1);
  const CCTK_REAL dz CCTK_ATTRIBUTE_UNUSED = CCTK_DELTA_SPACE(2);
  const CCTK_REAL dxi CCTK_ATTRIBUTE_UNUSED = pow(dx,-1);
  const CCTK_REAL dyi CCTK_ATTRIBUTE_UNUSED = pow(dy,-1);
  const CCTK_REAL dzi CCTK_ATTRIBUTE_UNUSED = pow(dz,-1);
  const CCTK_REAL khalf CCTK_ATTRIBUTE_UNUSED = 0.5;
  const CCTK_REAL kthird CCTK_ATTRIBUTE_UNUSED = 
    0.333333333333333333333333333333;
  const CCTK_REAL ktwothird CCTK_ATTRIBUTE_UNUSED = 
    0.666666666666666666666666666667;
  const CCTK_REAL kfourthird CCTK_ATTRIBUTE_UNUSED = 
    1.33333333333333333333333333333;
  const CCTK_REAL hdxi CCTK_ATTRIBUTE_UNUSED = 0.5*dxi;
  const CCTK_REAL hdyi CCTK_ATTRIBUTE_UNUSED = 0.5*dyi;
  const CCTK_REAL hdzi CCTK_ATTRIBUTE_UNUSED = 0.5*dzi;
  /* Initialize predefined quantities */
  const CCTK_REAL p1o1024dx CCTK_ATTRIBUTE_UNUSED = 0.0009765625*pow(dx,-1);
  const CCTK_REAL p1o1024dy CCTK_ATTRIBUTE_UNUSED = 0.0009765625*pow(dy,-1);
  const CCTK_REAL p1o1024dz CCTK_ATTRIBUTE_UNUSED = 0.0009765625*pow(dz,-1);
  const CCTK_REAL p1o1680dx CCTK_ATTRIBUTE_UNUSED = 0.000595238095238095238095238095238*pow(dx,-1);
  const CCTK_REAL p1o1680dy CCTK_ATTRIBUTE_UNUSED = 0.000595238095238095238095238095238*pow(dy,-1);
  const CCTK_REAL p1o1680dz CCTK_ATTRIBUTE_UNUSED = 0.000595238095238095238095238095238*pow(dz,-1);
  const CCTK_REAL p1o5040dx2 CCTK_ATTRIBUTE_UNUSED = 0.000198412698412698412698412698413*pow(dx,-2);
  const CCTK_REAL p1o5040dy2 CCTK_ATTRIBUTE_UNUSED = 0.000198412698412698412698412698413*pow(dy,-2);
  const CCTK_REAL p1o5040dz2 CCTK_ATTRIBUTE_UNUSED = 0.000198412698412698412698412698413*pow(dz,-2);
  const CCTK_REAL p1o560dx CCTK_ATTRIBUTE_UNUSED = 0.00178571428571428571428571428571*pow(dx,-1);
  const CCTK_REAL p1o560dy CCTK_ATTRIBUTE_UNUSED = 0.00178571428571428571428571428571*pow(dy,-1);
  const CCTK_REAL p1o560dz CCTK_ATTRIBUTE_UNUSED = 0.00178571428571428571428571428571*pow(dz,-1);
  const CCTK_REAL p1o60dx CCTK_ATTRIBUTE_UNUSED = 0.0166666666666666666666666666667*pow(dx,-1);
  const CCTK_REAL p1o60dy CCTK_ATTRIBUTE_UNUSED = 0.0166666666666666666666666666667*pow(dy,-1);
  const CCTK_REAL p1o60dz CCTK_ATTRIBUTE_UNUSED = 0.0166666666666666666666666666667*pow(dz,-1);
  const CCTK_REAL p1o705600dxdy CCTK_ATTRIBUTE_UNUSED = 1.41723356009070294784580498866e-6*pow(dx,-1)*pow(dy,-1);
  const CCTK_REAL p1o705600dxdz CCTK_ATTRIBUTE_UNUSED = 1.41723356009070294784580498866e-6*pow(dx,-1)*pow(dz,-1);
  const CCTK_REAL p1o705600dydz CCTK_ATTRIBUTE_UNUSED = 1.41723356009070294784580498866e-6*pow(dy,-1)*pow(dz,-1);
  const CCTK_REAL p1o840dx CCTK_ATTRIBUTE_UNUSED = 0.00119047619047619047619047619048*pow(dx,-1);
  const CCTK_REAL p1o840dy CCTK_ATTRIBUTE_UNUSED = 0.00119047619047619047619047619048*pow(dy,-1);
  const CCTK_REAL p1o840dz CCTK_ATTRIBUTE_UNUSED = 0.00119047619047619047619047619048*pow(dz,-1);
  const CCTK_REAL pm1o840dx CCTK_ATTRIBUTE_UNUSED = -0.00119047619047619047619047619048*pow(dx,-1);
  const CCTK_REAL pm1o840dy CCTK_ATTRIBUTE_UNUSED = -0.00119047619047619047619047619048*pow(dy,-1);
  const CCTK_REAL pm1o840dz CCTK_ATTRIBUTE_UNUSED = -0.00119047619047619047619047619048*pow(dz,-1);
  /* Assign local copies of arrays functions */
  
  
  /* Calculate temporaries and arrays functions */
  /* Copy local copies back to grid functions */
  /* Loop over the grid points */
  const int imin0=imin[0];
  const int imin1=imin[1];
  const int imin2=imin[2];
  const int imax0=imax[0];
  const int imax1=imax[1];
  const int imax2=imax[2];
  #pragma omp parallel
  CCTK_LOOP3(ML_CCZ4_EvolutionInteriorSplitBy1,
    i,j,k, imin0,imin1,imin2, imax0,imax1,imax2,
    cctk_ash[0],cctk_ash[1],cctk_ash[2])
  {
    const ptrdiff_t index CCTK_ATTRIBUTE_UNUSED = di*i + dj*j + dk*k;
    /* Assign local copies of grid functions */
    
    CCTK_REAL alphaL CCTK_ATTRIBUTE_UNUSED = alpha[index];
    CCTK_REAL At11L CCTK_ATTRIBUTE_UNUSED = At11[index];
    CCTK_REAL At12L CCTK_ATTRIBUTE_UNUSED = At12[index];
    CCTK_REAL At13L CCTK_ATTRIBUTE_UNUSED = At13[index];
    CCTK_REAL At22L CCTK_ATTRIBUTE_UNUSED = At22[index];
    CCTK_REAL At23L CCTK_ATTRIBUTE_UNUSED = At23[index];
    CCTK_REAL At33L CCTK_ATTRIBUTE_UNUSED = At33[index];
    CCTK_REAL beta1L CCTK_ATTRIBUTE_UNUSED = beta1[index];
    CCTK_REAL beta2L CCTK_ATTRIBUTE_UNUSED = beta2[index];
    CCTK_REAL beta3L CCTK_ATTRIBUTE_UNUSED = beta3[index];
    CCTK_REAL gt11L CCTK_ATTRIBUTE_UNUSED = gt11[index];
    CCTK_REAL gt12L CCTK_ATTRIBUTE_UNUSED = gt12[index];
    CCTK_REAL gt13L CCTK_ATTRIBUTE_UNUSED = gt13[index];
    CCTK_REAL gt22L CCTK_ATTRIBUTE_UNUSED = gt22[index];
    CCTK_REAL gt23L CCTK_ATTRIBUTE_UNUSED = gt23[index];
    CCTK_REAL gt33L CCTK_ATTRIBUTE_UNUSED = gt33[index];
    CCTK_REAL phiL CCTK_ATTRIBUTE_UNUSED = phi[index];
    CCTK_REAL ThetaL CCTK_ATTRIBUTE_UNUSED = Theta[index];
    CCTK_REAL trKL CCTK_ATTRIBUTE_UNUSED = trK[index];
    
    /* Include user supplied include files */
    /* Precompute derivatives */
    const CCTK_REAL PDupwindNthSymm1alpha CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm1(&alpha[index]);
    const CCTK_REAL PDupwindNthSymm2alpha CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm2(&alpha[index]);
    const CCTK_REAL PDupwindNthSymm3alpha CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm3(&alpha[index]);
    const CCTK_REAL PDupwindNthAnti1alpha CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti1(&alpha[index]);
    const CCTK_REAL PDupwindNthAnti2alpha CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti2(&alpha[index]);
    const CCTK_REAL PDupwindNthAnti3alpha CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti3(&alpha[index]);
    const CCTK_REAL PDdissipationNth1alpha CCTK_ATTRIBUTE_UNUSED = PDdissipationNth1(&alpha[index]);
    const CCTK_REAL PDdissipationNth2alpha CCTK_ATTRIBUTE_UNUSED = PDdissipationNth2(&alpha[index]);
    const CCTK_REAL PDdissipationNth3alpha CCTK_ATTRIBUTE_UNUSED = PDdissipationNth3(&alpha[index]);
    const CCTK_REAL PDstandardNth1beta1 CCTK_ATTRIBUTE_UNUSED = PDstandardNth1(&beta1[index]);
    const CCTK_REAL PDstandardNth2beta1 CCTK_ATTRIBUTE_UNUSED = PDstandardNth2(&beta1[index]);
    const CCTK_REAL PDstandardNth3beta1 CCTK_ATTRIBUTE_UNUSED = PDstandardNth3(&beta1[index]);
    const CCTK_REAL PDstandardNth1beta2 CCTK_ATTRIBUTE_UNUSED = PDstandardNth1(&beta2[index]);
    const CCTK_REAL PDstandardNth2beta2 CCTK_ATTRIBUTE_UNUSED = PDstandardNth2(&beta2[index]);
    const CCTK_REAL PDstandardNth3beta2 CCTK_ATTRIBUTE_UNUSED = PDstandardNth3(&beta2[index]);
    const CCTK_REAL PDstandardNth1beta3 CCTK_ATTRIBUTE_UNUSED = PDstandardNth1(&beta3[index]);
    const CCTK_REAL PDstandardNth2beta3 CCTK_ATTRIBUTE_UNUSED = PDstandardNth2(&beta3[index]);
    const CCTK_REAL PDstandardNth3beta3 CCTK_ATTRIBUTE_UNUSED = PDstandardNth3(&beta3[index]);
    const CCTK_REAL PDupwindNthSymm1gt11 CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm1(&gt11[index]);
    const CCTK_REAL PDupwindNthSymm2gt11 CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm2(&gt11[index]);
    const CCTK_REAL PDupwindNthSymm3gt11 CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm3(&gt11[index]);
    const CCTK_REAL PDupwindNthAnti1gt11 CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti1(&gt11[index]);
    const CCTK_REAL PDupwindNthAnti2gt11 CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti2(&gt11[index]);
    const CCTK_REAL PDupwindNthAnti3gt11 CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti3(&gt11[index]);
    const CCTK_REAL PDdissipationNth1gt11 CCTK_ATTRIBUTE_UNUSED = PDdissipationNth1(&gt11[index]);
    const CCTK_REAL PDdissipationNth2gt11 CCTK_ATTRIBUTE_UNUSED = PDdissipationNth2(&gt11[index]);
    const CCTK_REAL PDdissipationNth3gt11 CCTK_ATTRIBUTE_UNUSED = PDdissipationNth3(&gt11[index]);
    const CCTK_REAL PDupwindNthSymm1gt12 CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm1(&gt12[index]);
    const CCTK_REAL PDupwindNthSymm2gt12 CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm2(&gt12[index]);
    const CCTK_REAL PDupwindNthSymm3gt12 CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm3(&gt12[index]);
    const CCTK_REAL PDupwindNthAnti1gt12 CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti1(&gt12[index]);
    const CCTK_REAL PDupwindNthAnti2gt12 CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti2(&gt12[index]);
    const CCTK_REAL PDupwindNthAnti3gt12 CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti3(&gt12[index]);
    const CCTK_REAL PDdissipationNth1gt12 CCTK_ATTRIBUTE_UNUSED = PDdissipationNth1(&gt12[index]);
    const CCTK_REAL PDdissipationNth2gt12 CCTK_ATTRIBUTE_UNUSED = PDdissipationNth2(&gt12[index]);
    const CCTK_REAL PDdissipationNth3gt12 CCTK_ATTRIBUTE_UNUSED = PDdissipationNth3(&gt12[index]);
    const CCTK_REAL PDupwindNthSymm1gt13 CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm1(&gt13[index]);
    const CCTK_REAL PDupwindNthSymm2gt13 CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm2(&gt13[index]);
    const CCTK_REAL PDupwindNthSymm3gt13 CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm3(&gt13[index]);
    const CCTK_REAL PDupwindNthAnti1gt13 CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti1(&gt13[index]);
    const CCTK_REAL PDupwindNthAnti2gt13 CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti2(&gt13[index]);
    const CCTK_REAL PDupwindNthAnti3gt13 CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti3(&gt13[index]);
    const CCTK_REAL PDdissipationNth1gt13 CCTK_ATTRIBUTE_UNUSED = PDdissipationNth1(&gt13[index]);
    const CCTK_REAL PDdissipationNth2gt13 CCTK_ATTRIBUTE_UNUSED = PDdissipationNth2(&gt13[index]);
    const CCTK_REAL PDdissipationNth3gt13 CCTK_ATTRIBUTE_UNUSED = PDdissipationNth3(&gt13[index]);
    const CCTK_REAL PDupwindNthSymm1gt22 CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm1(&gt22[index]);
    const CCTK_REAL PDupwindNthSymm2gt22 CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm2(&gt22[index]);
    const CCTK_REAL PDupwindNthSymm3gt22 CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm3(&gt22[index]);
    const CCTK_REAL PDupwindNthAnti1gt22 CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti1(&gt22[index]);
    const CCTK_REAL PDupwindNthAnti2gt22 CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti2(&gt22[index]);
    const CCTK_REAL PDupwindNthAnti3gt22 CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti3(&gt22[index]);
    const CCTK_REAL PDdissipationNth1gt22 CCTK_ATTRIBUTE_UNUSED = PDdissipationNth1(&gt22[index]);
    const CCTK_REAL PDdissipationNth2gt22 CCTK_ATTRIBUTE_UNUSED = PDdissipationNth2(&gt22[index]);
    const CCTK_REAL PDdissipationNth3gt22 CCTK_ATTRIBUTE_UNUSED = PDdissipationNth3(&gt22[index]);
    const CCTK_REAL PDupwindNthSymm1gt23 CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm1(&gt23[index]);
    const CCTK_REAL PDupwindNthSymm2gt23 CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm2(&gt23[index]);
    const CCTK_REAL PDupwindNthSymm3gt23 CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm3(&gt23[index]);
    const CCTK_REAL PDupwindNthAnti1gt23 CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti1(&gt23[index]);
    const CCTK_REAL PDupwindNthAnti2gt23 CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti2(&gt23[index]);
    const CCTK_REAL PDupwindNthAnti3gt23 CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti3(&gt23[index]);
    const CCTK_REAL PDdissipationNth1gt23 CCTK_ATTRIBUTE_UNUSED = PDdissipationNth1(&gt23[index]);
    const CCTK_REAL PDdissipationNth2gt23 CCTK_ATTRIBUTE_UNUSED = PDdissipationNth2(&gt23[index]);
    const CCTK_REAL PDdissipationNth3gt23 CCTK_ATTRIBUTE_UNUSED = PDdissipationNth3(&gt23[index]);
    const CCTK_REAL PDupwindNthSymm1gt33 CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm1(&gt33[index]);
    const CCTK_REAL PDupwindNthSymm2gt33 CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm2(&gt33[index]);
    const CCTK_REAL PDupwindNthSymm3gt33 CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm3(&gt33[index]);
    const CCTK_REAL PDupwindNthAnti1gt33 CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti1(&gt33[index]);
    const CCTK_REAL PDupwindNthAnti2gt33 CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti2(&gt33[index]);
    const CCTK_REAL PDupwindNthAnti3gt33 CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti3(&gt33[index]);
    const CCTK_REAL PDdissipationNth1gt33 CCTK_ATTRIBUTE_UNUSED = PDdissipationNth1(&gt33[index]);
    const CCTK_REAL PDdissipationNth2gt33 CCTK_ATTRIBUTE_UNUSED = PDdissipationNth2(&gt33[index]);
    const CCTK_REAL PDdissipationNth3gt33 CCTK_ATTRIBUTE_UNUSED = PDdissipationNth3(&gt33[index]);
    const CCTK_REAL PDupwindNthSymm1phi CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm1(&phi[index]);
    const CCTK_REAL PDupwindNthSymm2phi CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm2(&phi[index]);
    const CCTK_REAL PDupwindNthSymm3phi CCTK_ATTRIBUTE_UNUSED = PDupwindNthSymm3(&phi[index]);
    const CCTK_REAL PDupwindNthAnti1phi CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti1(&phi[index]);
    const CCTK_REAL PDupwindNthAnti2phi CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti2(&phi[index]);
    const CCTK_REAL PDupwindNthAnti3phi CCTK_ATTRIBUTE_UNUSED = PDupwindNthAnti3(&phi[index]);
    const CCTK_REAL PDdissipationNth1phi CCTK_ATTRIBUTE_UNUSED = PDdissipationNth1(&phi[index]);
    const CCTK_REAL PDdissipationNth2phi CCTK_ATTRIBUTE_UNUSED = PDdissipationNth2(&phi[index]);
    const CCTK_REAL PDdissipationNth3phi CCTK_ATTRIBUTE_UNUSED = PDdissipationNth3(&phi[index]);
    /* Calculate temporaries and grid functions */
    CCTK_REAL epsdiss1 CCTK_ATTRIBUTE_UNUSED = epsDiss;
    
    CCTK_REAL epsdiss2 CCTK_ATTRIBUTE_UNUSED = epsDiss;
    
    CCTK_REAL epsdiss3 CCTK_ATTRIBUTE_UNUSED = epsDiss;
    
    CCTK_REAL detgt CCTK_ATTRIBUTE_UNUSED = 1;
    
    CCTK_REAL gtu11 CCTK_ATTRIBUTE_UNUSED = (gt22L*gt33L - 
      pow(gt23L,2))*pow(detgt,-1);
    
    CCTK_REAL gtu12 CCTK_ATTRIBUTE_UNUSED = (gt13L*gt23L - 
      gt12L*gt33L)*pow(detgt,-1);
    
    CCTK_REAL gtu13 CCTK_ATTRIBUTE_UNUSED = (-(gt13L*gt22L) + 
      gt12L*gt23L)*pow(detgt,-1);
    
    CCTK_REAL gtu22 CCTK_ATTRIBUTE_UNUSED = (gt11L*gt33L - 
      pow(gt13L,2))*pow(detgt,-1);
    
    CCTK_REAL gtu23 CCTK_ATTRIBUTE_UNUSED = (gt12L*gt13L - 
      gt11L*gt23L)*pow(detgt,-1);
    
    CCTK_REAL gtu33 CCTK_ATTRIBUTE_UNUSED = (gt11L*gt22L - 
      pow(gt12L,2))*pow(detgt,-1);
    
    CCTK_REAL Atm11 CCTK_ATTRIBUTE_UNUSED = At11L*gtu11 + At12L*gtu12 + 
      At13L*gtu13;
    
    CCTK_REAL Atm22 CCTK_ATTRIBUTE_UNUSED = At12L*gtu12 + At22L*gtu22 + 
      At23L*gtu23;
    
    CCTK_REAL Atm33 CCTK_ATTRIBUTE_UNUSED = At13L*gtu13 + At23L*gtu23 + 
      At33L*gtu33;
    
    CCTK_REAL phirhsL CCTK_ATTRIBUTE_UNUSED = 
      epsdiss1*PDdissipationNth1phi + epsdiss2*PDdissipationNth2phi + 
      epsdiss3*PDdissipationNth3phi + 
      0.333333333333333333333333333333*phiL*(alphaL*trKL - 
      PDstandardNth1beta1 - PDstandardNth2beta2 - PDstandardNth3beta3) + 
      beta1L*PDupwindNthAnti1phi + beta2L*PDupwindNthAnti2phi + 
      beta3L*PDupwindNthAnti3phi + PDupwindNthSymm1phi*fabs(beta1L) + 
      PDupwindNthSymm2phi*fabs(beta2L) + PDupwindNthSymm3phi*fabs(beta3L);
    
    CCTK_REAL trAt CCTK_ATTRIBUTE_UNUSED = Atm11 + Atm22 + Atm33;
    
    CCTK_REAL gt11rhsL CCTK_ATTRIBUTE_UNUSED = 
      epsdiss1*PDdissipationNth1gt11 + epsdiss2*PDdissipationNth2gt11 + 
      epsdiss3*PDdissipationNth3gt11 + 2*(gt11L*PDstandardNth1beta1 + 
      gt12L*PDstandardNth1beta2 + gt13L*PDstandardNth1beta3) - 
      0.666666666666666666666666666667*gt11L*(PDstandardNth1beta1 + 
      PDstandardNth2beta2 + PDstandardNth3beta3) + 
      beta1L*PDupwindNthAnti1gt11 + beta2L*PDupwindNthAnti2gt11 + 
      beta3L*PDupwindNthAnti3gt11 - 2*alphaL*(At11L - 
      0.333333333333333333333333333333*gt11L*trAt) + 
      PDupwindNthSymm1gt11*fabs(beta1L) + PDupwindNthSymm2gt11*fabs(beta2L) + 
      PDupwindNthSymm3gt11*fabs(beta3L);
    
    CCTK_REAL gt12rhsL CCTK_ATTRIBUTE_UNUSED = 
      epsdiss1*PDdissipationNth1gt12 + epsdiss2*PDdissipationNth2gt12 + 
      epsdiss3*PDdissipationNth3gt12 + gt22L*PDstandardNth1beta2 + 
      gt23L*PDstandardNth1beta3 + gt11L*PDstandardNth2beta1 + 
      gt13L*PDstandardNth2beta3 + 
      gt12L*(0.333333333333333333333333333333*(PDstandardNth1beta1 + 
      PDstandardNth2beta2) - 
      0.666666666666666666666666666667*PDstandardNth3beta3) + 
      beta1L*PDupwindNthAnti1gt12 + beta2L*PDupwindNthAnti2gt12 + 
      beta3L*PDupwindNthAnti3gt12 + alphaL*(-2*At12L + 
      0.666666666666666666666666666667*gt12L*trAt) + 
      PDupwindNthSymm1gt12*fabs(beta1L) + PDupwindNthSymm2gt12*fabs(beta2L) + 
      PDupwindNthSymm3gt12*fabs(beta3L);
    
    CCTK_REAL gt13rhsL CCTK_ATTRIBUTE_UNUSED = 
      epsdiss1*PDdissipationNth1gt13 + epsdiss2*PDdissipationNth2gt13 + 
      epsdiss3*PDdissipationNth3gt13 + gt23L*PDstandardNth1beta2 + 
      gt33L*PDstandardNth1beta3 + gt11L*PDstandardNth3beta1 + 
      gt12L*PDstandardNth3beta2 + 
      gt13L*(-0.666666666666666666666666666667*PDstandardNth2beta2 + 
      0.333333333333333333333333333333*(PDstandardNth1beta1 + 
      PDstandardNth3beta3)) + beta1L*PDupwindNthAnti1gt13 + 
      beta2L*PDupwindNthAnti2gt13 + beta3L*PDupwindNthAnti3gt13 + 
      alphaL*(-2*At13L + 0.666666666666666666666666666667*gt13L*trAt) + 
      PDupwindNthSymm1gt13*fabs(beta1L) + PDupwindNthSymm2gt13*fabs(beta2L) + 
      PDupwindNthSymm3gt13*fabs(beta3L);
    
    CCTK_REAL gt22rhsL CCTK_ATTRIBUTE_UNUSED = 
      epsdiss1*PDdissipationNth1gt22 + epsdiss2*PDdissipationNth2gt22 + 
      epsdiss3*PDdissipationNth3gt22 + 2*(gt12L*PDstandardNth2beta1 + 
      gt22L*PDstandardNth2beta2 + gt23L*PDstandardNth2beta3) - 
      0.666666666666666666666666666667*gt22L*(PDstandardNth1beta1 + 
      PDstandardNth2beta2 + PDstandardNth3beta3) + 
      beta1L*PDupwindNthAnti1gt22 + beta2L*PDupwindNthAnti2gt22 + 
      beta3L*PDupwindNthAnti3gt22 - 2*alphaL*(At22L - 
      0.333333333333333333333333333333*gt22L*trAt) + 
      PDupwindNthSymm1gt22*fabs(beta1L) + PDupwindNthSymm2gt22*fabs(beta2L) + 
      PDupwindNthSymm3gt22*fabs(beta3L);
    
    CCTK_REAL gt23rhsL CCTK_ATTRIBUTE_UNUSED = 
      epsdiss1*PDdissipationNth1gt23 + epsdiss2*PDdissipationNth2gt23 + 
      epsdiss3*PDdissipationNth3gt23 + gt13L*PDstandardNth2beta1 + 
      gt33L*PDstandardNth2beta3 + gt12L*PDstandardNth3beta1 + 
      gt22L*PDstandardNth3beta2 + 
      gt23L*(-0.666666666666666666666666666667*PDstandardNth1beta1 + 
      0.333333333333333333333333333333*(PDstandardNth2beta2 + 
      PDstandardNth3beta3)) + beta1L*PDupwindNthAnti1gt23 + 
      beta2L*PDupwindNthAnti2gt23 + beta3L*PDupwindNthAnti3gt23 + 
      alphaL*(-2*At23L + 0.666666666666666666666666666667*gt23L*trAt) + 
      PDupwindNthSymm1gt23*fabs(beta1L) + PDupwindNthSymm2gt23*fabs(beta2L) + 
      PDupwindNthSymm3gt23*fabs(beta3L);
    
    CCTK_REAL gt33rhsL CCTK_ATTRIBUTE_UNUSED = 
      epsdiss1*PDdissipationNth1gt33 + epsdiss2*PDdissipationNth2gt33 + 
      epsdiss3*PDdissipationNth3gt33 - 
      0.666666666666666666666666666667*gt33L*(PDstandardNth1beta1 + 
      PDstandardNth2beta2 + PDstandardNth3beta3) + 
      2*(gt13L*PDstandardNth3beta1 + gt23L*PDstandardNth3beta2 + 
      gt33L*PDstandardNth3beta3) + beta1L*PDupwindNthAnti1gt33 + 
      beta2L*PDupwindNthAnti2gt33 + beta3L*PDupwindNthAnti3gt33 - 
      2*alphaL*(At33L - 0.333333333333333333333333333333*gt33L*trAt) + 
      PDupwindNthSymm1gt33*fabs(beta1L) + PDupwindNthSymm2gt33*fabs(beta2L) + 
      PDupwindNthSymm3gt33*fabs(beta3L);
    
    CCTK_REAL dotalpha CCTK_ATTRIBUTE_UNUSED = -((-2*ThetaL + trKL + (-1 + 
      alphaL)*alphaDriver)*harmonicF*pow(alphaL,harmonicN));
    
    CCTK_REAL alpharhsL CCTK_ATTRIBUTE_UNUSED = dotalpha + 
      epsdiss1*PDdissipationNth1alpha + epsdiss2*PDdissipationNth2alpha + 
      epsdiss3*PDdissipationNth3alpha + IfThen(advectLapse != 
      0,beta1L*PDupwindNthAnti1alpha + beta2L*PDupwindNthAnti2alpha + 
      beta3L*PDupwindNthAnti3alpha + PDupwindNthSymm1alpha*fabs(beta1L) + 
      PDupwindNthSymm2alpha*fabs(beta2L) + 
      PDupwindNthSymm3alpha*fabs(beta3L),0);
    /* Copy local copies back to grid functions */
    alpharhs[index] = alpharhsL;
    gt11rhs[index] = gt11rhsL;
    gt12rhs[index] = gt12rhsL;
    gt13rhs[index] = gt13rhsL;
    gt22rhs[index] = gt22rhsL;
    gt23rhs[index] = gt23rhsL;
    gt33rhs[index] = gt33rhsL;
    phirhs[index] = phirhsL;
  }
  CCTK_ENDLOOP3(ML_CCZ4_EvolutionInteriorSplitBy1);
}
extern "C" void ML_CCZ4_EvolutionInteriorSplitBy1(CCTK_ARGUMENTS)
{
  #ifdef DECLARE_CCTK_ARGUMENTS_ML_CCZ4_EvolutionInteriorSplitBy1
  DECLARE_CCTK_ARGUMENTS_CHECKED(ML_CCZ4_EvolutionInteriorSplitBy1);
  #else
  DECLARE_CCTK_ARGUMENTS
  #endif
  DECLARE_CCTK_PARAMETERS
  
  if (verbose > 1)
  {
    CCTK_VInfo(CCTK_THORNSTRING,"Entering ML_CCZ4_EvolutionInteriorSplitBy1_Body");
  }
  if (cctk_iteration % ML_CCZ4_EvolutionInteriorSplitBy1_calc_every != ML_CCZ4_EvolutionInteriorSplitBy1_calc_offset)
  {
    return;
  }
  
  const char* const groups[] = {
    "ML_CCZ4::ML_curv",
    "ML_CCZ4::ML_lapse",
    "ML_CCZ4::ML_lapserhs",
    "ML_CCZ4::ML_log_confac",
    "ML_CCZ4::ML_log_confacrhs",
    "ML_CCZ4::ML_metric",
    "ML_CCZ4::ML_metricrhs",
    "ML_CCZ4::ML_shift",
    "ML_CCZ4::ML_Theta",
    "ML_CCZ4::ML_trace_curv"};
  AssertGroupStorage(cctkGH, "ML_CCZ4_EvolutionInteriorSplitBy1", 10, groups);
  
  EnsureStencilFits(cctkGH, "ML_CCZ4_EvolutionInteriorSplitBy1", 5, 5, 5);
  
  LoopOverInterior(cctkGH, ML_CCZ4_EvolutionInteriorSplitBy1_Body);
  if (verbose > 1)
  {
    CCTK_VInfo(CCTK_THORNSTRING,"Leaving ML_CCZ4_EvolutionInteriorSplitBy1_Body");
  }
}

} // namespace ML_CCZ4
