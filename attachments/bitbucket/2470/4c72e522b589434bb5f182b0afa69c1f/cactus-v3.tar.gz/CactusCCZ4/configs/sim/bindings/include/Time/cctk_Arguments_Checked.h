#ifndef CCTK_ARGUMENTS_CHECKED_H
#define CCTK_ARGUMENTS_CHECKED_H 1

/* needed for CCTK_ANSI_FPP */
#include "cctk_Types.h"

#ifdef CCODE
#define DECLARE_CCTK_ARGUMENTS_CHECKED(func) DECLARE_CCTK_ARGUMENTS_##func
#endif
#ifdef FCODE
#if CCTK_ANSI_FPP
#define DECLARE_CCTK_ARGUMENTS_CHECKED(func) DECLARE_CCTK_ARGUMENTS_##func
#else
#define DECLARE_CCTK_ARGUMENTS_CHECKED(func) DECLARE_CCTK_ARGUMENTS_/**/func
#endif
#endif

#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_Time_Courant 
#define DECLARE_CCTK_ARGUMENTS_Time_Courant \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_REAL  * restrict const courant_dt __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).courant_dt));; /* TL: Time_Courant_C --> 0 no*/\
CCTK_REAL const * restrict const courant_min_time __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).courant_min_time));; /* group yes */\
CCTK_REAL const * restrict const courant_wave_speed __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).courant_wave_speed));; /* group yes */\
  /* end Time_Courant */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_Time_Given 
#define DECLARE_CCTK_ARGUMENTS_Time_Given \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end Time_Given */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_Time_Initialise 
#define DECLARE_CCTK_ARGUMENTS_Time_Initialise \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_REAL  * restrict const courant_dt __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).courant_dt));; /* TL: Time_Initialise_C --> 0 no*/\
CCTK_REAL  * restrict const courant_min_time __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).courant_min_time));; /* group yes */\
CCTK_REAL  * restrict const courant_wave_speed __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).courant_wave_speed));; /* group yes */\
  /* end Time_Initialise */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_Time_Simple 
#define DECLARE_CCTK_ARGUMENTS_Time_Simple \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end Time_Simple */
#endif
#endif
#endif