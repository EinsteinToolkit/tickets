#ifndef CCTK_ARGUMENTS_CHECKED_H
#define CCTK_ARGUMENTS_CHECKED_H 1

/* needed for CCTK_ANSI_FPP */
#include "cctk_Types.h"

#ifdef CCODE
#define DECLARE_CCTK_ARGUMENTS_CHECKED(func) DECLARE_CCTK_ARGUMENTS_##func
#endif
#ifdef FCODE
#if CCTK_ANSI_FPP
#define DECLARE_CCTK_ARGUMENTS_CHECKED(func) DECLARE_CCTK_ARGUMENTS_##func
#else
#define DECLARE_CCTK_ARGUMENTS_CHECKED(func) DECLARE_CCTK_ARGUMENTS_/**/func
#endif
#endif

#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_PUGH_PrintFinalStorageReport 
#define DECLARE_CCTK_ARGUMENTS_PUGH_PrintFinalStorageReport \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end PUGH_PrintFinalStorageReport */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_PUGH_PrintStorageReport 
#define DECLARE_CCTK_ARGUMENTS_PUGH_PrintStorageReport \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end PUGH_PrintStorageReport */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_PUGH_PrintTimingInfo 
#define DECLARE_CCTK_ARGUMENTS_PUGH_PrintTimingInfo \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end PUGH_PrintTimingInfo */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_PUGH_RegisterPUGHP2LRoutines 
#define DECLARE_CCTK_ARGUMENTS_PUGH_RegisterPUGHP2LRoutines \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end PUGH_RegisterPUGHP2LRoutines */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_PUGH_RegisterPUGHTopologyRoutines 
#define DECLARE_CCTK_ARGUMENTS_PUGH_RegisterPUGHTopologyRoutines \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end PUGH_RegisterPUGHTopologyRoutines */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_PUGH_Report 
#define DECLARE_CCTK_ARGUMENTS_PUGH_Report \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end PUGH_Report */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_PUGH_Startup 
#define DECLARE_CCTK_ARGUMENTS_PUGH_Startup \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end PUGH_Startup */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_PUGH_Terminate 
#define DECLARE_CCTK_ARGUMENTS_PUGH_Terminate \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end PUGH_Terminate */
#endif
#endif
#endif