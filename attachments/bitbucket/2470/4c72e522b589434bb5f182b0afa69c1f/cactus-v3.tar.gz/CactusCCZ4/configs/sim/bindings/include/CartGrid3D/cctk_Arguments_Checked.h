#ifndef CCTK_ARGUMENTS_CHECKED_H
#define CCTK_ARGUMENTS_CHECKED_H 1

/* needed for CCTK_ANSI_FPP */
#include "cctk_Types.h"

#ifdef CCODE
#define DECLARE_CCTK_ARGUMENTS_CHECKED(func) DECLARE_CCTK_ARGUMENTS_##func
#endif
#ifdef FCODE
#if CCTK_ANSI_FPP
#define DECLARE_CCTK_ARGUMENTS_CHECKED(func) DECLARE_CCTK_ARGUMENTS_##func
#else
#define DECLARE_CCTK_ARGUMENTS_CHECKED(func) DECLARE_CCTK_ARGUMENTS_/**/func
#endif
#endif

#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_CartGrid3D_ApplyBC 
#define DECLARE_CCTK_ARGUMENTS_CartGrid3D_ApplyBC \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end CartGrid3D_ApplyBC */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_CartGrid3D_RegisterSymmetryBoundaries 
#define DECLARE_CCTK_ARGUMENTS_CartGrid3D_RegisterSymmetryBoundaries \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end CartGrid3D_RegisterSymmetryBoundaries */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_CartGrid3D_SetCoordinates 
#define DECLARE_CCTK_ARGUMENTS_CartGrid3D_SetCoordinates \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_REAL  * restrict const r __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).r));; /* group yes */\
CCTK_REAL  * restrict const x __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).x));; /* group yes */\
CCTK_REAL  * restrict const y __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).y));; /* group yes */\
CCTK_REAL  * restrict const z __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).z));; /* group yes */\
  /* end CartGrid3D_SetCoordinates */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_CartGrid3D_SetRanges 
#define DECLARE_CCTK_ARGUMENTS_CartGrid3D_SetRanges \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_REAL  * restrict const coarse_dx __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).coarse_dx));; /* group yes */\
CCTK_REAL  * restrict const coarse_dy __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).coarse_dy));; /* group yes */\
CCTK_REAL  * restrict const coarse_dz __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).coarse_dz));; /* group yes */\
  /* end CartGrid3D_SetRanges */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_ParamCheck_CartGrid3D 
#define DECLARE_CCTK_ARGUMENTS_ParamCheck_CartGrid3D \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end ParamCheck_CartGrid3D */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_RegisterCartGrid3DCoords 
#define DECLARE_CCTK_ARGUMENTS_RegisterCartGrid3DCoords \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end RegisterCartGrid3DCoords */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_SymmetryStartup 
#define DECLARE_CCTK_ARGUMENTS_SymmetryStartup \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end SymmetryStartup */
#endif
#endif
#endif