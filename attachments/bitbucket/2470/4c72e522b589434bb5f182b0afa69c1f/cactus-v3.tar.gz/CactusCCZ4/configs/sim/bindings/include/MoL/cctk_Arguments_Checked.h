#ifndef CCTK_ARGUMENTS_CHECKED_H
#define CCTK_ARGUMENTS_CHECKED_H 1

/* needed for CCTK_ANSI_FPP */
#include "cctk_Types.h"

#ifdef CCODE
#define DECLARE_CCTK_ARGUMENTS_CHECKED(func) DECLARE_CCTK_ARGUMENTS_##func
#endif
#ifdef FCODE
#if CCTK_ANSI_FPP
#define DECLARE_CCTK_ARGUMENTS_CHECKED(func) DECLARE_CCTK_ARGUMENTS_##func
#else
#define DECLARE_CCTK_ARGUMENTS_CHECKED(func) DECLARE_CCTK_ARGUMENTS_/**/func
#endif
#endif

#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_MoL_ABAdd 
#define DECLARE_CCTK_ARGUMENTS_MoL_ABAdd \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_INT const * restrict const MoL_Intermediate_Step __attribute__((__unused__)) = ((CCTK_INT *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).MoL_Intermediate_Step));; /* TL: MoL_ABAdd_C --> 0 no*/\
  /* end MoL_ABAdd */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_MoL_AllocateScratchSpace 
#define DECLARE_CCTK_ARGUMENTS_MoL_AllocateScratchSpace \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end MoL_AllocateScratchSpace */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_MoL_AllocateScratch 
#define DECLARE_CCTK_ARGUMENTS_MoL_AllocateScratch \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end MoL_AllocateScratch */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_MoL_DecrementCounter 
#define DECLARE_CCTK_ARGUMENTS_MoL_DecrementCounter \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_INT  * restrict const MoL_Intermediate_Step __attribute__((__unused__)) = ((CCTK_INT *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).MoL_Intermediate_Step));; /* TL: MoL_DecrementCounter_C --> 0 no*/\
CCTK_INT  * restrict const MoL_SlowPostStep __attribute__((__unused__)) = ((CCTK_INT *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).MoL_SlowPostStep));; /* TL: MoL_DecrementCounter_C --> 0 no*/\
CCTK_INT  * restrict const MoL_SlowStep __attribute__((__unused__)) = ((CCTK_INT *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).MoL_SlowStep));; /* TL: MoL_DecrementCounter_C --> 0 no*/\
  /* end MoL_DecrementCounter */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_MoL_EulerAdd 
#define DECLARE_CCTK_ARGUMENTS_MoL_EulerAdd \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_INT const * restrict const MoL_Intermediate_Step __attribute__((__unused__)) = ((CCTK_INT *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).MoL_Intermediate_Step));; /* TL: MoL_EulerAdd_C --> 0 no*/\
  /* end MoL_EulerAdd */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_MoL_FillAllLevels 
#define DECLARE_CCTK_ARGUMENTS_MoL_FillAllLevels \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end MoL_FillAllLevels */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_MoL_FindAdaptiveError 
#define DECLARE_CCTK_ARGUMENTS_MoL_FindAdaptiveError \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_REAL  * restrict const Count __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Count));; /* TL: MoL_FindAdaptiveError_C --> 0 no*/\
CCTK_REAL  * restrict const Error __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Error));; /* TL: MoL_FindAdaptiveError_C --> 0 no*/\
CCTK_REAL const * restrict const Original_Delta_Time __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Original_Delta_Time));; /* TL: MoL_FindAdaptiveError_C --> 0 no*/\
  /* end MoL_FindAdaptiveError */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_MoL_FinishLoop 
#define DECLARE_CCTK_ARGUMENTS_MoL_FinishLoop \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_INT  * restrict const MoL_SlowPostStep __attribute__((__unused__)) = ((CCTK_INT *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).MoL_SlowPostStep));; /* TL: MoL_FinishLoop_C --> 0 no*/\
CCTK_INT  * restrict const MoL_SlowStep __attribute__((__unused__)) = ((CCTK_INT *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).MoL_SlowStep));; /* TL: MoL_FinishLoop_C --> 0 no*/\
CCTK_INT  * restrict const MoL_Stepsize_Bad __attribute__((__unused__)) = ((CCTK_INT *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).MoL_Stepsize_Bad));; /* TL: MoL_FinishLoop_C --> 0 no*/\
  /* end MoL_FinishLoop */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_MoL_FreeIndexArrays 
#define DECLARE_CCTK_ARGUMENTS_MoL_FreeIndexArrays \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end MoL_FreeIndexArrays */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_MoL_FreeScratchSpace 
#define DECLARE_CCTK_ARGUMENTS_MoL_FreeScratchSpace \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end MoL_FreeScratchSpace */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_MoL_GenericRKAdd 
#define DECLARE_CCTK_ARGUMENTS_MoL_GenericRKAdd \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_INT const * restrict const MoL_Intermediate_Step __attribute__((__unused__)) = ((CCTK_INT *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).MoL_Intermediate_Step));; /* TL: MoL_GenericRKAdd_C --> 0 no*/\
CCTK_REAL const * restrict const Original_Delta_Time __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Original_Delta_Time));; /* TL: MoL_GenericRKAdd_C --> 0 no*/\
CCTK_REAL const * restrict const RKAlphaCoefficients __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).RKAlphaCoefficients));; /* TL: MoL_GenericRKAdd_C --> 0 no*/\
CCTK_REAL const * restrict const RKBetaCoefficients __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).RKBetaCoefficients));; /* TL: MoL_GenericRKAdd_C --> 0 no*/\
  /* end MoL_GenericRKAdd */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_MoL_ICNAdd 
#define DECLARE_CCTK_ARGUMENTS_MoL_ICNAdd \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_INT const * restrict const MoL_Intermediate_Step __attribute__((__unused__)) = ((CCTK_INT *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).MoL_Intermediate_Step));; /* TL: MoL_ICNAdd_C --> 0 no*/\
  /* end MoL_ICNAdd */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_MoL_ICNAverage 
#define DECLARE_CCTK_ARGUMENTS_MoL_ICNAverage \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_INT const * restrict const MoL_Intermediate_Step __attribute__((__unused__)) = ((CCTK_INT *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).MoL_Intermediate_Step));; /* TL: MoL_ICNAverage_C --> 0 no*/\
  /* end MoL_ICNAverage */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_MoL_InitAdaptiveError 
#define DECLARE_CCTK_ARGUMENTS_MoL_InitAdaptiveError \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_REAL  * restrict const Count __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Count));; /* TL: MoL_InitAdaptiveError_C --> 0 no*/\
CCTK_REAL  * restrict const Error __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Error));; /* TL: MoL_InitAdaptiveError_C --> 0 no*/\
  /* end MoL_InitAdaptiveError */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_MoL_InitRHS 
#define DECLARE_CCTK_ARGUMENTS_MoL_InitRHS \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end MoL_InitRHS */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_MoL_InitialCopy 
#define DECLARE_CCTK_ARGUMENTS_MoL_InitialCopy \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end MoL_InitialCopy */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_MoL_NaNCheck 
#define DECLARE_CCTK_ARGUMENTS_MoL_NaNCheck \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_INT const * restrict const MoL_Intermediate_Step __attribute__((__unused__)) = ((CCTK_INT *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).MoL_Intermediate_Step));; /* TL: MoL_NaNCheck_C --> 0 no*/\
  /* end MoL_NaNCheck */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_MoL_ParamCheck 
#define DECLARE_CCTK_ARGUMENTS_MoL_ParamCheck \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end MoL_ParamCheck */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_MoL_RK2Add 
#define DECLARE_CCTK_ARGUMENTS_MoL_RK2Add \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_INT const * restrict const MoL_Intermediate_Step __attribute__((__unused__)) = ((CCTK_INT *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).MoL_Intermediate_Step));; /* TL: MoL_RK2Add_C --> 0 no*/\
  /* end MoL_RK2Add */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_MoL_RK2CentralAdd 
#define DECLARE_CCTK_ARGUMENTS_MoL_RK2CentralAdd \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_INT const * restrict const MoL_Intermediate_Step __attribute__((__unused__)) = ((CCTK_INT *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).MoL_Intermediate_Step));; /* TL: MoL_RK2CentralAdd_C --> 0 no*/\
CCTK_REAL const * restrict const Original_Delta_Time __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Original_Delta_Time));; /* TL: MoL_RK2CentralAdd_C --> 0 no*/\
  /* end MoL_RK2CentralAdd */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_MoL_RK2_MR_2_1_Add 
#define DECLARE_CCTK_ARGUMENTS_MoL_RK2_MR_2_1_Add \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_INT const * restrict const MoL_Intermediate_Step __attribute__((__unused__)) = ((CCTK_INT *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).MoL_Intermediate_Step));; /* TL: MoL_RK2_MR_2_1_Add_C --> 0 no*/\
CCTK_REAL const * restrict const Original_Delta_Time __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Original_Delta_Time));; /* TL: MoL_RK2_MR_2_1_Add_C --> 0 no*/\
  /* end MoL_RK2_MR_2_1_Add */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_MoL_RK3Add 
#define DECLARE_CCTK_ARGUMENTS_MoL_RK3Add \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_INT const * restrict const MoL_Intermediate_Step __attribute__((__unused__)) = ((CCTK_INT *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).MoL_Intermediate_Step));; /* TL: MoL_RK3Add_C --> 0 no*/\
  /* end MoL_RK3Add */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_MoL_RK45Add 
#define DECLARE_CCTK_ARGUMENTS_MoL_RK45Add \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_INT const * restrict const MoL_Intermediate_Step __attribute__((__unused__)) = ((CCTK_INT *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).MoL_Intermediate_Step));; /* TL: MoL_RK45Add_C --> 0 no*/\
CCTK_REAL const * restrict const Original_Delta_Time __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Original_Delta_Time));; /* TL: MoL_RK45Add_C --> 0 no*/\
  /* end MoL_RK45Add */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_MoL_RK4Add 
#define DECLARE_CCTK_ARGUMENTS_MoL_RK4Add \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_INT const * restrict const MoL_Intermediate_Step __attribute__((__unused__)) = ((CCTK_INT *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).MoL_Intermediate_Step));; /* TL: MoL_RK4Add_C --> 0 no*/\
CCTK_REAL const * restrict const Original_Delta_Time __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Original_Delta_Time));; /* TL: MoL_RK4Add_C --> 0 no*/\
  /* end MoL_RK4Add */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_MoL_RK4_MR_2_1_Add 
#define DECLARE_CCTK_ARGUMENTS_MoL_RK4_MR_2_1_Add \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_INT const * restrict const MoL_Intermediate_Step __attribute__((__unused__)) = ((CCTK_INT *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).MoL_Intermediate_Step));; /* TL: MoL_RK4_MR_2_1_Add_C --> 0 no*/\
CCTK_REAL const * restrict const Original_Delta_Time __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Original_Delta_Time));; /* TL: MoL_RK4_MR_2_1_Add_C --> 0 no*/\
  /* end MoL_RK4_MR_2_1_Add */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_MoL_RK4_RK2_Add 
#define DECLARE_CCTK_ARGUMENTS_MoL_RK4_RK2_Add \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_INT const * restrict const MoL_Intermediate_Step __attribute__((__unused__)) = ((CCTK_INT *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).MoL_Intermediate_Step));; /* TL: MoL_RK4_RK2_Add_C --> 0 no*/\
CCTK_REAL const * restrict const Original_Delta_Time __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Original_Delta_Time));; /* TL: MoL_RK4_RK2_Add_C --> 0 no*/\
  /* end MoL_RK4_RK2_Add */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_MoL_RK65Add 
#define DECLARE_CCTK_ARGUMENTS_MoL_RK65Add \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_INT const * restrict const MoL_Intermediate_Step __attribute__((__unused__)) = ((CCTK_INT *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).MoL_Intermediate_Step));; /* TL: MoL_RK65Add_C --> 0 no*/\
CCTK_REAL const * restrict const Original_Delta_Time __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Original_Delta_Time));; /* TL: MoL_RK65Add_C --> 0 no*/\
  /* end MoL_RK65Add */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_MoL_RK87Add 
#define DECLARE_CCTK_ARGUMENTS_MoL_RK87Add \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_INT const * restrict const MoL_Intermediate_Step __attribute__((__unused__)) = ((CCTK_INT *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).MoL_Intermediate_Step));; /* TL: MoL_RK87Add_C --> 0 no*/\
CCTK_REAL const * restrict const Original_Delta_Time __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Original_Delta_Time));; /* TL: MoL_RK87Add_C --> 0 no*/\
  /* end MoL_RK87Add */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_MoL_ReduceAdaptiveError 
#define DECLARE_CCTK_ARGUMENTS_MoL_ReduceAdaptiveError \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_REAL  * restrict const Count __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Count));; /* TL: MoL_ReduceAdaptiveError_C --> 0 no*/\
CCTK_REAL  * restrict const Error __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Error));; /* TL: MoL_ReduceAdaptiveError_C --> 0 no*/\
CCTK_REAL  * restrict const EstimatedDt __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).EstimatedDt));; /* TL: MoL_ReduceAdaptiveError_C --> 0 no*/\
CCTK_INT  * restrict const MoL_Stepsize_Bad __attribute__((__unused__)) = ((CCTK_INT *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).MoL_Stepsize_Bad));; /* TL: MoL_ReduceAdaptiveError_C --> 0 no*/\
CCTK_REAL const * restrict const Original_Delta_Time __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Original_Delta_Time));; /* TL: MoL_ReduceAdaptiveError_C --> 0 no*/\
  /* end MoL_ReduceAdaptiveError */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_MoL_ReportNumberVariables 
#define DECLARE_CCTK_ARGUMENTS_MoL_ReportNumberVariables \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end MoL_ReportNumberVariables */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_MoL_ResetDeltaTime 
#define DECLARE_CCTK_ARGUMENTS_MoL_ResetDeltaTime \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_INT const * restrict const MoL_Intermediate_Step __attribute__((__unused__)) = ((CCTK_INT *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).MoL_Intermediate_Step));; /* TL: MoL_ResetDeltaTime_C --> 0 no*/\
CCTK_REAL const * restrict const Original_Delta_Time __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Original_Delta_Time));; /* TL: MoL_ResetDeltaTime_C --> 0 no*/\
CCTK_REAL const * restrict const RKAlphaCoefficients __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).RKAlphaCoefficients));; /* TL: MoL_ResetDeltaTime_C --> 0 no*/\
CCTK_REAL const * restrict const RKBetaCoefficients __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).RKBetaCoefficients));; /* TL: MoL_ResetDeltaTime_C --> 0 no*/\
  /* end MoL_ResetDeltaTime */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_MoL_ResetTime 
#define DECLARE_CCTK_ARGUMENTS_MoL_ResetTime \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_INT const * restrict const MoL_Intermediate_Step __attribute__((__unused__)) = ((CCTK_INT *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).MoL_Intermediate_Step));; /* TL: MoL_ResetTime_C --> 0 no*/\
CCTK_REAL const * restrict const Original_Delta_Time __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Original_Delta_Time));; /* group yes */\
CCTK_REAL const * restrict const Original_Time __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Original_Time));; /* group yes */\
CCTK_REAL const * restrict const RKAlphaCoefficients __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).RKAlphaCoefficients));; /* TL: MoL_ResetTime_C --> 0 no*/\
CCTK_REAL const * restrict const RKBetaCoefficients __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).RKBetaCoefficients));; /* TL: MoL_ResetTime_C --> 0 no*/\
  /* end MoL_ResetTime */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_MoL_RestoreSandR 
#define DECLARE_CCTK_ARGUMENTS_MoL_RestoreSandR \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end MoL_RestoreSandR */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_MoL_SetCounter 
#define DECLARE_CCTK_ARGUMENTS_MoL_SetCounter \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_INT  * restrict const MoL_Intermediate_Step __attribute__((__unused__)) = ((CCTK_INT *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).MoL_Intermediate_Step));; /* TL: MoL_SetCounter_C --> 0 no*/\
CCTK_INT  * restrict const MoL_SlowPostStep __attribute__((__unused__)) = ((CCTK_INT *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).MoL_SlowPostStep));; /* TL: MoL_SetCounter_C --> 0 no*/\
CCTK_INT  * restrict const MoL_SlowStep __attribute__((__unused__)) = ((CCTK_INT *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).MoL_SlowStep));; /* TL: MoL_SetCounter_C --> 0 no*/\
  /* end MoL_SetCounter */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_MoL_SetEstimatedDt 
#define DECLARE_CCTK_ARGUMENTS_MoL_SetEstimatedDt \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_REAL const * restrict const EstimatedDt __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).EstimatedDt));; /* TL: MoL_SetEstimatedDt_C --> 0 no*/\
  /* end MoL_SetEstimatedDt */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_MoL_SetScheduleStatus 
#define DECLARE_CCTK_ARGUMENTS_MoL_SetScheduleStatus \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end MoL_SetScheduleStatus */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_MoL_SetTime 
#define DECLARE_CCTK_ARGUMENTS_MoL_SetTime \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_INT const * restrict const MoL_Intermediate_Step __attribute__((__unused__)) = ((CCTK_INT *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).MoL_Intermediate_Step));; /* TL: MoL_SetTime_C --> 0 no*/\
CCTK_REAL  * restrict const Original_Delta_Time __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Original_Delta_Time));; /* group yes */\
CCTK_REAL  * restrict const Original_Time __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Original_Time));; /* group yes */\
CCTK_REAL const * restrict const RKAlphaCoefficients __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).RKAlphaCoefficients));; /* TL: MoL_SetTime_C --> 0 no*/\
CCTK_REAL const * restrict const RKBetaCoefficients __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).RKBetaCoefficients));; /* TL: MoL_SetTime_C --> 0 no*/\
  /* end MoL_SetTime */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_MoL_SetupIndexArrays 
#define DECLARE_CCTK_ARGUMENTS_MoL_SetupIndexArrays \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_REAL  * restrict const Original_Delta_Time __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Original_Delta_Time));; /* group yes */\
CCTK_REAL  * restrict const Original_Time __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Original_Time));; /* group yes */\
CCTK_INT  * restrict const MoL_SlowPostStep __attribute__((__unused__)) = ((CCTK_INT *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).MoL_SlowPostStep));; /* TL: MoL_SetupIndexArrays_C --> 0 no*/\
CCTK_INT  * restrict const MoL_SlowStep __attribute__((__unused__)) = ((CCTK_INT *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).MoL_SlowStep));; /* TL: MoL_SetupIndexArrays_C --> 0 no*/\
  /* end MoL_SetupIndexArrays */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_MoL_SetupRKCoefficients 
#define DECLARE_CCTK_ARGUMENTS_MoL_SetupRKCoefficients \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_REAL  * restrict const RKAlphaCoefficients __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).RKAlphaCoefficients));; /* TL: MoL_SetupRKCoefficients_C --> 0 no*/\
CCTK_REAL  * restrict const RKBetaCoefficients __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).RKBetaCoefficients));; /* TL: MoL_SetupRKCoefficients_C --> 0 no*/\
  /* end MoL_SetupRKCoefficients */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_MoL_StartLoop 
#define DECLARE_CCTK_ARGUMENTS_MoL_StartLoop \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_REAL  * restrict const EstimatedDt __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).EstimatedDt));; /* TL: MoL_StartLoop_C --> 0 no*/\
CCTK_INT  * restrict const MoL_Stepsize_Bad __attribute__((__unused__)) = ((CCTK_INT *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).MoL_Stepsize_Bad));; /* TL: MoL_StartLoop_C --> 0 no*/\
  /* end MoL_StartLoop */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_MoL_Startup 
#define DECLARE_CCTK_ARGUMENTS_MoL_Startup \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end MoL_Startup */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_MoL_UpdateValidForAdd 
#define DECLARE_CCTK_ARGUMENTS_MoL_UpdateValidForAdd \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end MoL_UpdateValidForAdd */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_MoL_UpdateValidForInitialCopy 
#define DECLARE_CCTK_ARGUMENTS_MoL_UpdateValidForInitialCopy \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end MoL_UpdateValidForInitialCopy */
#endif
#endif
#endif