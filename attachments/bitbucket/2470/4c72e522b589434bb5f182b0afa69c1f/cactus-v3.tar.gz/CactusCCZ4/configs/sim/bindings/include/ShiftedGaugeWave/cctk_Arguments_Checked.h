#ifndef CCTK_ARGUMENTS_CHECKED_H
#define CCTK_ARGUMENTS_CHECKED_H 1

/* needed for CCTK_ANSI_FPP */
#include "cctk_Types.h"

#ifdef CCODE
#define DECLARE_CCTK_ARGUMENTS_CHECKED(func) DECLARE_CCTK_ARGUMENTS_##func
#endif
#ifdef FCODE
#if CCTK_ANSI_FPP
#define DECLARE_CCTK_ARGUMENTS_CHECKED(func) DECLARE_CCTK_ARGUMENTS_##func
#else
#define DECLARE_CCTK_ARGUMENTS_CHECKED(func) DECLARE_CCTK_ARGUMENTS_/**/func
#endif
#endif

#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_ShiftedGaugeWave_CheckBoundaries 
#define DECLARE_CCTK_ARGUMENTS_ShiftedGaugeWave_CheckBoundaries \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end ShiftedGaugeWave_CheckBoundaries */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_ShiftedGaugeWave_ParamCheck 
#define DECLARE_CCTK_ARGUMENTS_ShiftedGaugeWave_ParamCheck \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end ShiftedGaugeWave_ParamCheck */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_ShiftedGaugeWave_RegisterSymmetries 
#define DECLARE_CCTK_ARGUMENTS_ShiftedGaugeWave_RegisterSymmetries \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end ShiftedGaugeWave_RegisterSymmetries */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_ShiftedGaugeWave_RegisterVars 
#define DECLARE_CCTK_ARGUMENTS_ShiftedGaugeWave_RegisterVars \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end ShiftedGaugeWave_RegisterVars */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_ShiftedGaugeWave_SelectBoundConds 
#define DECLARE_CCTK_ARGUMENTS_ShiftedGaugeWave_SelectBoundConds \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end ShiftedGaugeWave_SelectBoundConds */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_ShiftedGaugeWave_Startup 
#define DECLARE_CCTK_ARGUMENTS_ShiftedGaugeWave_Startup \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end ShiftedGaugeWave_Startup */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_ShiftedGaugeWave_always 
#define DECLARE_CCTK_ARGUMENTS_ShiftedGaugeWave_always \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_REAL  * restrict const alp __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).alp));; /* TL: ShiftedGaugeWave_always_C --> 0 no*/\
CCTK_REAL  * restrict const betax __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).betax));; /* TL: ShiftedGaugeWave_always_C --> 0 no*/\
CCTK_REAL  * restrict const betay __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).betay));; /* TL: ShiftedGaugeWave_always_C --> 0 no*/\
CCTK_REAL  * restrict const betaz __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).betaz));; /* TL: ShiftedGaugeWave_always_C --> 0 no*/\
CCTK_REAL  * restrict const dtalp __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).dtalp));; /* TL: ShiftedGaugeWave_always_C --> 0 no*/\
CCTK_REAL  * restrict const dtbetax __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).dtbetax));; /* TL: ShiftedGaugeWave_always_C --> 0 no*/\
CCTK_REAL  * restrict const dtbetay __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).dtbetay));; /* TL: ShiftedGaugeWave_always_C --> 0 no*/\
CCTK_REAL  * restrict const dtbetaz __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).dtbetaz));; /* TL: ShiftedGaugeWave_always_C --> 0 no*/\
CCTK_REAL  * restrict const gxx __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gxx));; /* TL: ShiftedGaugeWave_always_C --> 0 no*/\
CCTK_REAL  * restrict const gxy __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gxy));; /* TL: ShiftedGaugeWave_always_C --> 0 no*/\
CCTK_REAL  * restrict const gxz __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gxz));; /* TL: ShiftedGaugeWave_always_C --> 0 no*/\
CCTK_REAL  * restrict const gyy __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gyy));; /* TL: ShiftedGaugeWave_always_C --> 0 no*/\
CCTK_REAL  * restrict const gyz __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gyz));; /* TL: ShiftedGaugeWave_always_C --> 0 no*/\
CCTK_REAL  * restrict const gzz __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gzz));; /* TL: ShiftedGaugeWave_always_C --> 0 no*/\
CCTK_REAL  * restrict const kxx __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).kxx));; /* TL: ShiftedGaugeWave_always_C --> 0 no*/\
CCTK_REAL  * restrict const kxy __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).kxy));; /* TL: ShiftedGaugeWave_always_C --> 0 no*/\
CCTK_REAL  * restrict const kxz __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).kxz));; /* TL: ShiftedGaugeWave_always_C --> 0 no*/\
CCTK_REAL  * restrict const kyy __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).kyy));; /* TL: ShiftedGaugeWave_always_C --> 0 no*/\
CCTK_REAL  * restrict const kyz __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).kyz));; /* TL: ShiftedGaugeWave_always_C --> 0 no*/\
CCTK_REAL  * restrict const kzz __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).kzz));; /* TL: ShiftedGaugeWave_always_C --> 0 no*/\
CCTK_REAL const * restrict const x __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).x));; /* TL: ShiftedGaugeWave_always_C --> 0 no*/\
CCTK_REAL const * restrict const y __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).y));; /* TL: ShiftedGaugeWave_always_C --> 0 no*/\
CCTK_REAL const * restrict const z __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).z));; /* TL: ShiftedGaugeWave_always_C --> 0 no*/\
  /* end ShiftedGaugeWave_always */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_ShiftedGaugeWave_exact 
#define DECLARE_CCTK_ARGUMENTS_ShiftedGaugeWave_exact \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_REAL const * restrict const gxx __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gxx));; /* TL: ShiftedGaugeWave_exact_C --> 0 no*/\
CCTK_REAL const * restrict const gxy __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gxy));; /* TL: ShiftedGaugeWave_exact_C --> 0 no*/\
CCTK_REAL const * restrict const gxz __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gxz));; /* TL: ShiftedGaugeWave_exact_C --> 0 no*/\
CCTK_REAL const * restrict const gyy __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gyy));; /* TL: ShiftedGaugeWave_exact_C --> 0 no*/\
CCTK_REAL const * restrict const gyz __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gyz));; /* TL: ShiftedGaugeWave_exact_C --> 0 no*/\
CCTK_REAL const * restrict const gzz __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gzz));; /* TL: ShiftedGaugeWave_exact_C --> 0 no*/\
CCTK_REAL const * restrict const x __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).x));; /* TL: ShiftedGaugeWave_exact_C --> 0 no*/\
CCTK_REAL const * restrict const y __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).y));; /* TL: ShiftedGaugeWave_exact_C --> 0 no*/\
CCTK_REAL const * restrict const z __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).z));; /* TL: ShiftedGaugeWave_exact_C --> 0 no*/\
CCTK_REAL  * restrict const alpExact __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).alpExact));; /* TL: ShiftedGaugeWave_exact_C --> 0 no*/\
CCTK_REAL  * restrict const betaExact1 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).betaExact1));; /* TL: ShiftedGaugeWave_exact_C --> 0 no*/\
CCTK_REAL  * restrict const betaExact2 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).betaExact2));; /* TL: ShiftedGaugeWave_exact_C --> 0 no*/\
CCTK_REAL  * restrict const betaExact3 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).betaExact3));; /* TL: ShiftedGaugeWave_exact_C --> 0 no*/\
CCTK_REAL  * restrict const dtalpExact __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).dtalpExact));; /* TL: ShiftedGaugeWave_exact_C --> 0 no*/\
CCTK_REAL  * restrict const dtbetaExact1 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).dtbetaExact1));; /* TL: ShiftedGaugeWave_exact_C --> 0 no*/\
CCTK_REAL  * restrict const dtbetaExact2 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).dtbetaExact2));; /* TL: ShiftedGaugeWave_exact_C --> 0 no*/\
CCTK_REAL  * restrict const dtbetaExact3 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).dtbetaExact3));; /* TL: ShiftedGaugeWave_exact_C --> 0 no*/\
CCTK_REAL  * restrict const gExact11 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gExact11));; /* TL: ShiftedGaugeWave_exact_C --> 0 no*/\
CCTK_REAL  * restrict const gExact12 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gExact12));; /* TL: ShiftedGaugeWave_exact_C --> 0 no*/\
CCTK_REAL  * restrict const gExact13 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gExact13));; /* TL: ShiftedGaugeWave_exact_C --> 0 no*/\
CCTK_REAL  * restrict const gExact22 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gExact22));; /* TL: ShiftedGaugeWave_exact_C --> 0 no*/\
CCTK_REAL  * restrict const gExact23 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gExact23));; /* TL: ShiftedGaugeWave_exact_C --> 0 no*/\
CCTK_REAL  * restrict const gExact33 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gExact33));; /* TL: ShiftedGaugeWave_exact_C --> 0 no*/\
CCTK_REAL  * restrict const kExact11 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).kExact11));; /* TL: ShiftedGaugeWave_exact_C --> 0 no*/\
CCTK_REAL  * restrict const kExact12 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).kExact12));; /* TL: ShiftedGaugeWave_exact_C --> 0 no*/\
CCTK_REAL  * restrict const kExact13 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).kExact13));; /* TL: ShiftedGaugeWave_exact_C --> 0 no*/\
CCTK_REAL  * restrict const kExact22 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).kExact22));; /* TL: ShiftedGaugeWave_exact_C --> 0 no*/\
CCTK_REAL  * restrict const kExact23 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).kExact23));; /* TL: ShiftedGaugeWave_exact_C --> 0 no*/\
CCTK_REAL  * restrict const kExact33 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).kExact33));; /* TL: ShiftedGaugeWave_exact_C --> 0 no*/\
  /* end ShiftedGaugeWave_exact */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_ShiftedGaugeWave_initial 
#define DECLARE_CCTK_ARGUMENTS_ShiftedGaugeWave_initial \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_REAL  * restrict const alp __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).alp));; /* TL: ShiftedGaugeWave_initial_C --> 0 no*/\
CCTK_REAL  * restrict const betax __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).betax));; /* TL: ShiftedGaugeWave_initial_C --> 0 no*/\
CCTK_REAL  * restrict const betay __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).betay));; /* TL: ShiftedGaugeWave_initial_C --> 0 no*/\
CCTK_REAL  * restrict const betaz __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).betaz));; /* TL: ShiftedGaugeWave_initial_C --> 0 no*/\
CCTK_REAL  * restrict const dtalp __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).dtalp));; /* TL: ShiftedGaugeWave_initial_C --> 0 no*/\
CCTK_REAL  * restrict const dtbetax __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).dtbetax));; /* TL: ShiftedGaugeWave_initial_C --> 0 no*/\
CCTK_REAL  * restrict const dtbetay __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).dtbetay));; /* TL: ShiftedGaugeWave_initial_C --> 0 no*/\
CCTK_REAL  * restrict const dtbetaz __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).dtbetaz));; /* TL: ShiftedGaugeWave_initial_C --> 0 no*/\
CCTK_REAL  * restrict const gxx __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gxx));; /* TL: ShiftedGaugeWave_initial_C --> 0 no*/\
CCTK_REAL  * restrict const gxy __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gxy));; /* TL: ShiftedGaugeWave_initial_C --> 0 no*/\
CCTK_REAL  * restrict const gxz __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gxz));; /* TL: ShiftedGaugeWave_initial_C --> 0 no*/\
CCTK_REAL  * restrict const gyy __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gyy));; /* TL: ShiftedGaugeWave_initial_C --> 0 no*/\
CCTK_REAL  * restrict const gyz __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gyz));; /* TL: ShiftedGaugeWave_initial_C --> 0 no*/\
CCTK_REAL  * restrict const gzz __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gzz));; /* TL: ShiftedGaugeWave_initial_C --> 0 no*/\
CCTK_REAL  * restrict const kxx __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).kxx));; /* TL: ShiftedGaugeWave_initial_C --> 0 no*/\
CCTK_REAL  * restrict const kxy __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).kxy));; /* TL: ShiftedGaugeWave_initial_C --> 0 no*/\
CCTK_REAL  * restrict const kxz __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).kxz));; /* TL: ShiftedGaugeWave_initial_C --> 0 no*/\
CCTK_REAL  * restrict const kyy __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).kyy));; /* TL: ShiftedGaugeWave_initial_C --> 0 no*/\
CCTK_REAL  * restrict const kyz __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).kyz));; /* TL: ShiftedGaugeWave_initial_C --> 0 no*/\
CCTK_REAL  * restrict const kzz __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).kzz));; /* TL: ShiftedGaugeWave_initial_C --> 0 no*/\
CCTK_REAL const * restrict const x __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).x));; /* TL: ShiftedGaugeWave_initial_C --> 0 no*/\
CCTK_REAL const * restrict const y __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).y));; /* TL: ShiftedGaugeWave_initial_C --> 0 no*/\
CCTK_REAL const * restrict const z __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).z));; /* TL: ShiftedGaugeWave_initial_C --> 0 no*/\
  /* end ShiftedGaugeWave_initial */
#endif
#endif
#endif