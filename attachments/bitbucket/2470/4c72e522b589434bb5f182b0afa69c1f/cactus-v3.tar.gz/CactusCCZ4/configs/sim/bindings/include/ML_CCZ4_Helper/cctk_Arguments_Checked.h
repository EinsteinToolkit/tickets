#ifndef CCTK_ARGUMENTS_CHECKED_H
#define CCTK_ARGUMENTS_CHECKED_H 1

/* needed for CCTK_ANSI_FPP */
#include "cctk_Types.h"

#ifdef CCODE
#define DECLARE_CCTK_ARGUMENTS_CHECKED(func) DECLARE_CCTK_ARGUMENTS_##func
#endif
#ifdef FCODE
#if CCTK_ANSI_FPP
#define DECLARE_CCTK_ARGUMENTS_CHECKED(func) DECLARE_CCTK_ARGUMENTS_##func
#else
#define DECLARE_CCTK_ARGUMENTS_CHECKED(func) DECLARE_CCTK_ARGUMENTS_/**/func
#endif
#endif

#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_ML_CCZ4_ADMBase_SelectBCs 
#define DECLARE_CCTK_ARGUMENTS_ML_CCZ4_ADMBase_SelectBCs \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end ML_CCZ4_ADMBase_SelectBCs */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_ML_CCZ4_ExtrapolateGammas 
#define DECLARE_CCTK_ARGUMENTS_ML_CCZ4_ExtrapolateGammas \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_REAL  * restrict const Xt1 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Xt1));; /* group yes */\
CCTK_REAL  * restrict const Xt2 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Xt2));; /* group yes */\
CCTK_REAL  * restrict const Xt3 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Xt3));; /* group yes */\
  /* end ML_CCZ4_ExtrapolateGammas */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_ML_CCZ4_NewRad 
#define DECLARE_CCTK_ARGUMENTS_ML_CCZ4_NewRad \
  _DECLARE_CCTK_ARGUMENTS; \
CCTK_REAL const * restrict const At11 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At11));; /* group yes */\
CCTK_REAL const * restrict const At12 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At12));; /* group yes */\
CCTK_REAL const * restrict const At13 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At13));; /* group yes */\
CCTK_REAL const * restrict const At22 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At22));; /* group yes */\
CCTK_REAL const * restrict const At23 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At23));; /* group yes */\
CCTK_REAL const * restrict const At33 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At33));; /* group yes */\
CCTK_REAL  * restrict const At11rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At11rhs));; /* group yes */\
CCTK_REAL  * restrict const At12rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At12rhs));; /* group yes */\
CCTK_REAL  * restrict const At13rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At13rhs));; /* group yes */\
CCTK_REAL  * restrict const At22rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At22rhs));; /* group yes */\
CCTK_REAL  * restrict const At23rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At23rhs));; /* group yes */\
CCTK_REAL  * restrict const At33rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).At33rhs));; /* group yes */\
CCTK_REAL const * restrict const Xt1 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Xt1));; /* group yes */\
CCTK_REAL const * restrict const Xt2 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Xt2));; /* group yes */\
CCTK_REAL const * restrict const Xt3 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Xt3));; /* group yes */\
CCTK_REAL  * restrict const Xt1rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Xt1rhs));; /* group yes */\
CCTK_REAL  * restrict const Xt2rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Xt2rhs));; /* group yes */\
CCTK_REAL  * restrict const Xt3rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).Xt3rhs));; /* group yes */\
CCTK_REAL const * restrict const alpha __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).alpha));; /* group yes */\
CCTK_REAL  * restrict const alpharhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).alpharhs));; /* group yes */\
CCTK_REAL const * restrict const gt11 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt11));; /* group yes */\
CCTK_REAL const * restrict const gt12 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt12));; /* group yes */\
CCTK_REAL const * restrict const gt13 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt13));; /* group yes */\
CCTK_REAL const * restrict const gt22 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt22));; /* group yes */\
CCTK_REAL const * restrict const gt23 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt23));; /* group yes */\
CCTK_REAL const * restrict const gt33 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt33));; /* group yes */\
CCTK_REAL  * restrict const gt11rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt11rhs));; /* group yes */\
CCTK_REAL  * restrict const gt12rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt12rhs));; /* group yes */\
CCTK_REAL  * restrict const gt13rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt13rhs));; /* group yes */\
CCTK_REAL  * restrict const gt22rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt22rhs));; /* group yes */\
CCTK_REAL  * restrict const gt23rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt23rhs));; /* group yes */\
CCTK_REAL  * restrict const gt33rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).gt33rhs));; /* group yes */\
CCTK_REAL const * restrict const beta1 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).beta1));; /* group yes */\
CCTK_REAL const * restrict const beta2 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).beta2));; /* group yes */\
CCTK_REAL const * restrict const beta3 __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).beta3));; /* group yes */\
CCTK_REAL  * restrict const beta1rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).beta1rhs));; /* group yes */\
CCTK_REAL  * restrict const beta2rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).beta2rhs));; /* group yes */\
CCTK_REAL  * restrict const beta3rhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).beta3rhs));; /* group yes */\
CCTK_REAL const * restrict const phi __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).phi));; /* TL: ML_CCZ4_NewRad_C --> 0 no*/\
CCTK_REAL  * restrict const phirhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).phirhs));; /* TL: ML_CCZ4_NewRad_C --> 0 no*/\
CCTK_REAL const * restrict const trK __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).trK));; /* TL: ML_CCZ4_NewRad_C --> 0 no*/\
CCTK_REAL  * restrict const trKrhs __attribute__((__unused__)) = ((CCTK_REAL *) CCTKi_VarDataPtrI(cctkGH, 0, CCTK_JOIN_TOKENS(cctki_vi_, CCTK_THORN).trKrhs));; /* TL: ML_CCZ4_NewRad_C --> 0 no*/\
  /* end ML_CCZ4_NewRad */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_ML_CCZ4_ParamCheck 
#define DECLARE_CCTK_ARGUMENTS_ML_CCZ4_ParamCheck \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end ML_CCZ4_ParamCheck */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_ML_CCZ4_ParamCompat 
#define DECLARE_CCTK_ARGUMENTS_ML_CCZ4_ParamCompat \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end ML_CCZ4_ParamCompat */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_ML_CCZ4_RegisterConstrained 
#define DECLARE_CCTK_ARGUMENTS_ML_CCZ4_RegisterConstrained \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end ML_CCZ4_RegisterConstrained */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_ML_CCZ4_RegisterSlicing 
#define DECLARE_CCTK_ARGUMENTS_ML_CCZ4_RegisterSlicing \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end ML_CCZ4_RegisterSlicing */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_ML_CCZ4_SetGroupTags 
#define DECLARE_CCTK_ARGUMENTS_ML_CCZ4_SetGroupTags \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end ML_CCZ4_SetGroupTags */
#endif
#endif
#endif