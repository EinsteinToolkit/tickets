#ifndef CCTK_ARGUMENTS_CHECKED_H
#define CCTK_ARGUMENTS_CHECKED_H 1

/* needed for CCTK_ANSI_FPP */
#include "cctk_Types.h"

#ifdef CCODE
#define DECLARE_CCTK_ARGUMENTS_CHECKED(func) DECLARE_CCTK_ARGUMENTS_##func
#endif
#ifdef FCODE
#if CCTK_ANSI_FPP
#define DECLARE_CCTK_ARGUMENTS_CHECKED(func) DECLARE_CCTK_ARGUMENTS_##func
#else
#define DECLARE_CCTK_ARGUMENTS_CHECKED(func) DECLARE_CCTK_ARGUMENTS_/**/func
#endif
#endif

#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_Boundary_ApplyPhysicalBCs 
#define DECLARE_CCTK_ARGUMENTS_Boundary_ApplyPhysicalBCs \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end Boundary_ApplyPhysicalBCs */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_Boundary_Check 
#define DECLARE_CCTK_ARGUMENTS_Boundary_Check \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end Boundary_Check */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_Boundary_ClearSelection 
#define DECLARE_CCTK_ARGUMENTS_Boundary_ClearSelection \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end Boundary_ClearSelection */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_Boundary_RegisterBCs 
#define DECLARE_CCTK_ARGUMENTS_Boundary_RegisterBCs \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end Boundary_RegisterBCs */
#endif
#endif
#endif