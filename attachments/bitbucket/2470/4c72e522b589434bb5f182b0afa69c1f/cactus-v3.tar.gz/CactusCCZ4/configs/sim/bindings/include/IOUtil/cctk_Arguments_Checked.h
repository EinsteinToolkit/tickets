#ifndef CCTK_ARGUMENTS_CHECKED_H
#define CCTK_ARGUMENTS_CHECKED_H 1

/* needed for CCTK_ANSI_FPP */
#include "cctk_Types.h"

#ifdef CCODE
#define DECLARE_CCTK_ARGUMENTS_CHECKED(func) DECLARE_CCTK_ARGUMENTS_##func
#endif
#ifdef FCODE
#if CCTK_ANSI_FPP
#define DECLARE_CCTK_ARGUMENTS_CHECKED(func) DECLARE_CCTK_ARGUMENTS_##func
#else
#define DECLARE_CCTK_ARGUMENTS_CHECKED(func) DECLARE_CCTK_ARGUMENTS_/**/func
#endif
#endif

#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_IOUtil_RecoverGH 
#define DECLARE_CCTK_ARGUMENTS_IOUtil_RecoverGH \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end IOUtil_RecoverGH */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_IOUtil_RecoverIDFromDatafiles 
#define DECLARE_CCTK_ARGUMENTS_IOUtil_RecoverIDFromDatafiles \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end IOUtil_RecoverIDFromDatafiles */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_IOUtil_Startup 
#define DECLARE_CCTK_ARGUMENTS_IOUtil_Startup \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end IOUtil_Startup */
#endif
#endif
#ifdef CCODE 
#ifndef DECLARE_CCTK_ARGUMENTS_IOUtil_UpdateParFile 
#define DECLARE_CCTK_ARGUMENTS_IOUtil_UpdateParFile \
  _DECLARE_CCTK_ARGUMENTS; \
  /* end IOUtil_UpdateParFile */
#endif
#endif
#endif