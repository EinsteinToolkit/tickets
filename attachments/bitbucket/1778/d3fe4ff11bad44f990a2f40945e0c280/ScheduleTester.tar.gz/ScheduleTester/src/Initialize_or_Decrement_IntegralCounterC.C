#include "cctk.h"
#include "cctk_Parameters.h"
#include "cctk_Arguments.h"
#include "util_Table.h"
#include <assert.h>
#include <math.h>
#include <stdlib.h>

void InitializeCounter(CCTK_ARGUMENTS)
{
  DECLARE_CCTK_ARGUMENTS;
  DECLARE_CCTK_PARAMETERS;
  
  printf("HEY setting stuff here\n");
  printf("HEY setting stuff here %d\n",NumIterations);
  *SchedTestCounter = NumIterations;
  printf("HEY setting stuff here %d %d\n",*SchedTestCounter,NumIterations);
}

void DecrementCounter(CCTK_ARGUMENTS)
{
  DECLARE_CCTK_ARGUMENTS;
  DECLARE_CCTK_PARAMETERS;

    (*SchedTestCounter)--;
}
