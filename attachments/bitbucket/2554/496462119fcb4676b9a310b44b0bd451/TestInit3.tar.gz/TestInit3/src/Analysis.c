#include <string.h>
#include <math.h>
#include <stdio.h>
#include "cctk.h"
#include "cctk_Parameters.h"
#include "cctk_Arguments.h"

void TestInit3_TestForNans(CCTK_ARGUMENTS);

void TestInit3_TestForNans(CCTK_ARGUMENTS)
{
  // The following two macros ensure that our function can "see" the appropriate
  // gridfunctions and paramters.
  DECLARE_CCTK_ARGUMENTS;
  DECLARE_CCTK_PARAMETERS;

# ifdef _OPENMP
#   pragma omp parallel for
# endif	
  /* Loop over all interior (non-ghostzone) points */
  for (int k = 0; k < cctk_lsh[2]; k++)
  {
    for (int j = 0; j < cctk_lsh[1]; j++)
    {
      for (int i = 0; i < cctk_lsh[0]; i++)
      {
        const int ijk = CCTK_GFINDEX3D(cctkGH, i, j, k);

        nanp[ijk] = isfinite(simple_p[ijk]) ? 0.0 : 1.0;
        nanpp[ijk] = isfinite(simple_p_p[ijk]) ? 0.0 : 1.0;

      }
    }
  }
}
