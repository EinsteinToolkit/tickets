#include "cctk.h"
#include "cctk_Arguments.h"
#include "cctk_Parameters.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void TestInit3_Initialize(CCTK_ARGUMENTS);

void TestInit3_Initialize(CCTK_ARGUMENTS)
{
  DECLARE_CCTK_ARGUMENTS;
  DECLARE_CCTK_PARAMETERS;

  /* Loop over all points (ghostzones included) */
  for (int k = 0; k < cctk_lsh[2]; k++)
  {
    for (int j = 0; j < cctk_lsh[1]; j++)
    {
      for (int i = 0; i < cctk_lsh[0]; i++)
      {
        const size_t ijk = CCTK_GFINDEX3D(cctkGH, i, j, k);
        simple[ijk] = 10.0;
      }
    }
  }
}
