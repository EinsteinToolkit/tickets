#include "cctk.h"
#include <string.h>
#include <math.h>
#include <stdio.h>
#include "cctk_Parameters.h"
#include "cctk_Arguments.h"

#define MAX(x, y) ((x) > (y) ? (x) : (y))

void TestInit3_RHS_Interior(CCTK_ARGUMENTS);

void TestInit3_RHS_Interior(CCTK_ARGUMENTS)
{
  DECLARE_CCTK_ARGUMENTS;
  DECLARE_CCTK_PARAMETERS;

# ifdef _OPENMP
#   pragma omp parallel for
# endif	
  /* Loop over all points */
  for (int k = 0; k < cctk_lsh[2]; k++)
  {
    for (int j = 0; j < cctk_lsh[1]; j++)
    {
      for (int i = 0; i < cctk_lsh[0]; i++)
      {
        const int ijk = CCTK_GFINDEX3D(cctkGH, i, j, k);
        dotsimple[ijk] = 0.0;
      }
    }
  }
}
