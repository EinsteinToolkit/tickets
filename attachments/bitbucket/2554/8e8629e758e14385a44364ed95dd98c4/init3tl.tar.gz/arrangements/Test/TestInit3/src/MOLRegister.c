#include "cctk.h"
#include <string.h>
#include <math.h>
#include <stdio.h>
#include "cctk_Parameters.h"
#include "cctk_Arguments.h"

void TestInit3_MoLRegister(CCTK_ARGUMENTS);

/* Let the Method-Of-Lines thorn know which variables are
 * evolved and which variables contain the RHS for those variables
 */
void TestInit3_MoLRegister(CCTK_ARGUMENTS)
{
  DECLARE_CCTK_ARGUMENTS;
  int err = 0;
  err += MoLRegisterEvolved(CCTK_VarIndex("TestInit3::simple"),
                            CCTK_VarIndex("TestInit3::dotsimple"));

  if (err)
  {
    CCTK_WARN(CCTK_WARN_ABORT, "error registering evolution system");
  }
}
