#!/bin/bash

set -e

perl -w Bsym.rpar

dirs=("x" "y" "z")
for d in ${dirs[*]} ; do
        for s in "0" "x" "y" "z" "xy" "xz" "yz" "rot180" "rot90" "zrot180" "zrot90" ; do
                if [ -r Bsym_w${d}_$s.par ] ; then
                        ./cactus_etk Bsym_w${d}_$s.par
                fi
        done
done

for d in ${dirs[*]} ; do
        for s in "0" "x" "y" "z" "xy" "xz" "yz" "rot180" "rot90" "zrot180" "zrot90" ; do
                if [ -r Bsym_w${d}_$s.par ] ; then
                        for i in "0" "1" "2" ; do
                                if [ "${dirs[$i]}" == "$d" ] || [ "$s" == "0" ] ; then
                                        continue
                                fi
                                echo "direction of wire: $d symmetry: $s, Bvec[$i]"
                                gawk 'function fabs(x){return x+0<0?-x+0:x+0} 
                                      /^(#|$)/{next} 
                                      {$10=-3.0+$10*0.2;$11=-3.0+$11*0.2;$12=-3.0+$12*0.2} 
                                      ARGIND==1{slurp[$6,$7,$8]=$0} 
                                      ARGIND==2{split(slurp[$6,$7,$8],a)
                                                curr=fabs($13-a[13])
                                                if(curr>=max) {
                                                        max=curr
                                                        maxline1=$0
                                                        maxline2=slurp[$6,$7,$8]
                                                }
                                      } 
                                      END{print "nosym:",maxline1
                                          print "sym:",maxline2
                                          print "max. abs. difference",max
                                      }
                                      ' Bsym_w${d}_0/parrays3d\[$i\].xyz.asc Bsym_w${d}_$s/parrays3d\[$i\].xyz.asc
                        done
                fi
        done
done
