#include <math.h>

#include "cctk.h"
#include "cctk_Arguments.h"
#include "cctk_Parameters.h"

void WaveToyMoL_FakeMotion(CCTK_ARGUMENTS)
{
  DECLARE_CCTK_PARAMETERS;
  DECLARE_CCTK_ARGUMENTS;

  const CCTK_REAL xc = r_orbit * cos(omega_orbit * cctk_time);
  const CCTK_REAL yc = r_orbit * sin(omega_orbit * cctk_time);
  const CCTK_REAL zc = 0.;

  active[0] = 1;
  num_levels[0] = 2;
  position_x[0] = xc;
  position_y[0] = yc;
  position_z[0] = zc;
  radius[1] = box_size[1];
  radius[2] = box_size[2];
}

static CCTK_REAL coeff[4][4][4] = {
  -0.524425, -0.417869, 0.691628, -0.695583, 0.171075, -0.613049, 0.621245, -0.652939, -0.0300336, 
  -0.696275, -0.266086, -0.016527, 0.820188, -0.469486, 0.786375, -0.559298, 0.263597, 0.142154, 
  -0.335685, -0.79109, 0.00586165, 0.134789, 0.708329, -0.919718, -0.783955, 0.278792, -0.973778, 
  0.440369, -0.796371, -0.03411, -0.491289, 0.353395, 0.793564, 0.519791, 0.440584, 0.815246, 
  0.857221, -0.244674, 0.799512, 0.55776, -0.351491, -0.611538, 0.991106, -0.677407, 0.416069, 
  0.00303812, 0.872602, 0.432647, -0.789619, -0.581591, 0.118793, 0.410864, -0.843533, 0.0210597, 
  -0.607605, -0.451578, 0.277205, -0.103584, -0.920256, -0.0654973, -0.844487, -0.923799, -0.679911, 
  -0.204336, 
};
void WaveToyMoL_PolyData(CCTK_ARGUMENTS)
{
  DECLARE_CCTK_PARAMETERS;
  DECLARE_CCTK_ARGUMENTS;

  CCTK_REAL delta = CCTK_DELTA_SPACE(0);
  for(int i = 0; i < cctk_lsh[0]*cctk_lsh[1]*cctk_lsh[2]; ++i)
  {
    CCTK_REAL xL = x[i], yL = y[i], zL = z[i];

    CCTK_REAL poly = 0;
    for(int ii = 0,fi=1 ; ii <= 3 ; ++ii,fi*=ii)
    for(int jj = 0,fj=1 ; jj <= 3 ; ++jj,fj*=jj)
    for(int kk = 0,fk=1 ; kk <= 3 ; ++kk,fk*=kk)
      poly += coeff[ii][jj][kk] * pow(xL,ii)/fi * pow(yL,jj)/fj * pow(zL,kk)/fk;


    phi[i] = delta*poly;
  }
}
void WaveToyMoL_PolyDataSub(CCTK_ARGUMENTS)
{
  DECLARE_CCTK_PARAMETERS;
  DECLARE_CCTK_ARGUMENTS;

  CCTK_REAL delta = CCTK_DELTA_SPACE(0)/2;
  for(int i = 0; i < cctk_lsh[0]*cctk_lsh[1]*cctk_lsh[2]; ++i)
  {
    CCTK_REAL xL = x[i], yL = y[i], zL = z[i];

    CCTK_REAL poly = 0;
    for(int ii = 0,fi=1 ; ii <= 3 ; ++ii,fi*=ii)
    for(int jj = 0,fj=1 ; jj <= 3 ; ++jj,fj*=jj)
    for(int kk = 0,fk=1 ; kk <= 3 ; ++kk,fk*=kk)
      poly += coeff[ii][jj][kk] * pow(xL,ii)/fi * pow(yL,jj)/fj * pow(zL,kk)/fk;


    psi[i] = fabs((phi[i] - delta*poly) / (delta*poly));
  }
}
