#! /usr/bin/env perl

my %ODE;
# each entry of %ODE is a reference to a list describing single ODE stepper.
# elements of the lists:
# ode_method
# MoL_Intermediate_Steps
# MoL_Num_Scratch_Levels
# RHSexpression
# RHSSlowexpression - empty if no slow evolution
# evolve_grid_function (0/1)
# evolve_grid_array (0/1)
$ODE{"RK4"} = [
  "rk4", 4,1, "t**3", "", 1,1
];
$ODE{"RK3"} = [
  "rk3", 3,1, "t**3", "", 1,1
];
$ODE{"RK2"} = [
  "rk2", 2,1, "t", "", 1,1
];
$ODE{"ICN"} = [
  "icn", 3,0, "t", "", 1,1
];
$ODE{"ICN-avg"} = [
  "icn-avg", 3,0, "1", "", 1,1
];
$ODE{"RK45"} = [
  "rk45", 6,6, "t**4", "", 1,0
];
$ODE{"RK45CK"} = [
  "rk45ck", 6,6, "t**4", "", 1,0
];
$ODE{"RK65"} = [
  "rk65", 8,8, "t**5", "", 1,0
];
$ODE{"RK87"} = [
  "rk87", 13,13, "t**7", "", 1,0
];
$ODE{"RK4-RK2"} = [
  "rk4-rk2", 4,1, "t**3", "t", 1,0
];
$ODE{"RK2-MR-2-1"} = [
  "rk2-mr-2:1", 5,5, "t", "t", 1,0
];
$ODE{"RK4-MR-2-1"} = [
  "rk4-mr-2:1", 10,10, "t**3", "t**3", 1,0
];

foreach my $name (keys %ODE) {
  my ($ode_method, $MoL_Intermediate_Steps, $MoL_Num_Scratch_Levels,
      $RHSexpression, $RHSSlowexpression, $evolve_grid_function,
      $evolve_grid_array) = @{$ODE{$name}};

  # construct a list of output variables
  # for multi rate methods include both slow and fast grid functions
  @gfs = ('TestMoL::analytic_gf', 'TestMoL::diff_gf',
          'TestMoL::evolved_gf', 'TestMoL::constrained_gf',
          'TestMoL::sandr_gf');
  @slowgfs = ('TestMoL::analyticslow_gf', 'TestMoL::diffslow_gf',
              'TestMoL::evolvedslow_gf');
  push (@gfs, @slowgfs) if $RHSSlowexpression;
  @gas = ('TestMoL::analytic_ga', 'TestMoL::diff_ga',
          'TestMoL::evolved_ga', 'TestMoL::constrained_ga',
          'TestMoL::sandr_ga');

  $out_vars = "";
  $out_vars = join "\n        ",($out_vars, @gfs) if $evolve_grid_function;
  $out_vars = join "\n        ",($out_vars, @gas) if $evolve_grid_array;

  # norm of the difference to the analytic solution
  $out_norms = "";
  if($evolve_grid_function) {
    $out_norms = join "\n        ",($out_norms, "TestMoL::diff_gf");
  }
  if($evolve_grid_function and $RHSSlowexpression) {
    $out_norms = join "\n        ",($out_norms, "TestMoL::diffslow_gf");
  }
  if($evolve_grid_array) {
    $out_norms = join "\n        ",($out_norms, "TestMoL::diff_ga");
  }

  # $RHSSlowexpression is unset unless a multi-rate method is used
  # however we need to provide some value for the parfile parser
  if (not $RHSslowexpression) {
    $RHSslowexpression = "1"; # provide a dummy expression
  }

  $lines = <<EOF;
# !DESC verify convergence order of ODE steppers inside of MoL
# Do not modify this file by hand, instead modify ODEs.pl and regenerate this
# file.
ActiveThorns = "
        IOASCII
        IOBasic
        IOUtil
        LocalReduce
        MoL
        PUGH
        PUGHReduce
        PUGHSlab
        TestMoL
"

Cactus::terminate = "iteration"
Cactus::cctk_itlast = 3
PUGH::global_nx = 1
PUGH::global_ny = 1
PUGH::global_nz = 10

MoL::ode_method = "$ode_method"
MoL::MoL_Intermediate_Steps = $MoL_Intermediate_Steps
MoL::MoL_Num_Scratch_Levels = $MoL_Num_Scratch_Levels

TestMoL::RHSexpression = "$RHSexpression"
TestMoL::RHSSlowexpression = "$RHSslowexpression"
TestMoL::evolve_grid_function = $evolve_grid_function
TestMoL::evolve_grid_array = $evolve_grid_array

IO::out_dir			= \$parfile
IO::out_fileinfo                = "none"
IO::parfile_write               = "no"

IOASCII::out1D_every = 1
IOASCII::out1D_d = "no"
IOASCII::out1D_x = "yes"
IOASCII::out1D_y = "no"
IOASCII::out1D_z = "no"
IOASCII::out1D_vars  = "$out_vars"

IOBasic::outScalar_every = 1
IOBasic::outScalar_reductions = "norm_inf"
IOBasic::outScalar_vars  = "$out_norms"
EOF

  open($fh, ">", "$name.par");
  print $fh $lines;
  close $fh;
}
