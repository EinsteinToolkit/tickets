
 /*@@
   @file      RKIMEX3.c
   @date      Jan 2011
   @author    Daniela Alic
   @desc 
   RKIMEX following Pareschi and Russo, 2005  
   (J.Sci.Comput.,25,112)
   @enddesc 
   @version   $Header: /cactusdevcvs/CactusBase/MoL/src/RKIMEX3.c,v 1.5 2008/09/23 15:46:30 schnetter Exp $
 @@*/

#include "cctk.h"
#include "cctk_Arguments.h"
#include "cctk_Parameters.h"

#include <stdio.h>
#include <math.h>
#include "ExternalVariables.h"

static const char *rcsid = "$Header: /cactusdevcvs/CactusBase/MoL/src/RKIMEX3.c,v 1.5 2008/09/23 15:46:30 schnetter Exp $";

CCTK_FILEVERSION(CactusBase_MoL_RKIMEX3_c);

/********************************************************************
 *********************     Local Data Types   ***********************
 ********************************************************************/

/********************************************************************
 ********************* Local Routine Prototypes *********************
 ********************************************************************/

/********************************************************************
 ***************** Scheduled Routine Prototypes *********************
 ********************************************************************/

void MoL_RKIMEX3Add(CCTK_ARGUMENTS);

/********************************************************************
 ********************* Other Routine Prototypes *********************
 ********************************************************************/

/********************************************************************
 *********************     Local Data   *****************************
 ********************************************************************/

/********************************************************************
 *********************     External Routines   **********************
 ********************************************************************/

 /*@@
   @routine    MoL_RKIMEX3Add
   @date       
   @author     
   @desc 
   Performs a single step of a RKIMEX3 type time
   integration.
   @enddesc 
   @calls     
   @calledby   
   @history 
 
   @endhistory 

@@*/

void MoL_RKIMEX3Add(CCTK_ARGUMENTS)
{

  DECLARE_CCTK_ARGUMENTS;
  DECLARE_CCTK_PARAMETERS;
    
  cGroupDynamicData arraydata;
  CCTK_INT groupindex, ierr;
  CCTK_INT arraytotalsize, arraydim;

  CCTK_INT index, var, var2, scratchstep, scratchindex;
  CCTK_INT totalsize;
  CCTK_REAL impl;
  CCTK_REAL * restrict UpdateVar;
  CCTK_REAL * restrict OldVar;
  CCTK_REAL const * restrict RHSVar;
  CCTK_REAL const * restrict RHS2Var;
  CCTK_REAL * restrict Scratch2Var;
  CCTK_REAL impl_array[6][6];
  CCTK_REAL c_old[6];
  CCTK_REAL c_prev[6];
  CCTK_REAL c_flux[6];
  CCTK_REAL cold, cprev, cflux;

  CCTK_INT arrayscratchlocation;

  totalsize = 1;
  for (arraydim = 0; arraydim < cctk_dim; arraydim++)
  {
    totalsize *= cctk_lsh[arraydim];
  }

  char real_str[50];  // Buffer to hold string
  CCTK_REAL value;
  value =  (*Original_Delta_Time) / cctkGH->cctk_timefac;
  snprintf(real_str, sizeof(real_str), "%.19g", value); // Convert value to a string and place it in real_str

  CCTK_ParameterSet("RKtime", "MoL", real_str); 

  CCTK_REAL m13, m14, m16, m23, m34, ma, mb, me, m22, m33, m31, m32;

  m13 = 1.0/3.0;
  m14 = 1.0/4.0;
  m16 = 1.0/6.0;
  m23 = 2.0/3.0;
  m34 = 3.0/4.0;
  ma  = 0.24169426078821;
  mb  = 0.06042356519705;
  me  = 0.12915286960590;

 /* coefficients for RK3 type 1 */

  if (RKIMEX_type==1) 
  {
    char ma_str[50]; 
    snprintf(ma_str, sizeof(ma_str), "%.19g", ma); 

    switch (MoL_Intermediate_Steps - (*MoL_Intermediate_Step))
    {
      case 0:
      CCTK_ParameterSet("RKStiff", "MoL", ma_str);
      break;
      case 1:
      CCTK_ParameterSet("RKStiff", "MoL", ma_str);
      break;
      case 2:
      CCTK_ParameterSet("RKStiff", "MoL", ma_str);
      break;
      case 3:
      CCTK_ParameterSet("RKStiff", "MoL", ma_str);
      break;
      case 4:
      CCTK_ParameterSet("RKStiff", "MoL", "0.0");
      break;
      case 5:
      CCTK_ParameterSet("RKStiff", "MoL", "0.0");
    }

    m22 = 1.0 - ma;
    m33 = 0.5 - mb - me - ma;

    c_old[0]  = 1.0; c_old[1]  = 1.0; c_old[2]  = 1.0; c_old[3]  = m34; c_old[4]  = m13; c_old[5]  = 0.0;
    c_prev[0] = 0.0; c_prev[1] = 0.0; c_prev[2] = 0.0; c_prev[3] = m14; c_prev[4] = m23; c_prev[5] = 1.0;
    c_flux[0] = 0.0; c_flux[1] = 0.0; c_flux[2] = 1.0; c_flux[3] = m14; c_flux[4] = m23; c_flux[5] = 0.0;

    impl_array[0][0] = 0.0; impl_array[0][1] = 0.0;    impl_array[0][2] = 0.0;        impl_array[0][3] = 0.0;         impl_array[0][4] = 0.0;        impl_array[0][5] = 0.0;
    impl_array[1][0] = 0.0; impl_array[1][1] =-ma;     impl_array[1][2] = 0.0;        impl_array[1][3] = 0.0;         impl_array[1][4] = 0.0;        impl_array[1][5] = 0.0;
    impl_array[2][0] = 0.0; impl_array[2][1] = 0.0;    impl_array[2][2] = m22;        impl_array[2][3] = 0.0;         impl_array[2][4] = 0.0;        impl_array[2][5] = 0.0;
    impl_array[3][0] = 0.0; impl_array[3][1] = mb;     impl_array[3][2] = me-m14*m22; impl_array[3][3] = m33-m14*ma;  impl_array[3][4] = 0.0;        impl_array[3][5] = 0.0;
    impl_array[4][0] = 0.0; impl_array[4][1] =-m23*mb; impl_array[4][2] = m16-m23*me; impl_array[4][3] = m16-m23*m33; impl_array[4][4] = m23-m23*ma; impl_array[4][5] = 0.0;
    impl_array[5][0] = 0.0; impl_array[5][1] = 0.0;    impl_array[5][2] = 0.0;        impl_array[5][3] = 0.0;         impl_array[5][4] = 0.0;        impl_array[5][5] = 0.0;
  }

 /* coefficients for RK3 type 2 */

  if (RKIMEX_type==2) 
  {
    char m13_str[50]; 
    snprintf(m13_str, sizeof(m13_str), "%.19g", m13); 
    char m16_str[50]; 
    snprintf(m16_str, sizeof(m16_str), "%.19g", m16); 

    switch (MoL_Intermediate_Steps - (*MoL_Intermediate_Step))
    {
      case 0:
      CCTK_ParameterSet("RKStiff", "MoL", m13_str);
      break;
      case 1:
      CCTK_ParameterSet("RKStiff", "MoL", m13_str);
      break;
      case 2:
      CCTK_ParameterSet("RKStiff", "MoL", m13_str);
      break;
      case 3:
      CCTK_ParameterSet("RKStiff", "MoL", m13_str);
      break;
      case 4:
      CCTK_ParameterSet("RKStiff", "MoL", m16_str);
      break;
      case 5:
      CCTK_ParameterSet("RKStiff", "MoL", "0.0");
    }

    m22 = 1.0 - m13;
    m33 = 0.5 - mb - me - ma;
    m31 = 3.0*(2.0/9.0 + m23 - 1.0)/8.0;
    m32 = 3.0*(- 4.0/9.0 + 1.0)/8.0;

    c_old[0]  = 1.0; c_old[1]  = 1.0; c_old[2]  = 1.0; c_old[3]  = m34; c_old[4]  = m13; c_old[5]  = 0.0;
    c_prev[0] = 0.0; c_prev[1] = 0.0; c_prev[2] = 0.0; c_prev[3] = m14; c_prev[4] = m23; c_prev[5] = 1.0;
    c_flux[0] = 0.0; c_flux[1] = 0.0; c_flux[2] = 1.0; c_flux[3] = m14; c_flux[4] = m23; c_flux[5] = 0.0;

    impl_array[0][0] = 0.0; impl_array[0][1] = 0.0;     impl_array[0][2] = 0.0;         impl_array[0][3] = 0.0;      impl_array[0][4] = 0.0;     impl_array[0][5] = 0.0;
    impl_array[1][0] = 0.0; impl_array[1][1] =-m13;     impl_array[1][2] = 0.0;         impl_array[1][3] = 0.0;      impl_array[1][4] = 0.0;     impl_array[1][5] = 0.0;
    impl_array[2][0] = 0.0; impl_array[2][1] = 0.0;     impl_array[2][2] = m22;         impl_array[2][3] = 0.0;      impl_array[2][4] = 0.0;     impl_array[2][5] = 0.0;
    impl_array[3][0] = 0.0; impl_array[3][1] = m31;     impl_array[3][2] = m32-m14*m22; impl_array[3][3] = -m13*m14; impl_array[3][4] = 0.0;     impl_array[3][5] = 0.0;
    impl_array[4][0] = 0.0; impl_array[4][1] =-m23*m31; impl_array[4][2] = m16-m23*m32; impl_array[4][3] = 0.0;      impl_array[4][4] = m23*m23; impl_array[4][5] = 0.0;
    impl_array[5][0] = 0.0; impl_array[5][1] = 0.0;     impl_array[5][2] = 0.0;         impl_array[5][3] = 0.0;      impl_array[5][4] = 0.0;     impl_array[5][5] = 0.0;
  }

  /* Real GFs */

  for (var = 0, var2 = 0; var < MoLNumEvolvedVariables; var++, var2++)
  {
    int const has_implicit_rhs = RHS2VariableIndex[var] != -1;
    if (! has_implicit_rhs) var2--;
    
    const CCTK_REAL tmp = (*Original_Delta_Time) / cctkGH->cctk_timefac;

    int const offset = (MoL_Num_Evolved_Implicit_Vars)*(MoL_Intermediate_Steps - (*MoL_Intermediate_Step));

    if (has_implicit_rhs)
    {
      RHS2Var = (CCTK_REAL const *)CCTK_VarDataPtrI(cctkGH, 0, RHS2VariableIndex[var]);

      Scratch2Var = (CCTK_REAL*)CCTK_VarDataPtrI(cctkGH, 0, 
						 CCTK_FirstVarIndex("MOL::SCRATCHSPACE")
						 + var2
						 + offset);

      #pragma omp parallel for
      for (index = 0; index < totalsize; index++)
      {
        Scratch2Var[index] = tmp * RHS2Var[index]; 
      }
    }
    else
    {
      RHS2Var = NULL;
      Scratch2Var = NULL;
    }

  } /* for var */
  if (var2 != MoLNumEvolvedImplicitVariables)
  {
    CCTK_WARN (0, "counting error");
  }

  for (var = 0, var2 = 0; var < MoLNumEvolvedVariables; var++, var2++)
  {
    int const has_implicit_rhs = RHS2VariableIndex[var] != -1;
    if (! has_implicit_rhs) var2--;
    
    UpdateVar = (CCTK_REAL *)CCTK_VarDataPtrI(cctkGH, 0, 
					      EvolvedVariableIndex[var]);
    OldVar = (CCTK_REAL *)CCTK_VarDataPtrI(cctkGH, 1, 
					   EvolvedVariableIndex[var]);
    RHSVar = (CCTK_REAL const *)CCTK_VarDataPtrI(cctkGH, 0, 
                                                 RHSVariableIndex[var]);

    const CCTK_REAL tmp = (*Original_Delta_Time) / cctkGH->cctk_timefac;
  
    cold  = c_old[MoL_Intermediate_Steps - (*MoL_Intermediate_Step)];
    cprev = c_prev[MoL_Intermediate_Steps - (*MoL_Intermediate_Step)];
    cflux = c_flux[MoL_Intermediate_Steps - (*MoL_Intermediate_Step)];    

    #pragma omp parallel for
    for (index = 0; index < totalsize; index++)
    {
      UpdateVar[index] = cold*OldVar[index] + cprev*UpdateVar[index] + cflux*tmp*RHSVar[index];
    }

    if (has_implicit_rhs)
    { 
     for (scratchstep = 0; 
	 scratchstep < MoL_Intermediate_Steps - (*MoL_Intermediate_Step) + 1;
	 scratchstep++)
     {
       int const offset = MoL_Num_Evolved_Implicit_Vars*scratchstep;

       Scratch2Var = (CCTK_REAL*)CCTK_VarDataPtrI(cctkGH, 0, 
						   CCTK_FirstVarIndex("MOL::SCRATCHSPACE")
						   + var2
						   + offset);

       impl = impl_array[MoL_Intermediate_Steps - (*MoL_Intermediate_Step)][scratchstep];

       #pragma omp parallel for
       for (index = 0; index < totalsize; index++)
       {
	 UpdateVar[index] += impl * Scratch2Var[index];
       }
     } /* for scratchstep */
    } /* for if implicit rhs */
  } /* for var */

  if (var2 != MoLNumEvolvedImplicitVariables)
  {
    CCTK_WARN (0, "counting error");
  }
    
  return;
}





