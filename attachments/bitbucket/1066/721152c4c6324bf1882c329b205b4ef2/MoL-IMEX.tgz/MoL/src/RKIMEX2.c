
 /*@@
   @file      RKIMEX2.c
   @date      Dec 2009
   @author    Daniela Alic and Ian Hawke
   @desc 
   RKIMEX following Pareschi and Russo, 2005  
   (J.Sci.Comput.,25,112)
   @enddesc 
   @version   $Header: /cactusdevcvs/CactusBase/MoL/src/RKIMEX2.c,v 1.5 2008/09/23 15:46:30 schnetter Exp $
 @@*/

#include "cctk.h"
#include "cctk_Arguments.h"
#include "cctk_Parameters.h"

#include <stdio.h>
#include <math.h>
#include "ExternalVariables.h"

static const char *rcsid = "$Header: /cactusdevcvs/CactusBase/MoL/src/RKIMEX2.c,v 1.5 2008/09/23 15:46:30 schnetter Exp $";

CCTK_FILEVERSION(CactusBase_MoL_RKIMEX2_c);

/********************************************************************
 *********************     Local Data Types   ***********************
 ********************************************************************/

/********************************************************************
 ********************* Local Routine Prototypes *********************
 ********************************************************************/

/********************************************************************
 ***************** Scheduled Routine Prototypes *********************
 ********************************************************************/

void MoL_RKIMEX2Add(CCTK_ARGUMENTS);

/********************************************************************
 ********************* Other Routine Prototypes *********************
 ********************************************************************/

/********************************************************************
 *********************     Local Data   *****************************
 ********************************************************************/

/********************************************************************
 *********************     External Routines   **********************
 ********************************************************************/

 /*@@
   @routine    MoL_RKIMEX2Add
   @date       
   @author     
   @desc 
   Performs a single step of a RKIMEX2 type time
   integration.
   @enddesc 
   @calls     
   @calledby   
   @history 
 
   @endhistory 

@@*/

void MoL_RKIMEX2Add(CCTK_ARGUMENTS)
{

  DECLARE_CCTK_ARGUMENTS;
  DECLARE_CCTK_PARAMETERS;
    
  cGroupDynamicData arraydata;
  CCTK_INT groupindex, ierr;
  CCTK_INT arraytotalsize, arraydim;

  CCTK_INT index, var, var2, scratchstep, scratchindex;
  CCTK_INT totalsize;
  CCTK_REAL expl, impl;
  CCTK_REAL * restrict UpdateVar;
  CCTK_REAL * restrict OldVar;
  CCTK_REAL const * restrict RHSVar;
  CCTK_REAL const * restrict RHS2Var;
  CCTK_REAL * restrict ScratchVar;
  CCTK_REAL * restrict Scratch2Var;
  CCTK_REAL expl_array[4][4];
  CCTK_REAL impl_array[4][4];

  CCTK_INT arrayscratchlocation;

  totalsize = 1;
  for (arraydim = 0; arraydim < cctk_dim; arraydim++)
  {
    totalsize *= cctk_lsh[arraydim];
  }

  char real_str[50];  // Buffer to hold string
  CCTK_REAL value;
  value =  (*Original_Delta_Time) / cctkGH->cctk_timefac;
  snprintf(real_str, sizeof(real_str), "%.19g", value); // Convert value to a string and place it in real_str

  CCTK_ParameterSet("RKtime", "MoL", real_str); 

  CCTK_REAL m12, m13, m14, m16, m23, m11, m21;

  m12 = 1.0/2.0;
  m13 = 1.0/3.0;
  m14 = 1.0/4.0;
  m16 = 1.0/6.0;
  m23 = 2.0/3.0;

/* coefficients for RK2 type 1 */

  if (RKIMEX_type==1) 
  {
    char m14_str[50]; 
    char m13_str[50];
    snprintf(m14_str, sizeof(m14_str), "%.19g", m14);
    snprintf(m13_str, sizeof(m13_str), "%.19g", m13);

    switch (MoL_Intermediate_Steps - (*MoL_Intermediate_Step))
    {
      case 0:
      CCTK_ParameterSet("RKStiff", "MoL", m14_str);
      break;
      case 1:
      CCTK_ParameterSet("RKStiff", "MoL", m14_str);
      break;
      case 2:
      CCTK_ParameterSet("RKStiff", "MoL", m13_str);
      break;
      case 3:
      CCTK_ParameterSet("RKStiff", "MoL", "0.0");
    }

    expl_array[0][0] = 0.0; expl_array[0][1] = 0.0; expl_array[0][2] = 0.0; expl_array[0][3] = 0.0;
    expl_array[1][0] = 0.0; expl_array[1][1] = m12; expl_array[1][2] = 0.0; expl_array[1][3] = 0.0;
    expl_array[2][0] = 0.0; expl_array[2][1] = m12; expl_array[2][2] = m12; expl_array[2][3] = 0.0;
    expl_array[3][0] = 0.0; expl_array[3][1] = m13; expl_array[3][2] = m13; expl_array[3][3] = m13;

    impl_array[0][0] = 0.0; impl_array[0][1] = 0.0; impl_array[0][2] = 0.0; impl_array[0][3] = 0.0;
    impl_array[1][0] = 0.0; impl_array[1][1] = 0.0; impl_array[1][2] = 0.0; impl_array[1][3] = 0.0;
    impl_array[2][0] = 0.0; impl_array[2][1] = m13; impl_array[2][2] = m13; impl_array[2][3] = 0.0;
    impl_array[3][0] = 0.0; impl_array[3][1] = m13; impl_array[3][2] = m13; impl_array[3][3] = m13;
  }

 /* coefficients for RK2 type 2 */

  if (RKIMEX_type==2) 
  {
    CCTK_REAL gama;
    gama = 1.0 - 1.0 / sqrt(2.0);
    m11 = 1.0 - 2.0*gama; 
    m21 = 0.5 - gama;

    char gama_str[50];  // Buffer to hold string
    snprintf(gama_str, sizeof(gama_str), "%.19g", gama); // Convert gama to a string and place it in gama_str

    switch (MoL_Intermediate_Steps - (*MoL_Intermediate_Step))
    {
      case 0:
      CCTK_ParameterSet("RKStiff", "MoL", gama_str);
      break;
      case 1:
      CCTK_ParameterSet("RKStiff", "MoL", gama_str);
      break;
      case 2:
      CCTK_ParameterSet("RKStiff", "MoL", gama_str);
      break;
      case 3:
      CCTK_ParameterSet("RKStiff", "MoL", "0.0");
    }

    expl_array[0][0] = 0.0; expl_array[0][1] = 0.0; expl_array[0][2] = 0.0; expl_array[0][3] = 0.0;
    expl_array[1][0] = 0.0; expl_array[1][1] = 1.0; expl_array[1][2] = 0.0; expl_array[1][3] = 0.0;
    expl_array[2][0] = 0.0; expl_array[2][1] = m14; expl_array[2][2] = m14; expl_array[2][3] = 0.0;
    expl_array[3][0] = 0.0; expl_array[3][1] = m16; expl_array[3][2] = m16; expl_array[3][3] = m23;

    impl_array[0][0] = 0.0; impl_array[0][1] = 0.0; impl_array[0][2] = 0.0; impl_array[0][3] = 0.0;
    impl_array[1][0] = 0.0; impl_array[1][1] = m11; impl_array[1][2] = 0.0; impl_array[1][3] = 0.0;
    impl_array[2][0] = 0.0; impl_array[2][1] = m21; impl_array[2][2] = 0.0; impl_array[2][3] = 0.0;
    impl_array[3][0] = 0.0; impl_array[3][1] = m16; impl_array[3][2] = m16; impl_array[3][3] = m23;
  }

  /* Real GFs */

  for (var = 0, var2 = 0; var < MoLNumEvolvedVariables; var++, var2++)
  {
    int const has_implicit_rhs = RHS2VariableIndex[var] != -1;
    if (! has_implicit_rhs) var2--;
   
    const CCTK_REAL tmp = (*Original_Delta_Time) / cctkGH->cctk_timefac;

    UpdateVar = (CCTK_REAL *)CCTK_VarDataPtrI(cctkGH, 0, 
                                              EvolvedVariableIndex[var]);
    RHSVar = (CCTK_REAL const *)CCTK_VarDataPtrI(cctkGH, 0, 
                                                 RHSVariableIndex[var]);
    if (has_implicit_rhs)
    {
      RHS2Var = (CCTK_REAL const *)CCTK_VarDataPtrI(cctkGH, 0, 
                                                    RHS2VariableIndex[var]);
    }
    else
    {
      RHS2Var = NULL;
    }

    int const offset =
        (MoL_Num_Evolved_Vars + MoL_Num_Evolved_Implicit_Vars)
      * (MoL_Intermediate_Steps - (*MoL_Intermediate_Step));
    
    ScratchVar = (CCTK_REAL*)CCTK_VarDataPtrI(cctkGH, 0, 
					      CCTK_FirstVarIndex("MOL::SCRATCHSPACE")
					      + var 
					      + offset);

    if (has_implicit_rhs)
    {
      Scratch2Var = (CCTK_REAL*)CCTK_VarDataPtrI(cctkGH, 0, 
						 CCTK_FirstVarIndex("MOL::SCRATCHSPACE")
						 + MoL_Num_Evolved_Vars + var2
						 + offset);
    }
    else
    {
      Scratch2Var = NULL;
    }

    #pragma omp parallel for
    for (index = 0; index < totalsize; index++)
    {
      ScratchVar[index] = tmp * RHSVar[index];
    }

    if (has_implicit_rhs)
    {
      #pragma omp parallel for
      for (index = 0; index < totalsize; index++)
      {
        Scratch2Var[index] = tmp * RHS2Var[index]; 
      }
    }
     
  } /* for var */
  if (var2 != MoLNumEvolvedImplicitVariables)
  {
    CCTK_WARN (0, "counting error");
  }

  for (var = 0, var2 = 0; var < MoLNumEvolvedVariables; var++, var2++)
  {
    int const has_implicit_rhs = RHS2VariableIndex[var] != -1;
    if (! has_implicit_rhs) var2--;
    
    UpdateVar = (CCTK_REAL *)CCTK_VarDataPtrI(cctkGH, 0, 
                                              EvolvedVariableIndex[var]);
    OldVar = (CCTK_REAL *)CCTK_VarDataPtrI(cctkGH, 1, 
                                           EvolvedVariableIndex[var]);
     
    #pragma omp parallel for
    for (index = 0; index < totalsize; index++)
    {
      UpdateVar[index] = OldVar[index];
    }

    for (scratchstep = 0; 
         scratchstep < MoL_Intermediate_Steps - (*MoL_Intermediate_Step) + 1;
         scratchstep++)
    { 
      int const offset = (MoL_Num_Evolved_Vars + MoL_Num_Evolved_Implicit_Vars)*scratchstep;  
  
      ScratchVar = (CCTK_REAL*)CCTK_VarDataPtrI(cctkGH, 0, 
						CCTK_FirstVarIndex("MOL::SCRATCHSPACE")
						+ var 
						+ offset);
      
      if (has_implicit_rhs)
      { 
	Scratch2Var = (CCTK_REAL*)CCTK_VarDataPtrI(cctkGH, 0, 
						   CCTK_FirstVarIndex("MOL::SCRATCHSPACE")
						   + MoL_Num_Evolved_Vars + var2
						   + offset);
      }
 
        expl = expl_array[MoL_Intermediate_Steps - (*MoL_Intermediate_Step)][scratchstep];
        impl = impl_array[MoL_Intermediate_Steps - (*MoL_Intermediate_Step)][scratchstep];

      if (has_implicit_rhs)
      {
        #pragma omp parallel for
        for (index = 0; index < totalsize; index++)
        {
          UpdateVar[index] += expl * ScratchVar[index] + impl * Scratch2Var[index];
        }
      }
      else
      {
        #pragma omp parallel for
	for (index = 0; index < totalsize; index++)
	{
	  UpdateVar[index] += expl * ScratchVar[index];
	}
      }

    } /* for scratchstep */
    
  } /* for var */
  if (var2 != MoLNumEvolvedImplicitVariables)
  {
    CCTK_WARN (0, "counting error");
  }
    
  return;
}




