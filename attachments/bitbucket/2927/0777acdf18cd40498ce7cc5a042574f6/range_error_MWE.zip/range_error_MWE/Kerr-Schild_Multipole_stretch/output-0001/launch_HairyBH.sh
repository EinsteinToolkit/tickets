#!/bin/sh

#SBATCH --job-name=Gallery
#SBATCH --time=0-00:30:00
##SBATCH --mem-per-cpu=3G

##SBATCH --error=error.log

# x86

#SBATCH --partition=dev-x86
#SBATCH --account=f202407872cpcaa2x
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=12

module load OpenMPI/5.0.3-GCC-13.3.0
module load hwloc/2.10.0-GCCcore-13.3.0
module load zlib/1.3.1-GCCcore-13.3.0
module load FFTW/3.3.10-GCC-13.3.0
module load OpenBLAS/0.3.27-GCC-13.3.0
module load HDF5/1.14.3-gompi-2024a
module load ScaLAPACK/2.2.0-gompi-2024a-fb


printenv


MYSCRIPTNAME=$(basename $(scontrol show job "$SLURM_JOB_ID" | awk -F= '/Command=/{print $2}'))
echo "Script name: $MYSCRIPTNAME."


#################
##### SETUP #####
#################

# Used values (not provided as options here for cluster)
nprocs=$SLURM_NPROCS
omp_num_t=${SLURM_CPUS_PER_TASK:=1}

et_exe=cactus_ET_test__x86__GCC-13.3.0__rangemod
et_exe=/home/$USER/Work/ET_test/Cactus/exe/$et_exe

custom_name=""

simtype="Gallery"

# Parameter file
parfiledir=/home/$USER/Work/ET_test/Simus/parfiles
parfiledir=$parfiledir/$simtype
parfile=Kerr-Schild_Multipole_stretch.par

# Name of simulation directory
if [[ -z $custom_name ]]
then 
	name="$(basename "$parfile" .par)"
else
	name=$custom_name
fi

parfile=$parfiledir/$parfile


#######################
##### DIRECTORIES #####
#######################

# we now set up the folder structure

# set simulation dir
simdir="/projects/F202407872CPCAA2/jnicoules/ET_test/Simus/$simtype"

# let's use the same conventions as simfactory for the folders
rundirstring='output-'   
checkptdir='checkpoints'

# if $simdir/$name does not exist, create the folder and checkptdir
if [ ! -d "${simdir}/${name}" ]; then
    mkdir ${simdir}/${name}
fi

if [ ! -d "${simdir}/${name}/${checkptdir}" ]; then
    mkdir ${simdir}/${name}/${checkptdir}
fi

# now we see what the last output-NNNN folder is, and set rundir to be the next one.
for i in {0000..9999}; do
    rundir=${simdir}/${name}/${rundirstring}${i}
    if [ ! -d "${rundir}" ]; then
        mkdir ${rundir}
        break
    fi
done

cp $SLURM_SUBMIT_DIR/$MYSCRIPTNAME $rundir
cd ${rundir}
echo "Running in ${rundir}"

export OMP_NUM_THREADS=${omp_num_t}
echo "OMP_NUM_THREADS: ${OMP_NUM_THREADS}"
echo 

# we finally launch the run
srun ${et_exe} -L 3 ${parfile} 1>${rundirstring}${i}.out 2>${rundirstring}${i}.err </dev/null

echo "Simulation finished for job ${SLURM_JOBID}."

exit 0


