#include <cctk.h>
#include <cctk_Arguments.h>
#include <cctk_Parameters.h>

#include <string.h>

void TestPar_PrintStrings (CCTK_ARGUMENTS)
{
  DECLARE_CCTK_ARGUMENTS;
  DECLARE_CCTK_PARAMETERS;
  
  /* Expected parameter values */
  char const* const goodvalue1 = "value";
  char const* const goodvalue2 = "\n        value\n";
  char const* const goodvalue3 = "\n        value\n        ";
  char const* const goodvalue4 = "\n                value\n";
  char const* const goodvalue5 = "\n        value\n                value\n";
  char const* const goodvalue6 = "\n        ";
  char const* const goodvalue7 = "";
  char const* const goodvalue8 = "";
  char const* const goodvalue9 = "";
  
  /* Output actual parameter values for debugging */
  CCTK_VInfo (CCTK_THORNSTRING, "String 1: \"%s\"", string1);
  CCTK_VInfo (CCTK_THORNSTRING, "String 2: \"%s\"", string2);
  CCTK_VInfo (CCTK_THORNSTRING, "String 3: \"%s\"", string3);
  CCTK_VInfo (CCTK_THORNSTRING, "String 4: \"%s\"", string4);
  CCTK_VInfo (CCTK_THORNSTRING, "String 5: \"%s\"", string5);
  CCTK_VInfo (CCTK_THORNSTRING, "String 6: \"%s\"", string6);
  CCTK_VInfo (CCTK_THORNSTRING, "String 7: \"%s\"", string7);
  CCTK_VInfo (CCTK_THORNSTRING, "String 8: \"%s\"", string8);
  CCTK_VInfo (CCTK_THORNSTRING, "String 9: \"%s\"", string9);
  
  /* Compare, and set the status variable */
  *status =
    strcmp(string1, goodvalue1) == 0 &&
    strcmp(string2, goodvalue2) == 0 &&
    strcmp(string3, goodvalue3) == 0 &&
    strcmp(string4, goodvalue4) == 0 &&
    strcmp(string5, goodvalue5) == 0 &&
    strcmp(string6, goodvalue6) == 0 &&
    strcmp(string7, goodvalue7) == 0 &&
    strcmp(string8, goodvalue8) == 0 &&
    strcmp(string9, goodvalue9) == 0;
  
  CCTK_VInfo (CCTK_THORNSTRING, "These values are %s",
              *status ? "correct" : "incorrect");
}
