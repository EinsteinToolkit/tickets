# run from within gnuplot with load "<...>"

# Define variables

dir1 = "../data/202602_RN01_hf40/"

filename = "procaevolve-gauss.x.xg::gc"
output_file = "gc_x_RN_subcycl.pdf"

# iteration
it0     = 0
it1     = 1
it2     = 20
it3     = 100
it4     = 150

plot_title = "Gc"
x_label = "x"
y_label = "Gc"

time0 = it0*0.05
time1 = it1*0.05
time2 = it2*0.05
time3 = it3*0.05
time4 = it4*0.05


file1 = dir1 . filename
#file2 = dir2 . filename

time0_str = sprintf("t = %.2f",time0)
time1_str = sprintf("t = %.2f",time1)
time2_str = sprintf("t = %.2f",time2)
time3_str = sprintf("t = %.2f",time3)
time4_str = sprintf("t = %.2f",time4)


# output terminal (PNG, PDF, or screen)
#set terminal qt
set terminal pdfcairo enhanced

# output file (if saving to a file)
set output output_file


# plot title and labels
#set title title_str
set xlabel x_label
set ylabel y_label

# set ranges for axes
set xrange [-1:20]
set yrange [1e-12:0.1]
set logscale y 10

# set grid, key, or other styles
set grid
#set key [position]

# function to plot
plot file1 using ($1):(abs($2)) index it0 title time0_str  w l, \
     file1 using ($1):(abs($2)) index it1 title time1_str  w l, \
     file1 using ($1):(abs($2)) index it2 title time2_str  w l, \
     file1 using ($1):(abs($2)) index it3 title time3_str  w l, \
     file1 using ($1):(abs($2)) index it4 title time4_str  w l, \

# flush output to write the file
set output
