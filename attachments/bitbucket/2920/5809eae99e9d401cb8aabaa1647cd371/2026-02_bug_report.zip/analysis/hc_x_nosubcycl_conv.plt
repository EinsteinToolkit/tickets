# run from within gnuplot with load "<...>"

# Define variables

dir1 = "../data/202602_RN01_nosubcycl_hf20/"
dir2 = "../data/202602_RN01_nosubcycl_hf40/"

filename = "leanbssnmol-ham.x.xg::hc"
output_file = "hc_x_RN_nosubcycl_conv.pdf"

# iteration
it0     = 400

plot_title = "Hc"
x_label = "x"
y_label = "Hc"

time0 = it0*0.025


file1 = dir1 . filename
file2 = dir2 . filename

time0_str = sprintf("t = %.2f",time0)


# output terminal (PNG, PDF, or screen)
#set terminal qt
set terminal pdfcairo enhanced

# output file (if saving to a file)
set output output_file


# plot title and labels
set title time0_str
set xlabel x_label
set ylabel y_label

# set ranges for axes
set xrange [0.1:120]
set yrange [1e-12:1]
set logscale x 10
set logscale y 10

# set grid, key, or other styles
set grid
#set key [position]

# function to plot
plot file1 using ($1):(abs($2)) index it0 title "lres"  w l, \
     file2 using ($1):(abs($2)*2**4) index it0*2 title "hres ord4"  w l, \
     #file2 using ($1):(abs($2)*2**2) index it0*2 title "hres ord2"  w l, \

# flush output to write the file
set output
