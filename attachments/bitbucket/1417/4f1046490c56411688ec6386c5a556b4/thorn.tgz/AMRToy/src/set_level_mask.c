/* Written by Cutter Coryell, July 9, 2013. */

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#include <cctk.h>
#include <cctk_Arguments.h>
#include <cctk_Parameters.h>
#include "cctk_WarnLevel.h"


/* C version of AMR_set_level_mask */
void AMR_set_level_mask2(CCTK_ARGUMENTS)
{
    
  DECLARE_CCTK_ARGUMENTS;
  DECLARE_CCTK_PARAMETERS;

  if (CCTK_EQUALS(radius_type, "shock"))
  {
    for(int k=0; k<cctk_lsh[2]; k++)
    {
      for(int j=0; j<cctk_lsh[1]; j++)
      {
        for(int i=0; i<cctk_lsh[0]; i++)
        {
          int vindex = CCTK_GFINDEX3D(cctkGH,i,j,k);

          if (level_mask[vindex] < 0 || 100 < level_mask[vindex])
          {
            CCTK_WARN(CCTK_WARN_ABORT, "level mask contains strange values");
          }

          if (shock_strength[vindex] > shock_threshold)
          {
            level_mask[vindex] = 1.0;
          }
          else
          {
            level_mask[vindex] = 0.0;
          }
        }
      }
    }
  }

  else if (CCTK_EQUALS(radius_type, "sphere"))
  {
    for(int k=0; k<cctk_lsh[2]; k++)
    {
      for(int j=0; j<cctk_lsh[1]; j++)
      {
        for(int i=0; i<cctk_lsh[0]; i++)
        {
          int vindex = CCTK_GFINDEX3D(cctkGH,i,j,k);
          
          if (level_mask[vindex] < 0 || 100 < level_mask[vindex])
          {
            CCTK_WARN(CCTK_WARN_ABORT, "level mask contains strange values");
          }
          
          level_mask[vindex] = max_radius / fmax(r[vindex], min_radius);
        }
      }
    }
  }

  else if (CCTK_EQUALS(radius_type, "annulus"))
  {
    for(int k=0; k<cctk_lsh[2]; k++)
    {
      for(int j=0; j<cctk_lsh[1]; j++)
      {
        for(int i=0; i<cctk_lsh[0]; i++)
        {
          int vindex = CCTK_GFINDEX3D(cctkGH,i,j,k);
          
          if (level_mask[vindex] < 0 || 100 < level_mask[vindex])
          {
            CCTK_WARN(CCTK_WARN_ABORT, "level mask contains strange values");
          }
          
          if (min_radius < r[vindex] && r[vindex] < max_radius)
          {
            level_mask[vindex] = 1.0;
          }
          else
          {
            level_mask[vindex] = 0.0;
          }
        }
      }
    }
  }
}
