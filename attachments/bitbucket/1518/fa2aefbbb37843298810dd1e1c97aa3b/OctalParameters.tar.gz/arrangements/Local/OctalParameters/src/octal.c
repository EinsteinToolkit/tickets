#include "cctk.h"
#include "cctk_Parameters.h"
#include "cctk_Arguments.h"

int octal_test(void)
{
  // new block so that local copies of parameters are re-initialized
  {
  DECLARE_CCTK_PARAMETERS;
  CCTK_VInfo(CCTK_THORNSTRING, "intparam at line %d is: %d", __LINE__,
             intparam);
  CCTK_VInfo(CCTK_THORNSTRING, "realparam at line %d is: %g", __LINE__,
             realparam);
  }

  CCTK_ParameterSet("intparam", CCTK_THORNSTRING, "10");
  CCTK_ParameterSet("realparam", CCTK_THORNSTRING, "10.0");
  // new block so that local copies of parameters are re-initialized
  {
  DECLARE_CCTK_PARAMETERS;
  CCTK_VInfo(CCTK_THORNSTRING, "intparam at line %d is: %d", __LINE__,
             intparam);
  CCTK_VInfo(CCTK_THORNSTRING, "realparam at line %d is: %g", __LINE__,
             realparam);
  }

  CCTK_ParameterSet("intparam", CCTK_THORNSTRING, "010");
  CCTK_ParameterSet("realparam", CCTK_THORNSTRING, "010.0");
  // new block so that local copies of parameters are re-initialized
  {
  DECLARE_CCTK_PARAMETERS;
  CCTK_VInfo(CCTK_THORNSTRING, "intparam at line %d is: %d", __LINE__,
             intparam);
  CCTK_VInfo(CCTK_THORNSTRING, "realparam at line %d is: %g", __LINE__,
             realparam);
  }

  CCTK_ParameterSet("intparam", CCTK_THORNSTRING, "0x10");
  CCTK_ParameterSet("realparam", CCTK_THORNSTRING, "0x10.0");
  // new block so that local copies of parameters are re-initialized
  {
  DECLARE_CCTK_PARAMETERS;
  CCTK_VInfo(CCTK_THORNSTRING, "intparam at line %d is: %d", __LINE__,
             intparam);
  CCTK_VInfo(CCTK_THORNSTRING, "realparam at line %d is: %g", __LINE__,
             realparam);
  }

  return 1;
}
