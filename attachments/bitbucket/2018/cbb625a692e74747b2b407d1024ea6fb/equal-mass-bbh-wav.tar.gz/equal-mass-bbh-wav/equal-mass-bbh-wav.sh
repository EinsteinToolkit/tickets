#PBS -q UCTlong
#PBS -N equal-mass-bbh-wav
#PBS -m abe
#PBS -M allgwy001@myuct.ac.za
#PBS -l nodes=1:ppn=46:series600
#PBS -o /home/allgwy001/Output/equal-mass-bbh-wav
#PBS -e /home/allgwy001/Output/equal-mass-bbh-wav
module load software/EinsteinToolkit
cd /home/allgwy001/Output
export OMP_NUM_THREADS=1
time mpirun -np 46 -hostfile $PBS_NODEFILE -v cactus_ET /home/allgwy001/repos/equal-mass-bbh/equal-mass-bbh-wav.par
